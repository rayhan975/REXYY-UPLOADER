package com.rexyy.uploader

import android.content.Context
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.fragment.app.FragmentActivity
import com.rexyy.uploader.audio.AudioProcessor
import com.rexyy.uploader.network.LinkDownloader
import com.rexyy.uploader.network.RobloxAssetUploader
import com.rexyy.uploader.security.BiometricHelper
import com.rexyy.uploader.security.SecureStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

// ═══════════════════════════════════════════════════════════════
// PALET WARNA — "Royal Gold" — hitam pekat + emas + putih bersih
// ═══════════════════════════════════════════════════════════════
private val BgDeep        = Color(0xFF000000)   // Pure black
private val BgCard        = Color(0xFF0C0C0C)   // Near black card
private val BgCardAlt     = Color(0xFF141414)   // Slightly lighter card
private val BgCardDark    = Color(0xFF080808)   // Darker card variant
private val GoldPrimary   = Color(0xFFFFD700)   // Classic gold
private val GoldLight     = Color(0xFFFFEC6E)   // Warm light gold
private val GoldDark      = Color(0xFFB8860B)   // Dark gold / antique
private val GoldAccent    = Color(0xFFF5C842)   // Mid gold accent
private val WhitePure     = Color(0xFFFFFFFF)   // Pure white
private val WhiteSoft     = Color(0xFFEEEEEE)   // Soft white
private val WhiteMuted    = Color(0xFFAAAAAA)   // Muted white/gray
private val GrayDim       = Color(0xFF4A4A4A)   // Dim gray for borders
private val GraySubtle    = Color(0xFF2A2A2A)   // Subtle dark gray
private val ErrorRed      = Color(0xFFFF4444)
private val SuccessGreen  = Color(0xFF00DD66)

// ── Gradient brushes ────────────────────────────────────────────
private val GoldBrush get() = Brush.linearGradient(
    listOf(GoldPrimary, GoldAccent.copy(alpha = 0.85f), GoldDark.copy(alpha = 0.7f))
)
private val GoldBorderBrush get() = Brush.linearGradient(
    listOf(GoldPrimary.copy(alpha = 0.9f), GoldLight.copy(alpha = 0.5f), GoldDark.copy(alpha = 0.3f))
)
private val CardBrush get() = Brush.linearGradient(
    listOf(BgCardAlt, BgCardDark)
)
private val SubtleGoldBg get() = Brush.linearGradient(
    listOf(GoldPrimary.copy(alpha = 0.06f), GoldDark.copy(alpha = 0.03f))
)

// ═══════════════════════════════════════════════════════════════
// HELPER — format durasi ms → "m:ss"
// ═══════════════════════════════════════════════════════════════
private fun formatDuration(ms: Long): String {
    if (ms <= 0L) return "--:--"
    val totalSec = ms / 1000
    val min = totalSec / 60
    val sec = totalSec % 60
    return "$min:${sec.toString().padStart(2, '0')}"
}

/** Format countdown ms → "HH:MM:SS" */
private fun formatCountdown(ms: Long): String {
    if (ms <= 0L) return "00:00:00"
    val totalSec = ms / 1000
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return "${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}"
}

private fun getAudioDurationMs(context: Context, uri: Uri): Long {
    return try {
        MediaMetadataRetriever().use { mmr ->
            mmr.setDataSource(context, uri)
            mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        }
    } catch (_: Exception) { 0L }
}

private fun getAudioDurationMsFromBytes(bytes: ByteArray, context: Context): Long {
    return try {
        val tmp = java.io.File(context.cacheDir, "_dur_probe_${System.currentTimeMillis()}.mp3")
        tmp.writeBytes(bytes)
        val dur = MediaMetadataRetriever().use { mmr ->
            mmr.setDataSource(tmp.absolutePath)
            mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        }
        tmp.delete()
        dur
    } catch (_: Exception) { 0L }
}

// ═══════════════════════════════════════════════════════════════
class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RexyyApp() }
    }
}

private enum class Page(val label: String) {
    Upload("Upload"), History("History"), Account("Akun"), Help("Bantuan")
}

private data class HistoryItem(
    val type: String,
    val name: String,
    val id: String,
    val status: String,
    val date: String,
    val operationId: String = "",
    val pending: Boolean = false
)

private fun getFileNameFromUri(context: Context, uri: Uri): String {
    var result = ""
    if (uri.scheme == "content") {
        val cursor = context.contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                val idx = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) result = it.getString(idx)
            }
        }
    }
    if (result.isBlank()) result = uri.lastPathSegment?.substringAfterLast('/') ?: "File dipilih"
    return result
}

// ═══════════════════════════════════════════════════════════════
// UI COMPONENTS
// ═══════════════════════════════════════════════════════════════

@Composable
private fun Modifier.goldBorder(
    cornerRadius: Dp = 18.dp,
    strokeWidth: Dp = 1.2.dp,
    subtle: Boolean = false
): Modifier = this.border(
    width = strokeWidth,
    brush = if (subtle)
        Brush.linearGradient(listOf(GoldDark.copy(alpha = 0.4f), GoldPrimary.copy(alpha = 0.2f)))
    else GoldBorderBrush,
    shape = RoundedCornerShape(cornerRadius)
)

/** Background animated dengan partikel gold halus */
@Composable
private fun AnimatedBg(modifier: Modifier = Modifier) {
    val inf = rememberInfiniteTransition(label = "bg")
    val s by inf.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(15000, easing = LinearEasing), RepeatMode.Reverse),
        label = "s"
    )
    Box(
        modifier.fillMaxSize().background(
            Brush.radialGradient(
                colors = listOf(
                    GoldPrimary.copy(alpha = 0.04f * s + 0.01f),
                    BgDeep
                ),
                radius = 1400f + 300f * s
            )
        )
    )
    // Subtle top-left accent
    Box(
        modifier.fillMaxSize().background(
            Brush.radialGradient(
                colors = listOf(GoldDark.copy(alpha = 0.03f), Color.Transparent),
                center = androidx.compose.ui.geometry.Offset(100f, 200f),
                radius = 600f
            )
        )
    )
}

@Composable
private fun GoldCard(
    modifier: Modifier = Modifier,
    subtle: Boolean = false,
    cornerRadius: Dp = 20.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier
            .fillMaxWidth()
            .goldBorder(cornerRadius, subtle = subtle)
            .clip(RoundedCornerShape(cornerRadius))
            .background(CardBrush)
            .padding(18.dp),
        content = content
    )
    Spacer(Modifier.height(12.dp))
}

@Composable
private fun StatusChip(text: String, color: Color, bgColor: Color = color.copy(alpha = 0.12f)) {
    Box(
        Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .border(0.5.dp, color.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Text(text, color = color, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 0.5.sp)
    }
}

@Composable
private fun PillTab(
    label: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    onClick: () -> Unit
) {
    Box(
        modifier
            .clip(RoundedCornerShape(12.dp))
            .background(
                if (selected)
                    Brush.linearGradient(listOf(GoldPrimary, GoldDark))
                else
                    Brush.linearGradient(listOf(GraySubtle, BgCard))
            )
            .then(
                if (!selected) Modifier.border(1.dp, GrayDim.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                else Modifier
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            if (icon != null) {
                Icon(
                    icon, null,
                    tint = if (selected) BgDeep else WhiteMuted,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(Modifier.width(5.dp))
            }
            Text(
                label,
                color = if (selected) BgDeep else WhiteMuted,
                fontSize = 13.sp,
                fontWeight = if (selected) FontWeight.Black else FontWeight.Medium
            )
        }
    }
}

@Composable
private fun SpeedChip(speed: Float, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .clip(RoundedCornerShape(10.dp))
            .background(
                if (selected)
                    Brush.linearGradient(listOf(GoldPrimary, GoldDark))
                else
                    Brush.linearGradient(listOf(GraySubtle, BgCard))
            )
            .then(
                if (!selected) Modifier.border(1.dp, GrayDim.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                else Modifier
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            if (speed == 1.0f) "1×" else "${speed}×",
            color = if (selected) BgDeep else WhiteMuted,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Normal
        )
    }
}

@Composable
private fun InfoRow(icon: ImageVector, tint: Color, text: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(15.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, color = WhiteMuted, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun WaveformAnim(playing: Boolean, color: Color = GoldPrimary) {
    val inf = rememberInfiniteTransition(label = "wave")
    val bars = (0 until 5).map { i ->
        if (playing) {
            inf.animateFloat(
                initialValue = 0.25f + i * 0.05f,
                targetValue = 0.9f - i * 0.05f,
                animationSpec = infiniteRepeatable(
                    tween((300 + i * 80), easing = LinearEasing),
                    RepeatMode.Reverse
                ),
                label = "bar$i"
            ).value
        } else 0.3f
    }
    Row(
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.height(24.dp)
    ) {
        bars.forEach { h ->
            Box(
                Modifier
                    .width(3.dp)
                    .fillMaxHeight(h)
                    .clip(RoundedCornerShape(2.dp))
                    .background(color.copy(alpha = 0.85f))
            )
        }
    }
}

@Composable
private fun AudioPreviewRow(
    isPlaying: Boolean,
    durationMs: Long,
    speed: Float,
    loading: Boolean,
    label: String,
    onPlayPause: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Brush.linearGradient(listOf(GoldPrimary.copy(alpha = 0.06f), GoldDark.copy(alpha = 0.03f))))
            .border(1.dp, GoldPrimary.copy(alpha = 0.25f), RoundedCornerShape(14.dp))
            .clickable(enabled = !loading, onClick = onPlayPause)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(
                    if (isPlaying)
                        Brush.linearGradient(listOf(GoldPrimary, GoldDark))
                    else
                        Brush.linearGradient(listOf(GoldDark.copy(alpha = 0.8f), GoldPrimary.copy(alpha = 0.6f)))
                ),
            contentAlignment = Alignment.Center
        ) {
            if (loading) {
                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = BgDeep)
            } else {
                Icon(
                    if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    null, tint = BgDeep, modifier = Modifier.size(22.dp)
                )
            }
        }

        Spacer(Modifier.width(12.dp))

        Column(Modifier.weight(1f)) {
            Text(
                if (loading) "Memuat audio…" else label,
                color = if (loading) WhiteMuted else WhitePure,
                fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (durationMs > 0) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Timer, null, tint = GoldAccent, modifier = Modifier.size(11.dp))
                        Spacer(Modifier.width(3.dp))
                        val effectiveDur = if (speed != 1.0f) (durationMs / speed).toLong() else durationMs
                        Text(formatDuration(effectiveDur), color = GoldAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        if (speed != 1.0f) {
                            Spacer(Modifier.width(3.dp))
                            Text("(${formatDuration(durationMs)} asli)", color = WhiteMuted, fontSize = 10.sp)
                        }
                    }
                }
                StatusChip("${speed}×", GoldPrimary, GoldPrimary.copy(alpha = 0.1f))
            }
        }

        Spacer(Modifier.width(10.dp))
        WaveformAnim(isPlaying, GoldPrimary)
    }
}

// ═══════════════════════════════════════════════════════════════
// MAIN APP
// ═══════════════════════════════════════════════════════════════
@Composable
private fun RexyyApp() {
    val context = LocalContext.current
    val activity = context as FragmentActivity
    val prefs = remember { SecureStore.get(context) }

    var page by remember { mutableStateOf(Page.Upload) }
    var type by remember { mutableStateOf("Audio") }
    var uri by remember { mutableStateOf<Uri?>(null) }
    var fileName by remember { mutableStateOf("") }
    var fileDurationMs by remember { mutableLongStateOf(0L) }

    var apiKey by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
    var creator by remember { mutableStateOf(prefs.getString("creator_id", "") ?: "") }
    var apiKeyVisible by remember { mutableStateOf(false) }
    var accountUnlocked by remember { mutableStateOf(false) }

    var isVip by remember { mutableStateOf(UploadLimit.isVip(context)) }
    var vipKeyInput by remember { mutableStateOf("") }
    var vipKeyVisible by remember { mutableStateOf(false) }

    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("Uploaded via Rexyy Uploader") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var history by remember { mutableStateOf(loadHistory(prefs.getString("history", "[]") ?: "[]")) }

    var uploadBadge by remember { mutableStateOf(UploadLimit.badgeText(context)) }

    // Live countdown state
    var countdownMs by remember { mutableLongStateOf(0L) }

    var selectedSpeed by remember { mutableStateOf(1.0f) }
    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    var isPlaying by remember { mutableStateOf(false) }

    var uploadMode by remember { mutableStateOf("File") }
    var linkInput by remember { mutableStateOf("") }
    var linkStatus by remember { mutableStateOf("") }
    var linkAudioBytes by remember { mutableStateOf<ByteArray?>(null) }
    var linkAudioMime by remember { mutableStateOf("audio/mpeg") }
    var linkAudioName by remember { mutableStateOf("audio.mp3") }
    var linkMediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    var linkIsPlaying by remember { mutableStateOf(false) }
    var linkFetching by remember { mutableStateOf(false) }
    var linkSelectedSpeed by remember { mutableStateOf(1.0f) }
    var linkDurationMs by remember { mutableLongStateOf(0L) }

    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    fun refreshLimit() {
        isVip = UploadLimit.isVip(context)
        uploadBadge = UploadLimit.badgeText(context)
        countdownMs = UploadLimit.millisUntilNextSlot(context)
    }

    // Live countdown ticker — update setiap detik saat limit aktif
    LaunchedEffect(uploadBadge) {
        while (true) {
            val ms = UploadLimit.millisUntilNextSlot(context)
            countdownMs = ms
            if (ms <= 0L) {
                // Slot sudah terbuka, refresh badge
                val prev = uploadBadge
                isVip = UploadLimit.isVip(context)
                uploadBadge = UploadLimit.badgeText(context)
                if (uploadBadge != prev) break
            }
            delay(1000L)
        }
    }

    fun persistHistory(new: List<HistoryItem>) {
        history = new
        prefs.edit().putString("history", saveHistory(new)).apply()
    }

    fun pollOperation(apiKeyTrim: String, operationId: String, historyIndexId: String) {
        scope.launch {
            var found = ""
            var lastRaw = ""
            var done = false
            repeat(24) { attempt ->
                if (found.isBlank() && !done) {
                    kotlinx.coroutines.delay(3000)
                    try {
                        lastRaw = withContext(Dispatchers.IO) {
                            RobloxAssetUploader(context).checkOperation(apiKeyTrim, operationId)
                        }
                        val j = JSONObject(lastRaw)
                        done = j.optBoolean("done", false)
                        val response = j.optJSONObject("response")
                        found = response?.optString("assetId").orEmpty()
                        status = when {
                            found.isNotBlank() -> "Selesai • Asset ID: $found"
                            done -> "Operasi selesai di Roblox, menunggu Asset ID muncul…"
                            else -> "Memproses upload… (percobaan ${attempt + 1}/24)"
                        }
                    } catch (e: Exception) {
                        status = "Gagal cek status: ${e.message ?: "tidak diketahui"}"
                    }
                }
            }
            val finalStatus = when {
                found.isNotBlank() -> "Selesai • Asset ID: $found"
                done -> "Diproses Roblox — cek Creator Dashboard atau tekan Cek status lagi"
                else -> "Masih diproses Roblox (moderasi bisa > 72 detik) — tekan Cek status lagi nanti"
            }
            status = finalStatus
            val updated = history.map {
                if (it.id == historyIndexId) it.copy(
                    id = found.ifBlank { it.id },
                    status = finalStatus,
                    pending = found.isBlank()
                ) else it
            }
            persistHistory(updated)
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { picked ->
        if (picked != null) {
            uri = picked
            fileName = getFileNameFromUri(context, picked)
            val nameWithoutExt = fileName.substringBeforeLast('.').ifBlank { fileName }
            name = nameWithoutExt
            fileDurationMs = 0L
            try {
                context.contentResolver.takePersistableUriPermission(
                    picked, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            mediaPlayer?.release(); mediaPlayer = null; isPlaying = false
            scope.launch {
                fileDurationMs = withContext(Dispatchers.IO) { getAudioDurationMs(context, picked) }
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            mediaPlayer?.release(); mediaPlayer = null
            linkMediaPlayer?.release(); linkMediaPlayer = null
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = GoldPrimary, background = BgDeep, surface = BgCard)) {
        Box(Modifier.fillMaxSize()) {
            AnimatedBg()
            Scaffold(
                containerColor = Color.Transparent,
                snackbarHost = { SnackbarHost(snackbar) },
                bottomBar = {
                    NavigationBar(
                        containerColor = BgCard.copy(alpha = 0.98f),
                        tonalElevation = 0.dp
                    ) {
                        Page.values().forEach { p ->
                            NavigationBarItem(
                                selected = page == p,
                                onClick = { page = p; refreshLimit() },
                                icon = {
                                    Icon(
                                        when (p) {
                                            Page.Upload  -> Icons.Default.CloudUpload
                                            Page.History -> Icons.Default.History
                                            Page.Account -> Icons.Default.Shield
                                            Page.Help    -> Icons.Default.Help
                                        }, null
                                    )
                                },
                                label = { Text(p.label, fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = GoldPrimary,
                                    selectedTextColor = GoldPrimary,
                                    unselectedIconColor = GrayDim,
                                    unselectedTextColor = GrayDim,
                                    indicatorColor = GoldPrimary.copy(alpha = 0.15f)
                                )
                            )
                        }
                    }
                }
            ) { pad ->
                Column(
                    Modifier
                        .fillMaxSize()
                        .padding(pad)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 18.dp, vertical = 14.dp)
                ) {

                    // ═══ HEADER ═══════════════════════════════════════════
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Logo dengan gold glow border
                            Box(
                                Modifier
                                    .size(52.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .goldBorder(14.dp)
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.rexyy_logo),
                                    contentDescription = "Logo",
                                    modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(14.dp)),
                                    contentScale = ContentScale.Crop
                                )
                            }
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(
                                    "REXYY",
                                    fontSize = 26.sp,
                                    fontWeight = FontWeight.Black,
                                    color = WhitePure,
                                    letterSpacing = 4.sp
                                )
                                Text(
                                    "ROBLOX UPLOADER",
                                    fontSize = 9.sp,
                                    color = GoldAccent,
                                    letterSpacing = 2.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            StatusChip(
                                if (apiKey.isBlank()) "BELUM TERHUBUNG" else "KEY AKTIF",
                                if (apiKey.isBlank()) GoldPrimary else SuccessGreen
                            )
                            StatusChip(
                                uploadBadge,
                                if (isVip) GoldPrimary else WhiteMuted,
                                if (isVip) GoldPrimary.copy(alpha = 0.12f) else GraySubtle
                            )
                        }
                    }

                    // Live countdown banner — tampil saat limit penuh
                    if (!isVip && countdownMs > 0L) {
                        Spacer(Modifier.height(10.dp))
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Brush.linearGradient(listOf(GoldDark.copy(alpha = 0.12f), BgCard)))
                                .border(1.dp, GoldDark.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Timer, null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(8.dp))
                                Column {
                                    Text("Limit harian tercapai", color = WhiteSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Text("Slot baru terbuka dalam:", color = WhiteMuted, fontSize = 10.sp)
                                }
                            }
                            // Countdown digital
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(BgDeep)
                                    .border(1.dp, GoldPrimary.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    formatCountdown(countdownMs),
                                    color = GoldPrimary,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 2.sp
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(20.dp))

                    // ═══════════════════════════════════════════════════════
                    when (page) {

                        // ═══ PAGE: UPLOAD ══════════════════════════════════
                        Page.Upload -> {
                            Text("Upload Asset", color = WhitePure, fontSize = 22.sp, fontWeight = FontWeight.Black)
                            Text("Kirim audio atau decal ke akunmu", color = WhiteMuted, fontSize = 12.sp)
                            Spacer(Modifier.height(16.dp))

                            GoldCard {
                                // Tab Audio / Decal
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("Audio" to Icons.Default.MusicNote, "Decal" to Icons.Default.Image)
                                        .forEach { (t, ic) ->
                                            PillTab(t, type == t, Modifier.weight(1f), icon = ic) {
                                                type = t
                                                uri = null; fileName = ""; name = ""; fileDurationMs = 0L
                                                linkInput = ""; linkStatus = ""; linkAudioBytes = null
                                                mediaPlayer?.release(); mediaPlayer = null; isPlaying = false
                                                linkMediaPlayer?.release(); linkMediaPlayer = null; linkIsPlaying = false
                                            }
                                        }
                                }

                                if (type == "Audio") {
                                    Spacer(Modifier.height(12.dp))
                                    Row(
                                        Modifier.fillMaxWidth()
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(BgDeep.copy(alpha = 0.7f))
                                            .padding(4.dp),
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        listOf("File" to Icons.Default.FolderOpen, "Link" to Icons.Default.Link)
                                            .forEach { (mode, ic) ->
                                                PillTab(
                                                    mode, uploadMode == mode,
                                                    Modifier.weight(1f), icon = ic
                                                ) {
                                                    uploadMode = mode
                                                    uri = null; fileName = ""; linkInput = ""; linkStatus = ""; linkAudioBytes = null
                                                    fileDurationMs = 0L; linkDurationMs = 0L
                                                    mediaPlayer?.release(); mediaPlayer = null; isPlaying = false
                                                    linkMediaPlayer?.release(); linkMediaPlayer = null; linkIsPlaying = false
                                                }
                                            }
                                    }
                                }

                                Spacer(Modifier.height(14.dp))
                                HorizontalDivider(color = GoldDark.copy(alpha = 0.2f))
                                Spacer(Modifier.height(14.dp))

                                // ─── MODE FILE ────────────────────────────────
                                if (type != "Audio" || uploadMode == "File") {
                                    Box(
                                        Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(16.dp))
                                            .background(
                                                Brush.linearGradient(
                                                    listOf(GoldPrimary.copy(alpha = 0.05f), BgCard)
                                                )
                                            )
                                            .border(
                                                1.5.dp,
                                                if (uri != null) GoldPrimary.copy(alpha = 0.7f)
                                                else GrayDim.copy(alpha = 0.4f),
                                                RoundedCornerShape(16.dp)
                                            )
                                            .clickable {
                                                picker.launch(
                                                    if (type == "Audio") arrayOf("audio/*") else arrayOf("image/*")
                                                )
                                            }
                                            .padding(28.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            if (uri == null) {
                                                Box(
                                                    Modifier
                                                        .size(64.dp)
                                                        .clip(CircleShape)
                                                        .background(
                                                            Brush.linearGradient(
                                                                listOf(GoldPrimary.copy(alpha = 0.15f), GoldDark.copy(alpha = 0.08f))
                                                            )
                                                        )
                                                        .border(1.dp, GoldPrimary.copy(alpha = 0.3f), CircleShape),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(
                                                        if (type == "Audio") Icons.Default.MusicNote else Icons.Default.Image,
                                                        null, tint = GoldPrimary, modifier = Modifier.size(30.dp)
                                                    )
                                                }
                                                Spacer(Modifier.height(12.dp))
                                                Text("Pilih file dari HP", color = WhitePure, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                                                Spacer(Modifier.height(4.dp))
                                                Text(
                                                    if (type == "Audio") "Format audio yang didukung Roblox" else "PNG / JPG",
                                                    color = WhiteMuted, fontSize = 11.sp
                                                )
                                            } else {
                                                Box(
                                                    Modifier
                                                        .size(56.dp)
                                                        .clip(CircleShape)
                                                        .background(GoldPrimary.copy(alpha = 0.12f))
                                                        .border(1.dp, GoldPrimary.copy(alpha = 0.4f), CircleShape),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(
                                                        if (type == "Audio") Icons.Default.AudioFile else Icons.Default.Image,
                                                        null, tint = GoldPrimary, modifier = Modifier.size(28.dp)
                                                    )
                                                }
                                                Spacer(Modifier.height(10.dp))
                                                Text(
                                                    fileName, color = WhitePure, fontSize = 13.sp,
                                                    fontWeight = FontWeight.Bold, maxLines = 2,
                                                    overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
                                                )
                                                if (fileDurationMs > 0L && type == "Audio") {
                                                    Spacer(Modifier.height(6.dp))
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        Icon(Icons.Default.Timer, null, tint = GoldAccent, modifier = Modifier.size(12.dp))
                                                        Spacer(Modifier.width(4.dp))
                                                        Text(
                                                            "Durasi: ${formatDuration(fileDurationMs)}",
                                                            color = GoldAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold
                                                        )
                                                    }
                                                }
                                                Spacer(Modifier.height(6.dp))
                                                Text("Tap untuk ganti file", color = WhiteMuted, fontSize = 10.sp)
                                            }
                                        }
                                    }

                                    if (type == "Audio" && uri != null) {
                                        Spacer(Modifier.height(16.dp))

                                        Row(
                                            Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.Speed, null, tint = GoldPrimary, modifier = Modifier.size(15.dp))
                                                Spacer(Modifier.width(5.dp))
                                                Text("SPEED UPLOAD", color = WhiteMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                                            }
                                            if (fileDurationMs > 0L) {
                                                val effDur = if (selectedSpeed != 1.0f) (fileDurationMs / selectedSpeed).toLong() else fileDurationMs
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(Icons.Default.Timer, null, tint = GoldAccent, modifier = Modifier.size(12.dp))
                                                    Spacer(Modifier.width(3.dp))
                                                    Text(
                                                        formatDuration(effDur),
                                                        color = GoldAccent, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold
                                                    )
                                                    if (selectedSpeed != 1.0f) {
                                                        Text(" di Roblox", color = WhiteMuted, fontSize = 10.sp)
                                                    }
                                                }
                                            }
                                        }

                                        Spacer(Modifier.height(8.dp))

                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                            listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f).forEach { spd ->
                                                SpeedChip(spd, selectedSpeed == spd, modifier = Modifier.weight(1f)) {
                                                    selectedSpeed = spd
                                                    mediaPlayer?.playbackParams =
                                                        mediaPlayer?.playbackParams?.setSpeed(spd) ?: return@SpeedChip
                                                }
                                            }
                                        }

                                        Spacer(Modifier.height(12.dp))

                                        AudioPreviewRow(
                                            isPlaying = isPlaying,
                                            durationMs = fileDurationMs,
                                            speed = selectedSpeed,
                                            loading = false,
                                            label = fileName
                                        ) {
                                            if (isPlaying) {
                                                mediaPlayer?.pause(); isPlaying = false
                                            } else {
                                                try {
                                                    if (mediaPlayer == null) {
                                                        mediaPlayer = MediaPlayer().apply {
                                                            setDataSource(context, uri!!)
                                                            prepare()
                                                            playbackParams = playbackParams.setSpeed(selectedSpeed)
                                                            setOnCompletionListener { isPlaying = false }
                                                        }
                                                    } else {
                                                        mediaPlayer?.playbackParams =
                                                            mediaPlayer!!.playbackParams.setSpeed(selectedSpeed)
                                                    }
                                                    mediaPlayer?.start(); isPlaying = true
                                                } catch (e: Exception) {
                                                    status = "Gagal preview: ${e.message}"
                                                }
                                            }
                                        }
                                    }
                                }

                                // ─── MODE LINK ────────────────────────────────
                                else {
                                    Row(
                                        Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(GoldDark.copy(alpha = 0.06f))
                                            .border(1.dp, GoldDark.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                                            .padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("♪", color = GoldAccent, fontSize = 18.sp)
                                        Spacer(Modifier.width(8.dp))
                                        Column {
                                            Text("TikTok Audio Import", color = GoldAccent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                            Text("Paste link TikTok untuk ambil audionya", color = WhiteMuted, fontSize = 10.sp)
                                        }
                                    }
                                    Spacer(Modifier.height(12.dp))

                                    OutlinedTextField(
                                        value = linkInput,
                                        onValueChange = { v ->
                                            linkInput = v
                                            linkStatus = ""
                                            linkAudioBytes = null
                                            linkDurationMs = 0L
                                            linkMediaPlayer?.release(); linkMediaPlayer = null; linkIsPlaying = false
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        label = { Text("Link TikTok (tiktok.com / vt.tiktok.com)", fontSize = 11.sp) },
                                        singleLine = true,
                                        leadingIcon = { Text("♪", color = GoldAccent, fontSize = 14.sp, modifier = Modifier.padding(start = 4.dp)) },
                                        trailingIcon = {
                                            if (linkInput.isNotBlank()) {
                                                IconButton(onClick = {
                                                    linkInput = ""; linkStatus = ""; linkAudioBytes = null; linkDurationMs = 0L
                                                }) { Icon(Icons.Default.Clear, null, tint = WhiteMuted) }
                                            }
                                        },
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = GoldPrimary,
                                            unfocusedBorderColor = GrayDim.copy(alpha = 0.5f)
                                        )
                                    )

                                    if (linkInput.isNotBlank()) {
                                        Spacer(Modifier.height(6.dp))
                                        val detected = LinkDownloader.detectType(linkInput)
                                        when {
                                            detected == LinkDownloader.LinkType.UNSUPPORTED ->
                                                Text("⚠ Link tidak dikenali. Gunakan link TikTok yang valid.", color = GoldDark, fontSize = 11.sp)
                                            else ->
                                                Text("TikTok terdeteksi ♪", color = GoldAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    if (linkStatus.isNotBlank()) {
                                        Spacer(Modifier.height(6.dp))
                                        Text(
                                            linkStatus,
                                            color = when {
                                                linkStatus.startsWith("✓") -> SuccessGreen
                                                linkStatus.startsWith("✗") || linkStatus.startsWith("Gagal") -> ErrorRed
                                                else -> WhiteMuted
                                            },
                                            fontSize = 11.sp
                                        )
                                    }

                                    val isLinkValid = linkInput.isNotBlank() &&
                                        LinkDownloader.detectType(linkInput) != LinkDownloader.LinkType.UNSUPPORTED

                                    LaunchedEffect(linkInput) {
                                        if (isLinkValid && linkAudioBytes == null && !linkFetching) {
                                            linkFetching = true
                                            linkStatus = "⏳ Memuat audio…"
                                            try {
                                                val ltype = LinkDownloader.detectType(linkInput)
                                                val dl = withContext(Dispatchers.IO) {
                                                    LinkDownloader.download(linkInput.trim(), ltype)
                                                }
                                                val bytes = withContext(Dispatchers.IO) { dl.stream.use { it.readBytes() } }
                                                linkAudioBytes = bytes
                                                linkAudioMime  = dl.mimeType
                                                linkAudioName  = dl.fileName
                                                linkDurationMs = withContext(Dispatchers.IO) {
                                                    getAudioDurationMsFromBytes(bytes, context)
                                                }
                                                linkStatus = "✓ Audio siap (${bytes.size / 1024} KB)${if (linkDurationMs > 0) " · ${formatDuration(linkDurationMs)}" else ""}"
                                            } catch (e: Exception) {
                                                linkStatus = "✗ Gagal: ${e.message ?: "Error"}"
                                            } finally {
                                                linkFetching = false
                                            }
                                        }
                                    }

                                    if (isLinkValid) {
                                        Spacer(Modifier.height(16.dp))
                                        HorizontalDivider(color = GoldDark.copy(alpha = 0.2f))
                                        Spacer(Modifier.height(14.dp))

                                        Row(
                                            Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.Speed, null, tint = GoldPrimary, modifier = Modifier.size(15.dp))
                                                Spacer(Modifier.width(5.dp))
                                                Text("SPEED UPLOAD", color = WhiteMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                                            }
                                            if (linkDurationMs > 0L) {
                                                val effDur = if (linkSelectedSpeed != 1.0f) (linkDurationMs / linkSelectedSpeed).toLong() else linkDurationMs
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(Icons.Default.Timer, null, tint = GoldAccent, modifier = Modifier.size(12.dp))
                                                    Spacer(Modifier.width(3.dp))
                                                    Text(
                                                        formatDuration(effDur),
                                                        color = GoldAccent, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold
                                                    )
                                                    if (linkSelectedSpeed != 1.0f) {
                                                        Text(" di Roblox", color = WhiteMuted, fontSize = 10.sp)
                                                    }
                                                }
                                            }
                                        }
                                        Spacer(Modifier.height(8.dp))

                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                            listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f).forEach { spd ->
                                                SpeedChip(spd, linkSelectedSpeed == spd, modifier = Modifier.weight(1f)) {
                                                    linkSelectedSpeed = spd
                                                    linkMediaPlayer?.playbackParams =
                                                        linkMediaPlayer?.playbackParams?.setSpeed(spd) ?: return@SpeedChip
                                                }
                                            }
                                        }
                                        Spacer(Modifier.height(12.dp))

                                        AudioPreviewRow(
                                            isPlaying = linkIsPlaying,
                                            durationMs = linkDurationMs,
                                            speed = linkSelectedSpeed,
                                            loading = linkFetching,
                                            label = linkAudioName
                                        ) {
                                            if (linkFetching) return@AudioPreviewRow
                                            if (linkIsPlaying) {
                                                linkMediaPlayer?.pause(); linkIsPlaying = false
                                            } else {
                                                try {
                                                    if (linkMediaPlayer == null) {
                                                        val tmp = java.io.File(context.cacheDir, linkAudioName)
                                                        tmp.writeBytes(linkAudioBytes!!)
                                                        linkMediaPlayer = MediaPlayer().apply {
                                                            setDataSource(tmp.absolutePath)
                                                            prepare()
                                                            playbackParams = playbackParams.setSpeed(linkSelectedSpeed)
                                                            setOnCompletionListener { linkIsPlaying = false }
                                                        }
                                                    } else {
                                                        linkMediaPlayer?.playbackParams =
                                                            linkMediaPlayer!!.playbackParams.setSpeed(linkSelectedSpeed)
                                                    }
                                                    linkMediaPlayer?.start(); linkIsPlaying = true
                                                } catch (e: Exception) {
                                                    linkStatus = "✗ Gagal preview: ${e.message}"
                                                }
                                            }
                                        }
                                    }
                                }

                                Spacer(Modifier.height(16.dp))
                                HorizontalDivider(color = GoldDark.copy(alpha = 0.2f))
                                Spacer(Modifier.height(14.dp))

                                OutlinedTextField(
                                    name, { name = it }, Modifier.fillMaxWidth(),
                                    label = { Text("Display Name") }, singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = GoldPrimary,
                                        unfocusedBorderColor = GrayDim.copy(alpha = 0.5f)
                                    )
                                )
                                Spacer(Modifier.height(8.dp))
                                OutlinedTextField(
                                    desc, { desc = it }, Modifier.fillMaxWidth(),
                                    label = { Text("Deskripsi") }, minLines = 2,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = GoldPrimary,
                                        unfocusedBorderColor = GrayDim.copy(alpha = 0.5f)
                                    )
                                )
                                Spacer(Modifier.height(16.dp))

                                // Tombol upload
                                Button(
                                    onClick = {
                                        val isLinkMode = type == "Audio" && uploadMode == "Link"
                                        if (apiKey.isBlank() || creator.toLongOrNull() == null || name.isBlank()) {
                                            status = "Lengkapi API Key, Creator ID, dan nama asset."
                                            return@Button
                                        }
                                        if (!isLinkMode && uri == null) { status = "Pilih file terlebih dahulu."; return@Button }
                                        if (isLinkMode && linkInput.isBlank()) { status = "Paste link TikTok dulu."; return@Button }
                                        if (isLinkMode && LinkDownloader.detectType(linkInput) == LinkDownloader.LinkType.UNSUPPORTED) {
                                            status = "Link tidak dikenali. Gunakan link TikTok."; return@Button
                                        }
                                        val limitError = UploadLimit.checkAllowed(context)
                                        if (limitError != null) { status = limitError; return@Button }

                                        busy = true
                                        status = if (isLinkMode) "Memproses & upload audio dari link…" else "Mengirim file ke Roblox…"
                                        if (isLinkMode) linkStatus = "⏳ Memproses audio…"

                                        scope.launch {
                                            try {
                                                val result = withContext(Dispatchers.IO) {
                                                    if (isLinkMode) {
                                                        val (bytes, fname, mime) = if (linkAudioBytes != null) {
                                                            withContext(Dispatchers.Main) {
                                                                linkStatus = "✓ Pakai audio yang sudah diambil — mengirim ke Roblox…"
                                                                status = linkStatus
                                                            }
                                                            Triple(linkAudioBytes!!, linkAudioName, linkAudioMime)
                                                        } else {
                                                            val ltype = LinkDownloader.detectType(linkInput)
                                                            val dl = LinkDownloader.download(linkInput.trim(), ltype)
                                                            val b = dl.stream.use { it.readBytes() }
                                                            withContext(Dispatchers.Main) {
                                                                linkStatus = "✓ Audio siap (${b.size / 1024} KB) — mengirim ke Roblox…"
                                                                status = linkStatus
                                                                linkAudioBytes = b
                                                                linkAudioMime  = dl.mimeType
                                                                linkAudioName  = dl.fileName
                                                            }
                                                            Triple(b, dl.fileName, dl.mimeType)
                                                        }
                                                        val processedBytes = AudioProcessor.applySpeed(bytes, linkSelectedSpeed, context)
                                                        val uploadMime = if (processedBytes !== bytes && !mime.contains("wav")) "audio/wav" else mime
                                                        val uploadFname = if (processedBytes !== bytes && !mime.contains("wav")) fname.substringBeforeLast('.') + ".wav" else fname
                                                        RobloxAssetUploader(context).uploadFromBytes(
                                                            apiKey.trim(), processedBytes, uploadFname, uploadMime,
                                                            "Audio", name.trim(), desc.trim(), creator.toLong()
                                                        )
                                                    } else {
                                                        if (type == "Audio" && selectedSpeed != 1.0f) {
                                                            val rawBytes = context.contentResolver.openInputStream(uri!!)?.use { it.readBytes() }
                                                                ?: error("File tidak bisa dibaca")
                                                            val processedBytes = AudioProcessor.applySpeed(rawBytes, selectedSpeed, context)
                                                            val origMime = context.contentResolver.getType(uri!!) ?: "audio/mpeg"
                                                            // Gunakan fileName (sudah terbaca dengan benar dari ContentResolver)
                                                            val uploadMime = if (processedBytes !== rawBytes && !origMime.contains("wav")) "audio/wav" else origMime
                                                            val uploadFname = if (processedBytes !== rawBytes && !origMime.contains("wav"))
                                                                fileName.substringBeforeLast('.') + ".wav"
                                                            else fileName
                                                            RobloxAssetUploader(context).uploadFromBytes(
                                                                apiKey.trim(), processedBytes, uploadFname, uploadMime,
                                                                type, name.trim(), desc.trim(), creator.toLong()
                                                            )
                                                        } else {
                                                            RobloxAssetUploader(context).upload(
                                                                apiKey.trim(), uri!!, type, name.trim(), desc.trim(), creator.toLong()
                                                            )
                                                        }
                                                    }
                                                }
                                                UploadLimit.recordUpload(context)
                                                refreshLimit()

                                                val operation = result.operationId.orEmpty()
                                                val assetId   = result.assetId.orEmpty()
                                                val tempId    = assetId.ifBlank { operation.ifBlank { System.currentTimeMillis().toString() } }
                                                status = if (assetId.isNotBlank()) "Upload berhasil. Asset ID: $assetId" else "Upload diterima. Memeriksa status…"
                                                if (isLinkMode) linkStatus = "✓ $status"

                                                val pendingItem = HistoryItem(
                                                    type = type, name = name, id = tempId,
                                                    status = status, date = System.currentTimeMillis().toString(),
                                                    operationId = operation, pending = assetId.isBlank() && operation.isNotBlank()
                                                )
                                                persistHistory(listOf(pendingItem) + history)

                                                if (assetId.isBlank() && operation.isNotBlank()) {
                                                    pollOperation(apiKey.trim(), operation, tempId)
                                                }
                                            } catch (e: Exception) {
                                                status = "Gagal: ${e.message ?: "Kesalahan tidak diketahui"}"
                                                if (uploadMode == "Link") linkStatus = "✗ ${e.message ?: "Gagal"}"
                                            } finally {
                                                busy = false
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth().height(56.dp),
                                    enabled = !busy,
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Box(
                                        Modifier
                                            .fillMaxSize()
                                            .background(
                                                if (!busy) GoldBrush
                                                else Brush.linearGradient(listOf(GrayDim.copy(alpha = 0.5f), GraySubtle)),
                                                shape = RoundedCornerShape(16.dp)
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            if (busy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = BgDeep)
                                            else Icon(Icons.Default.CloudUpload, null, tint = BgDeep)
                                            Spacer(Modifier.width(10.dp))
                                            Text(
                                                if (busy) "SEDANG UPLOAD…" else "UPLOAD ASSET",
                                                color = if (!busy) BgDeep else WhiteMuted,
                                                fontWeight = FontWeight.Black,
                                                fontSize = 15.sp, letterSpacing = 1.sp
                                            )
                                        }
                                    }
                                }

                                AnimatedVisibility(visible = status.isNotBlank()) {
                                    Column {
                                        Spacer(Modifier.height(12.dp))
                                        Row(
                                            Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(
                                                    when {
                                                        status.startsWith("Upload berhasil") || status.startsWith("Selesai") ->
                                                            SuccessGreen.copy(alpha = 0.07f)
                                                        status.startsWith("Gagal") || status.startsWith("Limit") ->
                                                            ErrorRed.copy(alpha = 0.07f)
                                                        else -> GoldPrimary.copy(alpha = 0.05f)
                                                    }
                                                )
                                                .border(
                                                    1.dp,
                                                    when {
                                                        status.startsWith("Upload berhasil") || status.startsWith("Selesai") ->
                                                            SuccessGreen.copy(alpha = 0.35f)
                                                        status.startsWith("Gagal") || status.startsWith("Limit") ->
                                                            ErrorRed.copy(alpha = 0.35f)
                                                        else -> GoldDark.copy(alpha = 0.3f)
                                                    },
                                                    RoundedCornerShape(12.dp)
                                                )
                                                .padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                when {
                                                    status.startsWith("Upload berhasil") || status.startsWith("Selesai") ->
                                                        Icons.Default.CheckCircle
                                                    status.startsWith("Gagal") || status.startsWith("Limit") ->
                                                        Icons.Default.Error
                                                    else -> Icons.Default.Info
                                                },
                                                null,
                                                tint = when {
                                                    status.startsWith("Upload berhasil") || status.startsWith("Selesai") -> SuccessGreen
                                                    status.startsWith("Gagal") || status.startsWith("Limit") -> ErrorRed
                                                    else -> GoldAccent
                                                },
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(Modifier.width(10.dp))
                                            Text(status, color = WhiteSoft, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.weight(1f))
                                        }
                                    }
                                }
                            }
                        }

                        // ═══ PAGE: HISTORY ════════════════════════════════
                        Page.History -> {
                            Text("Riwayat Upload", color = WhitePure, fontSize = 22.sp, fontWeight = FontWeight.Black)
                            Text("Tersimpan lokal di perangkat ini", color = WhiteMuted, fontSize = 12.sp)
                            Spacer(Modifier.height(16.dp))

                            if (history.isEmpty()) {
                                GoldCard {
                                    Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Icon(Icons.Default.History, null, tint = GrayDim, modifier = Modifier.size(40.dp))
                                            Spacer(Modifier.height(8.dp))
                                            Text("Belum ada riwayat upload.", color = WhiteMuted, fontSize = 13.sp)
                                        }
                                    }
                                }
                            } else {
                                history.forEach { h ->
                                    GoldCard(subtle = true) {
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                                            Column(Modifier.weight(1f)) {
                                                Text(
                                                    "${h.type.uppercase()} · ${h.name}",
                                                    color = WhitePure, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                                                    maxLines = 1, overflow = TextOverflow.Ellipsis
                                                )
                                                Spacer(Modifier.height(4.dp))
                                                Text("ID: ${h.id}", color = GoldAccent, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                                Spacer(Modifier.height(3.dp))
                                                Text(h.status, color = WhiteMuted, fontSize = 11.sp, lineHeight = 15.sp)
                                            }
                                            Spacer(Modifier.width(8.dp))
                                            if (h.pending) {
                                                StatusChip("PENDING", GoldPrimary)
                                            } else {
                                                StatusChip("SELESAI", SuccessGreen)
                                            }
                                        }
                                        if (h.pending && h.operationId.isNotBlank()) {
                                            Spacer(Modifier.height(10.dp))
                                            OutlinedButton(
                                                onClick = {
                                                    if (apiKey.isBlank()) {
                                                        scope.launch { snackbar.showSnackbar("Isi API Key dulu di menu Akun") }
                                                    } else {
                                                        pollOperation(apiKey.trim(), h.operationId, h.id)
                                                    }
                                                },
                                                Modifier.fillMaxWidth(),
                                                border = ButtonDefaults.outlinedButtonBorder.copy(
                                                    brush = Brush.linearGradient(listOf(GoldPrimary, GoldDark))
                                                )
                                            ) {
                                                Icon(Icons.Default.Refresh, null, tint = GoldAccent, modifier = Modifier.size(14.dp))
                                                Spacer(Modifier.width(6.dp))
                                                Text("CEK STATUS LAGI", color = GoldAccent, fontSize = 12.sp)
                                            }
                                        }
                                    }
                                }
                                OutlinedButton(
                                    onClick = { persistHistory(emptyList()) },
                                    Modifier.fillMaxWidth(),
                                    colors = ButtonColors(
                                        containerColor = ErrorRed.copy(alpha = 0.07f),
                                        contentColor = ErrorRed,
                                        disabledContainerColor = Color.Transparent,
                                        disabledContentColor = GrayDim
                                    )
                                ) {
                                    Icon(Icons.Default.Delete, null, tint = ErrorRed, modifier = Modifier.size(14.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("HAPUS SEMUA RIWAYAT", color = ErrorRed, fontSize = 12.sp)
                                }
                            }
                        }

                        // ═══ PAGE: ACCOUNT ════════════════════════════════
                        Page.Account -> {
                            Text("Akun Roblox", color = WhitePure, fontSize = 22.sp, fontWeight = FontWeight.Black)
                            Text("API Key dienkripsi di Android Keystore", color = WhiteMuted, fontSize = 12.sp)
                            Spacer(Modifier.height(16.dp))

                            if (!accountUnlocked) {
                                GoldCard {
                                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Box(
                                                Modifier.size(64.dp).clip(CircleShape)
                                                    .background(GoldPrimary.copy(alpha = 0.1f))
                                                    .border(1.dp, GoldPrimary.copy(alpha = 0.4f), CircleShape),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(Icons.Default.Lock, null, tint = GoldPrimary, modifier = Modifier.size(30.dp))
                                            }
                                            Spacer(Modifier.height(14.dp))
                                            Text("Halaman ini terkunci", color = WhitePure, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                            Spacer(Modifier.height(6.dp))
                                            Text(
                                                "Verifikasi sidik jari / PIN untuk membuka dan mengubah API Key.",
                                                color = WhiteMuted, fontSize = 12.sp, textAlign = TextAlign.Center
                                            )
                                            Spacer(Modifier.height(20.dp))
                                            Button(
                                                onClick = {
                                                    BiometricHelper.authenticate(activity) { result ->
                                                        when (result) {
                                                            is BiometricHelper.BiometricResult.Success -> accountUnlocked = true
                                                            is BiometricHelper.BiometricResult.Unavailable -> {
                                                                accountUnlocked = true
                                                                scope.launch { snackbar.showSnackbar("Kunci layar belum diatur di perangkat ini") }
                                                            }
                                                            is BiometricHelper.BiometricResult.Failed -> {
                                                                scope.launch { snackbar.showSnackbar("Verifikasi gagal: ${result.reason}") }
                                                            }
                                                        }
                                                    }
                                                },
                                                Modifier.fillMaxWidth(),
                                                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                                                contentPadding = PaddingValues(0.dp)
                                            ) {
                                                Box(
                                                    Modifier.fillMaxWidth().height(50.dp)
                                                        .background(GoldBrush, RoundedCornerShape(14.dp)),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        Icon(Icons.Default.Fingerprint, null, tint = BgDeep, modifier = Modifier.size(18.dp))
                                                        Spacer(Modifier.width(8.dp))
                                                        Text("BUKA DENGAN BIOMETRIK / PIN", color = BgDeep, fontWeight = FontWeight.Black)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            } else {
                                GoldCard {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Key, null, tint = GoldAccent, modifier = Modifier.size(20.dp))
                                        Spacer(Modifier.width(8.dp))
                                        Text("API KEY & CREATOR ID", color = GoldAccent, fontSize = 12.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                                    }
                                    Spacer(Modifier.height(14.dp))
                                    OutlinedTextField(
                                        apiKey, { apiKey = it }, Modifier.fillMaxWidth(),
                                        label = { Text("Roblox Open Cloud API Key") },
                                        singleLine = true,
                                        visualTransformation = if (apiKeyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                        trailingIcon = {
                                            IconButton(onClick = { apiKeyVisible = !apiKeyVisible }) {
                                                Icon(if (apiKeyVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility, null, tint = WhiteMuted)
                                            }
                                        },
                                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = GoldPrimary, unfocusedBorderColor = GrayDim.copy(alpha = 0.5f))
                                    )
                                    Spacer(Modifier.height(10.dp))
                                    OutlinedTextField(
                                        creator, { creator = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(),
                                        label = { Text("Creator User ID") }, singleLine = true,
                                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = GoldPrimary, unfocusedBorderColor = GrayDim.copy(alpha = 0.5f))
                                    )
                                    Spacer(Modifier.height(14.dp))
                                    Button(
                                        onClick = {
                                            prefs.edit().putString("api_key", apiKey.trim()).putString("creator_id", creator.trim()).apply()
                                            scope.launch { snackbar.showSnackbar("Akun tersimpan terenkripsi di perangkat") }
                                        },
                                        Modifier.fillMaxWidth(),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                                        contentPadding = PaddingValues(0.dp)
                                    ) {
                                        Box(
                                            Modifier.fillMaxWidth().height(46.dp)
                                                .background(GoldBrush, RoundedCornerShape(12.dp)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.Save, null, tint = BgDeep, modifier = Modifier.size(16.dp))
                                                Spacer(Modifier.width(8.dp))
                                                Text("SIMPAN AKUN", color = BgDeep, fontWeight = FontWeight.Black)
                                            }
                                        }
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    OutlinedButton(
                                        onClick = {
                                            SecureStore.wipeAccount(context)
                                            apiKey = ""; creator = ""
                                            scope.launch { snackbar.showSnackbar("API Key dihapus dari perangkat") }
                                        },
                                        Modifier.fillMaxWidth(),
                                        border = ButtonDefaults.outlinedButtonBorder.copy(
                                            brush = Brush.linearGradient(listOf(ErrorRed.copy(alpha = 0.6f), ErrorRed.copy(alpha = 0.3f)))
                                        )
                                    ) { Text("HAPUS API KEY DARI PERANGKAT", color = ErrorRed) }
                                    Spacer(Modifier.height(8.dp))
                                    Text(
                                        "Buat API Key di Creator Dashboard dengan izin asset:write. Jangan bagikan API Key kepada siapapun.",
                                        color = WhiteMuted, fontSize = 11.sp, lineHeight = 16.sp
                                    )
                                }

                                // VIP Card
                                GoldCard {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Star, null, tint = GoldPrimary, modifier = Modifier.size(20.dp))
                                        Spacer(Modifier.width(8.dp))
                                        Text("VIP — Upload Tak Terbatas", color = GoldPrimary, fontSize = 14.sp, fontWeight = FontWeight.Black)
                                    }
                                    Spacer(Modifier.height(12.dp))
                                    if (isVip) {
                                        Box(
                                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                                .background(GoldPrimary.copy(alpha = 0.08f))
                                                .border(1.dp, GoldPrimary.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                                .padding(14.dp)
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.CheckCircle, null, tint = GoldPrimary, modifier = Modifier.size(20.dp))
                                                Spacer(Modifier.width(10.dp))
                                                Text("VIP AKTIF — Upload tanpa batas harian.", color = GoldLight, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                        Spacer(Modifier.height(10.dp))
                                        OutlinedButton(
                                            onClick = {
                                                UploadLimit.clearVipKey(context)
                                                vipKeyInput = ""
                                                refreshLimit()
                                                scope.launch { snackbar.showSnackbar("VIP dinonaktifkan.") }
                                            },
                                            Modifier.fillMaxWidth()
                                        ) { Text("HAPUS VIP KEY") }
                                    } else {
                                        Text("User biasa: maks ${UploadLimit.DAILY_LIMIT} upload per 24 jam. Aktifkan VIP untuk upload tanpa batas.", color = WhiteMuted, fontSize = 12.sp)
                                        Spacer(Modifier.height(12.dp))
                                        OutlinedTextField(
                                            vipKeyInput, { vipKeyInput = it }, Modifier.fillMaxWidth(),
                                            label = { Text("VIP Key") }, singleLine = true,
                                            visualTransformation = if (vipKeyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                            trailingIcon = {
                                                IconButton(onClick = { vipKeyVisible = !vipKeyVisible }) {
                                                    Icon(if (vipKeyVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility, null, tint = WhiteMuted)
                                                }
                                            },
                                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = GoldPrimary, unfocusedBorderColor = GrayDim.copy(alpha = 0.5f))
                                        )
                                        Spacer(Modifier.height(12.dp))
                                        Button(
                                            onClick = {
                                                if (vipKeyInput.trim().uppercase() == UploadLimit.VIP_KEY_VALUE) {
                                                    UploadLimit.saveVipKey(context, vipKeyInput)
                                                    refreshLimit()
                                                    scope.launch { snackbar.showSnackbar("VIP aktif! Upload tak terbatas.") }
                                                } else {
                                                    scope.launch { snackbar.showSnackbar("VIP Key tidak valid. Hubungi owner untuk mendapatkan key.") }
                                                }
                                            },
                                            Modifier.fillMaxWidth(),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                                            contentPadding = PaddingValues(0.dp)
                                        ) {
                                            Box(
                                                Modifier.fillMaxWidth().height(50.dp)
                                                    .background(GoldBrush, RoundedCornerShape(14.dp)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(Icons.Default.Star, null, tint = BgDeep, modifier = Modifier.size(16.dp))
                                                    Spacer(Modifier.width(8.dp))
                                                    Text("AKTIFKAN VIP", color = BgDeep, fontWeight = FontWeight.Black)
                                                }
                                            }
                                        }
                                        Spacer(Modifier.height(6.dp))
                                        Text("Hubungi owner di tab Bantuan untuk membeli VIP Key.", color = WhiteMuted, fontSize = 11.sp)
                                    }
                                }
                            }
                        }

                        // ═══ PAGE: HELP ═══════════════════════════════════
                        Page.Help -> {
                            Text("Bantuan", color = WhitePure, fontSize = 22.sp, fontWeight = FontWeight.Black)
                            Text("Panduan penggunaan & kontak owner", color = WhiteMuted, fontSize = 12.sp)
                            Spacer(Modifier.height(16.dp))

                            GoldCard {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CloudUpload, null, tint = GoldAccent, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text("CARA UPLOAD", color = GoldAccent, fontSize = 12.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                                }
                                Spacer(Modifier.height(14.dp))
                                data class HelpStep(val num: String, val title: String, val desc: String)
                                listOf(
                                    HelpStep("1", "Setup Akun", "Buka menu Akun → verifikasi biometrik/PIN → isi API Key & Creator User ID."),
                                    HelpStep("2", "Pilih Tipe Asset", "Pilih Audio untuk musik/suara, atau Decal untuk gambar PNG/JPG."),
                                    HelpStep("3a", "Mode File", "Tab File → tap area pilih file → pilih audio/gambar dari penyimpanan HP."),
                                    HelpStep("3b", "Mode Link", "Tab Link → paste URL TikTok → sistem otomatis download audio."),
                                    HelpStep("4", "Atur Speed", "Pilih speed 0.5× sampai 2.0× — speed diterapkan ke file sebelum upload, jadi Roblox akan play dengan speed itu."),
                                    HelpStep("5", "Cek Durasi", "Durasi musik otomatis tampil setelah file dipilih / link diproses. Durasi di Roblox = durasi asli ÷ speed yang dipilih."),
                                    HelpStep("6", "Upload", "Isi Display Name → tekan UPLOAD ASSET → tunggu konfirmasi Asset ID."),
                                    HelpStep("7", "Cek Status", "Kalau masih 'Diproses', buka tab History → tekan CEK STATUS LAGI.")
                                ).forEach { s ->
                                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.Top) {
                                        Box(
                                            Modifier.size(28.dp).clip(RoundedCornerShape(9.dp))
                                                .background(GoldPrimary.copy(alpha = 0.12f))
                                                .border(1.dp, GoldDark.copy(alpha = 0.4f), RoundedCornerShape(9.dp)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(s.num, color = GoldPrimary, fontSize = 10.sp, fontWeight = FontWeight.Black)
                                        }
                                        Spacer(Modifier.width(10.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(s.title, color = WhitePure, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            Text(s.desc, color = WhiteMuted, fontSize = 11.sp, lineHeight = 16.sp)
                                        }
                                    }
                                }
                                Spacer(Modifier.height(8.dp))
                                HorizontalDivider(color = GoldDark.copy(alpha = 0.2f))
                                Spacer(Modifier.height(8.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Security, null, tint = GrayDim, modifier = Modifier.size(13.dp))
                                    Spacer(Modifier.width(5.dp))
                                    Text("API Key tersimpan terenkripsi via Android Keystore & dikunci biometrik/PIN.", color = WhiteMuted, fontSize = 10.sp, lineHeight = 15.sp)
                                }
                            }

                            GoldCard(subtle = true) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Speed, null, tint = GoldPrimary, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text("FITUR SPEED & DURASI", color = GoldPrimary, fontSize = 12.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                                }
                                Spacer(Modifier.height(12.dp))
                                InfoRow(Icons.Default.Speed, GoldPrimary, "Speed 0.5× sampai 2.0× — diterapkan ke file WAV (sample rate rewrite), bukan sekedar playback preview.")
                                InfoRow(Icons.Default.Timer, GoldAccent, "Durasi otomatis terbaca dari file yang dipilih. Durasi di Roblox = durasi asli ÷ speed.")
                                InfoRow(Icons.Default.Info, GrayDim, "Untuk MP3, di-decode ke WAV lalu sample rate disesuaikan agar kompatibel dengan Roblox.")
                            }

                            GoldCard(subtle = true) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CloudUpload, null, tint = GoldAccent, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text("LIMIT UPLOAD", color = GoldAccent, fontSize = 12.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                                }
                                Spacer(Modifier.height(12.dp))
                                InfoRow(Icons.Default.Person, WhiteMuted, "User biasa: maks ${UploadLimit.DAILY_LIMIT} upload per 24 jam (rolling window).")
                                InfoRow(Icons.Default.Timer, GoldAccent, "Countdown real-time tampil otomatis di header saat limit tercapai.")
                                InfoRow(Icons.Default.Refresh, WhiteMuted, "Slot terbuka tepat 24 jam setelah upload dilakukan (bukan reset midnight).")
                                InfoRow(Icons.Default.Star, GoldPrimary, "User VIP: upload tak terbatas, tidak ada limit harian.")
                                InfoRow(Icons.Default.ShoppingCart, GoldPrimary, "VIP Key bisa dibeli langsung dari owner.")
                            }

                            GoldCard {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.ContactPhone, null, tint = GoldPrimary, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text("KONTAK OWNER", color = GoldPrimary, fontSize = 12.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                                }
                                Spacer(Modifier.height(14.dp))
                                Row(
                                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                                        .background(SuccessGreen.copy(alpha = 0.05f))
                                        .border(1.dp, SuccessGreen.copy(alpha = 0.2f), RoundedCornerShape(14.dp))
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        Modifier.size(38.dp).clip(RoundedCornerShape(10.dp)).background(SuccessGreen.copy(alpha = 0.12f)),
                                        contentAlignment = Alignment.Center
                                    ) { Icon(Icons.Default.Phone, null, tint = SuccessGreen, modifier = Modifier.size(18.dp)) }
                                    Spacer(Modifier.width(12.dp))
                                    Column {
                                        Text("WhatsApp / No. HP", color = WhiteMuted, fontSize = 10.sp)
                                        Text("082324919412", color = WhitePure, fontWeight = FontWeight.Black, fontSize = 16.sp)
                                    }
                                }
                                Spacer(Modifier.height(8.dp))
                                Row(
                                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                                        .background(Color(0xFF7289DA).copy(alpha = 0.05f))
                                        .border(1.dp, Color(0xFF7289DA).copy(alpha = 0.2f), RoundedCornerShape(14.dp))
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        Modifier.size(38.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF7289DA).copy(alpha = 0.12f)),
                                        contentAlignment = Alignment.Center
                                    ) { Icon(Icons.Default.Chat, null, tint = Color(0xFF7289DA), modifier = Modifier.size(18.dp)) }
                                    Spacer(Modifier.width(12.dp))
                                    Column {
                                        Text("Discord", color = WhiteMuted, fontSize = 10.sp)
                                        Text("reyytzyyy", color = WhitePure, fontWeight = FontWeight.Black, fontSize = 16.sp)
                                    }
                                }
                                Spacer(Modifier.height(10.dp))
                                Row(
                                    Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                                        .background(GoldPrimary.copy(alpha = 0.06f)).padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Info, null, tint = GoldDark.copy(alpha = 0.8f), modifier = Modifier.size(13.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Hubungi owner untuk membeli VIP Key atau melaporkan bug.", color = GoldLight.copy(alpha = 0.8f), fontSize = 11.sp)
                                }
                            }

                            Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                                Text("Rexyy Uploader v4.0 — Roblox Asset Uploader", color = GrayDim.copy(alpha = 0.5f), fontSize = 10.sp)
                            }
                        }
                    }

                    Spacer(Modifier.height(20.dp))
                }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// HISTORY SERIALIZATION — tidak berubah sama sekali
// ═══════════════════════════════════════════════════════════════
private fun saveHistory(items: List<HistoryItem>) = org.json.JSONArray().apply {
    items.take(100).forEach {
        put(
            JSONObject()
                .put("type", it.type).put("name", it.name).put("id", it.id)
                .put("status", it.status).put("date", it.date)
                .put("operationId", it.operationId).put("pending", it.pending)
        )
    }
}.toString()

private fun loadHistory(raw: String): List<HistoryItem> {
    return try {
        val a = org.json.JSONArray(raw)
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            HistoryItem(
                o.optString("type"), o.optString("name"), o.optString("id"),
                o.optString("status"), o.optString("date"),
                o.optString("operationId"), o.optBoolean("pending", false)
            )
        }
    } catch (_: Exception) { emptyList() }
}
