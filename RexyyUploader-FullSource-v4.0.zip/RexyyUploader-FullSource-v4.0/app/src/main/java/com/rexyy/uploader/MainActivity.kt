package com.rexyy.uploader

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaPlayer
import java.nio.ByteBuffer
import java.nio.ByteOrder
import android.net.Uri
import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import com.rexyy.uploader.audio.AudioProcessor
import com.rexyy.uploader.network.LinkDownloader
import com.rexyy.uploader.network.RobloxAssetUploader
import com.rexyy.uploader.security.BiometricHelper
import com.rexyy.uploader.security.SecureStore
import androidx.compose.foundation.Canvas
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.DrawScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

// ===== Palet warna "premium" (ungu -> teal, kaya aliran air bercahaya) =====
private val Bg = Color(0xFF07080D)
private val Panel = Color(0xFF14151D)
private val Purple = Color(0xFF9B6CFF)
private val Teal = Color(0xFF4FE3C1)
private val Pink = Color(0xFFFF6CAE)
private val Gold = Color(0xFFFFD166)
private val Muted = Color(0xFF9BA1B2)
// Subtle glow colors untuk border efek premium
private val BorderGlowStart = Color(0xFF9B6CFF)   // purple
private val BorderGlowEnd   = Color(0xFF4FE3C1)   // teal

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RexyyApp() }
    }
}

private enum class Page(val label: String) {
    Upload("Upload"), History("History"), Account("Akun"), Help("Bantuan")
}

private data class HistoryItem(
    val type: String,
    val name: String,
    val id: String,
    val status: String,
    val date: String,
    val operationId: String = "",
    val pending: Boolean = false
)

private fun getFileNameFromUri(context: Context, uri: Uri): String {
    var result = ""
    if (uri.scheme == "content") {
        val cursor = context.contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                val idx = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) result = it.getString(idx)
            }
        }
    }
    if (result.isBlank()) {
        result = uri.lastPathSegment?.substringAfterLast('/') ?: "File dipilih"
    }
    return result
}

/**
 * Border premium statis: gradient diagonal purple → teal, transparan di sudut,
 * solid di tengah sisi. Tidak muter, tidak kedap-kedip — clean & keren.
 */
@Composable
private fun Modifier.premiumBorder(cornerRadius: Dp = 20.dp, strokeWidth: Dp = 1.5.dp): Modifier =
    this.border(
        width = strokeWidth,
        brush = Brush.linearGradient(
            colors = listOf(
                BorderGlowStart.copy(alpha = 0.85f),
                BorderGlowEnd.copy(alpha = 0.60f),
                BorderGlowStart.copy(alpha = 0.25f),
            )
        ),
        shape = RoundedCornerShape(cornerRadius)
    )

@Composable
private fun AnimatedAmbientBackground(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "bg-flow")
    val shift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse),
        label = "shift"
    )
    Box(
        modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    colors = listOf(Bg, Color(0xFF13101D), Bg, Color(0xFF0C1715), Bg),
                    start = androidx.compose.ui.geometry.Offset(0f, 1200f * shift),
                    end = androidx.compose.ui.geometry.Offset(1200f * (1f - shift), 0f)
                )
            )
    )
}

@Composable
private fun RexyyApp() {
    val context = LocalContext.current
    val activity = context as FragmentActivity
    val prefs = remember { SecureStore.get(context) }

    var page by remember { mutableStateOf(Page.Upload) }
    var type by remember { mutableStateOf("Audio") }
    var uri by remember { mutableStateOf<Uri?>(null) }
    var fileName by remember { mutableStateOf("") }

    var apiKey by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
    var creator by remember { mutableStateOf(prefs.getString("creator_id", "") ?: "") }
    var apiKeyVisible by remember { mutableStateOf(false) }
    var accountUnlocked by remember { mutableStateOf(false) }

    // VIP state — dibaca ulang setiap kali halaman Account dibuka / VIP key disimpan
    var isVip by remember { mutableStateOf(UploadLimit.isVip(context)) }
    var vipKeyInput by remember { mutableStateOf("") }
    var vipKeyVisible by remember { mutableStateOf(false) }

    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("Uploaded via Rexyy Uploader") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var history by remember { mutableStateOf(loadHistory(prefs.getString("history", "[]") ?: "[]")) }

    // Upload limit badge — di-refresh setiap recompose (lightweight read dari prefs)
    var uploadBadge by remember { mutableStateOf(UploadLimit.badgeText(context)) }

    var selectedSpeed by remember { mutableStateOf(1.0f) }
    var selectedVolume by remember { mutableStateOf(1.0f) }   // gain multiplier 0f–1.5f slider
    var selectedFilter by remember { mutableStateOf("Normal") }
    var audioProgressMs by remember { mutableStateOf(0L) }
    var audioDurationMs by remember { mutableStateOf(0L) }
    var fileSizeBytes by remember { mutableStateOf(0L) }
    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    var isPlaying by remember { mutableStateOf(false) }

    // ===== State fitur Link (TikTok) =====
    var uploadMode by remember { mutableStateOf("File") } // "File" atau "Link"
    var linkPlatform by remember { mutableStateOf("TikTok") } // Link import hanya TikTok
    var linkInput by remember { mutableStateOf("") }
    var linkStatus by remember { mutableStateOf("") }

    // State khusus Link mode: audio yang sudah didownload (untuk preview & speed)
    var linkAudioBytes by remember { mutableStateOf<ByteArray?>(null) }
    var linkAudioMime  by remember { mutableStateOf("audio/mpeg") }
    var linkAudioName  by remember { mutableStateOf("audio.mp3") }
    var linkMediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    var linkIsPlaying  by remember { mutableStateOf(false) }
    var linkFetching   by remember { mutableStateOf(false) } // sedang fetch audio dari server
    var linkSelectedSpeed by remember { mutableStateOf(1.0f) }
    var linkSelectedVolume by remember { mutableStateOf(1.0f) }
    var linkSelectedFilter by remember { mutableStateOf("Normal") }
    var linkAudioProgressMs by remember { mutableStateOf(0L) }
    var linkAudioDurationMs by remember { mutableStateOf(0L) }

    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    fun refreshLimit() {
        isVip = UploadLimit.isVip(context)
        uploadBadge = UploadLimit.badgeText(context)
    }

    fun persistHistory(new: List<HistoryItem>) {
        history = new
        prefs.edit().putString("history", saveHistory(new)).apply()
    }

    fun pollOperation(apiKeyTrim: String, operationId: String, historyIndexId: String) {
        scope.launch {
            var found = ""
            var lastRaw = ""
            var done = false
            repeat(24) { attempt ->
                if (found.isBlank() && !done) {
                    kotlinx.coroutines.delay(3000)
                    try {
                        lastRaw = withContext(Dispatchers.IO) {
                            RobloxAssetUploader(context).checkOperation(apiKeyTrim, operationId)
                        }
                        val j = JSONObject(lastRaw)
                        done = j.optBoolean("done", false)
                        val response = j.optJSONObject("response")
                        found = response?.optString("assetId").orEmpty()
                        status = when {
                            found.isNotBlank() -> "Selesai • Asset ID: $found"
                            done -> "Operasi selesai di Roblox, menunggu Asset ID muncul…"
                            else -> "Memproses upload… (percobaan ${attempt + 1}/24)"
                        }
                    } catch (e: Exception) {
                        status = "Gagal cek status: ${e.message ?: "tidak diketahui"}"
                    }
                }
            }
            val finalStatus = when {
                found.isNotBlank() -> "Selesai • Asset ID: $found"
                done -> "Diproses Roblox, menunggu Asset ID (cek Creator Dashboard atau tekan Cek status lagi)"
                else -> "Masih diproses Roblox (moderasi bisa lebih lama dari 72 detik) — tekan Cek status lagi nanti"
            }
            status = finalStatus
            val updated = history.map {
                if (it.id == historyIndexId) it.copy(
                    id = found.ifBlank { it.id },
                    status = finalStatus,
                    pending = found.isBlank()
                ) else it
            }
            persistHistory(updated)
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { picked ->
        if (picked != null) {
            uri = picked
            fileName = getFileNameFromUri(context, picked)
            val nameWithoutExt = fileName.substringBeforeLast('.').ifBlank { fileName }
            name = nameWithoutExt
            try {
                context.contentResolver.takePersistableUriPermission(
                    picked, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            // Read file size
            try {
                val pfd = context.contentResolver.openFileDescriptor(picked, "r")
                fileSizeBytes = pfd?.statSize ?: 0L
                pfd?.close()
            } catch (_: Exception) { fileSizeBytes = 0L }
            // Read duration via MediaPlayer
            try {
                val mp = MediaPlayer()
                mp.setDataSource(context, picked)
                mp.prepare()
                audioDurationMs = mp.duration.toLong()
                mp.release()
            } catch (_: Exception) { audioDurationMs = 0L }
            audioProgressMs = 0L
            mediaPlayer?.release()
            mediaPlayer = null
            isPlaying = false
        }
    }

    // Progress ticker — updates audioProgressMs every 500ms when playing
    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            delay(500L)
            audioProgressMs = mediaPlayer?.currentPosition?.toLong() ?: audioProgressMs
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            mediaPlayer?.release()
            mediaPlayer = null
            linkMediaPlayer?.release()
            linkMediaPlayer = null
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Bg, surface = Panel)) {
        Box(Modifier.fillMaxSize()) {
            AnimatedAmbientBackground()
            Scaffold(
                containerColor = Color.Transparent,
                snackbarHost = { SnackbarHost(snackbar) },
                bottomBar = {
                    NavigationBar(containerColor = Color(0xFF0E0F16)) {
                        Page.values().forEach { p ->
                            NavigationBarItem(
                                selected = page == p,
                                onClick = { page = p; refreshLimit() },
                                icon = {
                                    Icon(
                                        when (p) {
                                            Page.Upload -> Icons.Default.CloudUpload
                                            Page.History -> Icons.Default.History
                                            Page.Account -> Icons.Default.Shield
                                            Page.Help -> Icons.Default.Help
                                        }, null
                                    )
                                },
                                label = { Text(p.label, fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Teal, selectedTextColor = Teal,
                                    indicatorColor = Color(0xFF1B1E29)
                                )
                            )
                        }
                    }
                }
            ) { pad ->
                Column(
                    Modifier
                        .fillMaxSize()
                        .padding(pad)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp)
                ) {
                    // ===== Header =====
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Image(
                                painter = painterResource(id = R.drawable.rexyy_logo),
                                contentDescription = "Logo REXYY",
                                modifier = Modifier.size(58.dp).clip(RoundedCornerShape(12.dp)),
                                contentScale = ContentScale.Crop
                            )
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(
                                    "REXYY",
                                    fontSize = 25.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White,
                                    letterSpacing = 3.sp
                                )
                                Text("ROBLOX ASSET UPLOADER", fontSize = 10.sp, color = Muted, letterSpacing = 1.sp)
                            }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (apiKey.isBlank()) Color(0xFF2A2412) else Color(0xFF123023))
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    if (apiKey.isBlank()) "BELUM TERHUBUNG" else "API KEY TERSIMPAN AMAN",
                                    color = if (apiKey.isBlank()) Color(0xFFFFC56A) else Teal,
                                    fontSize = 10.sp, fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(Modifier.height(4.dp))
                            // Badge upload limit / VIP
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isVip) Color(0xFF1A1500) else Color(0xFF1A1020))
                                    .padding(horizontal = 10.dp, vertical = 5.dp)
                            ) {
                                Text(
                                    uploadBadge,
                                    color = if (isVip) Gold else Purple,
                                    fontSize = 10.sp, fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(20.dp))

                    when (page) {

                        // ===================================================
                        // PAGE: ACCOUNT
                        // ===================================================
                        Page.Account -> {
                            Title("Akun Roblox", "API Key dienkripsi di perangkat (Android Keystore).")
                            if (!accountUnlocked) {
                                CardBox {
                                    Icon(Icons.Default.Lock, null, tint = Purple, modifier = Modifier.size(28.dp))
                                    Spacer(Modifier.height(8.dp))
                                    Text("Halaman ini terkunci", color = Color.White, fontWeight = FontWeight.Bold)
                                    Text(
                                        "Verifikasi sidik jari/PIN layar kunci untuk melihat atau mengubah API Key.",
                                        color = Muted, fontSize = 12.sp
                                    )
                                    Spacer(Modifier.height(10.dp))
                                    Button(
                                        onClick = {
                                            BiometricHelper.authenticate(activity) { result ->
                                                when (result) {
                                                    is BiometricHelper.BiometricResult.Success -> accountUnlocked = true
                                                    is BiometricHelper.BiometricResult.Unavailable -> {
                                                        accountUnlocked = true
                                                        scope.launch { snackbar.showSnackbar("Kunci layar belum diatur di perangkat ini") }
                                                    }
                                                    is BiometricHelper.BiometricResult.Failed -> {
                                                        scope.launch { snackbar.showSnackbar("Verifikasi gagal: ${result.reason}") }
                                                    }
                                                }
                                            }
                                        },
                                        Modifier.fillMaxWidth()
                                    ) { Text("BUKA DENGAN SIDIK JARI / PIN") }
                                }
                            } else {
                                // --- API Key & Creator ID ---
                                CardBox {
                                    OutlinedTextField(
                                        apiKey, { apiKey = it }, Modifier.fillMaxWidth(),
                                        label = { Text("Roblox Open Cloud API Key") },
                                        singleLine = true,
                                        visualTransformation = if (apiKeyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                        trailingIcon = {
                                            IconButton(onClick = { apiKeyVisible = !apiKeyVisible }) {
                                                Icon(if (apiKeyVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility, null)
                                            }
                                        }
                                    )
                                    Spacer(Modifier.height(10.dp))
                                    OutlinedTextField(
                                        creator, { creator = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(),
                                        label = { Text("Creator User ID") }, singleLine = true
                                    )
                                    Spacer(Modifier.height(12.dp))
                                    Button(onClick = {
                                        prefs.edit().putString("api_key", apiKey.trim()).putString("creator_id", creator.trim()).apply()
                                        scope.launch { snackbar.showSnackbar("Akun tersimpan terenkripsi di perangkat") }
                                    }, Modifier.fillMaxWidth()) { Text("SIMPAN AKUN") }
                                    Spacer(Modifier.height(8.dp))
                                    OutlinedButton(
                                        onClick = {
                                            SecureStore.wipeAccount(context)
                                            apiKey = ""; creator = ""
                                            scope.launch { snackbar.showSnackbar("API Key dihapus dari perangkat") }
                                        },
                                        Modifier.fillMaxWidth()
                                    ) { Text("HAPUS API KEY DARI PERANGKAT") }
                                    Text(
                                        "Buat API Key di Creator Dashboard dengan izin asset:write. Jangan bagikan API Key kepada siapa pun.",
                                        color = Muted, fontSize = 11.sp
                                    )
                                }

                                Spacer(Modifier.height(4.dp))

                                // --- VIP Section ---
                                CardBox {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Star, null, tint = Gold, modifier = Modifier.size(20.dp))
                                        Spacer(Modifier.width(8.dp))
                                        Text("VIP — Upload Tak Terbatas", color = Gold, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    }
                                    Spacer(Modifier.height(6.dp))
                                    if (isVip) {
                                        Box(
                                            Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(Color(0xFF1A1500))
                                                .padding(12.dp)
                                        ) {
                                            Text("✓ VIP AKTIF — Tidak ada batas upload harian.", color = Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        }
                                        Spacer(Modifier.height(10.dp))
                                        OutlinedButton(
                                            onClick = {
                                                UploadLimit.clearVipKey(context)
                                                vipKeyInput = ""
                                                refreshLimit()
                                                scope.launch { snackbar.showSnackbar("VIP dinonaktifkan.") }
                                            },
                                            Modifier.fillMaxWidth()
                                        ) { Text("HAPUS VIP KEY") }
                                    } else {
                                        Text(
                                            "User biasa: maks ${UploadLimit.DAILY_LIMIT} upload per 24 jam. Aktifkan VIP untuk upload tanpa batas.",
                                            color = Muted, fontSize = 12.sp
                                        )
                                        Spacer(Modifier.height(10.dp))
                                        OutlinedTextField(
                                            vipKeyInput, { vipKeyInput = it }, Modifier.fillMaxWidth(),
                                            label = { Text("VIP Key") },
                                            singleLine = true,
                                            visualTransformation = if (vipKeyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                            trailingIcon = {
                                                IconButton(onClick = { vipKeyVisible = !vipKeyVisible }) {
                                                    Icon(if (vipKeyVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility, null)
                                                }
                                            }
                                        )
                                        Spacer(Modifier.height(10.dp))
                                        Button(
                                            onClick = {
                                                if (vipKeyInput.trim().uppercase() == UploadLimit.VIP_KEY_VALUE) {
                                                    UploadLimit.saveVipKey(context, vipKeyInput)
                                                    refreshLimit()
                                                    scope.launch { snackbar.showSnackbar("VIP aktif! Upload tak terbatas.") }
                                                } else {
                                                    scope.launch { snackbar.showSnackbar("VIP Key tidak valid. Hubungi owner untuk mendapatkan key.") }
                                                }
                                            },
                                            Modifier.fillMaxWidth(),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2A2000))
                                        ) {
                                            Icon(Icons.Default.Star, null, tint = Gold, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(8.dp))
                                            Text("AKTIFKAN VIP", color = Gold, fontWeight = FontWeight.Bold)
                                        }
                                        Spacer(Modifier.height(6.dp))
                                        Text(
                                            "Untuk membeli VIP, hubungi owner di kontak yang tersedia di tab Bantuan.",
                                            color = Muted, fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                        }

                        // ===================================================
                        // PAGE: UPLOAD
                        // ===================================================
                        Page.Upload -> {
                            Title("Upload asset Roblox", "Kirim Audio atau Decal ke akun/creator yang kamu atur.")

                            // Banner limit / VIP
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isVip) Color(0xFF1A1500) else Color(0xFF1A1020))
                                    .padding(horizontal = 14.dp, vertical = 10.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        if (isVip) Icons.Default.Star else Icons.Default.CloudUpload,
                                        null,
                                        tint = if (isVip) Gold else Purple,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text(uploadBadge, color = if (isVip) Gold else Purple, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Spacer(Modifier.height(10.dp))

                            // Countdown timer — hanya muncul kalau limit habis
                            val limitMs = UploadLimit.millisUntilNextSlot(context)
                            if (!isVip && limitMs > 0L) {
                                LimitCountdownCard(context = context, onLimitReset = { refreshLimit() })
                                Spacer(Modifier.height(10.dp))
                            }

                            CardBox {
                                // ── Tab: Audio / Decal ──
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("Audio", "Decal").forEach { t ->
                                        FilterButton(t, type == t, Modifier.weight(1f)) {
                                            type = t
                                            uri = null; fileName = ""; name = ""
                                            linkInput = ""; linkStatus = ""; linkPlatform = "TikTok"
                                            linkAudioBytes = null
                                            audioProgressMs = 0L; audioDurationMs = 0L; fileSizeBytes = 0L
                                            selectedFilter = "Normal"; selectedSpeed = 1.0f; selectedVolume = 1.0f
                                            linkSelectedFilter = "Normal"; linkSelectedSpeed = 1.0f; linkSelectedVolume = 1.0f
                                            mediaPlayer?.release(); mediaPlayer = null; isPlaying = false
                                            linkMediaPlayer?.release(); linkMediaPlayer = null; linkIsPlaying = false
                                        }
                                    }
                                }

                                Spacer(Modifier.height(10.dp))

                                // ── Tab: File / Link (hanya untuk Audio) ──
                                if (type == "Audio") {
                                    Row(
                                        Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(Color(0xFF12131C))
                                            .padding(4.dp),
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        listOf("File", "Link").forEach { mode ->
                                            Box(
                                                Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(if (uploadMode == mode) Purple else Color.Transparent)
                                                    .clickable {
                                                        uploadMode = mode
                                                        uri = null; fileName = ""; linkInput = ""; linkStatus = ""; linkPlatform = "TikTok"
                                                        linkAudioBytes = null
                                                        mediaPlayer?.release(); mediaPlayer = null; isPlaying = false
                                                        linkMediaPlayer?.release(); linkMediaPlayer = null; linkIsPlaying = false
                                                    }
                                                    .padding(vertical = 8.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(
                                                        if (mode == "File") Icons.Default.FolderOpen else Icons.Default.Link,
                                                        null,
                                                        tint = if (uploadMode == mode) Color.White else Muted,
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                    Spacer(Modifier.width(5.dp))
                                                    Text(
                                                        mode,
                                                        color = if (uploadMode == mode) Color.White else Muted,
                                                        fontSize = 12.sp,
                                                        fontWeight = if (uploadMode == mode) FontWeight.Bold else FontWeight.Normal
                                                    )
                                                }
                                            }
                                        }
                                    }
                                    Spacer(Modifier.height(12.dp))
                                }

                                // ── Konten berdasarkan mode ──
                                if (type != "Audio" || uploadMode == "File") {
                                    // MODE FILE
                                    // Kalau Audio dan file sudah dipilih, AudioEditorCard yang tampil (di bawah CardBox)
                                    // Tampilkan area pilih file hanya kalau belum ada file, atau tipe Decal
                                    if (type != "Audio" || uri == null) {
                                        Text("FILE ${type.uppercase()}", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Box(
                                            Modifier
                                                .fillMaxWidth()
                                                .premiumBorder(16.dp)
                                                .clip(RoundedCornerShape(16.dp))
                                                .background(Color(0xFF191B26))
                                                .clickable { picker.launch(if (type == "Audio") arrayOf("audio/*") else arrayOf("image/*")) }
                                                .padding(22.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                Icon(
                                                    if (type == "Audio") Icons.Default.MusicNote else Icons.Default.Image,
                                                    null, tint = Teal, modifier = Modifier.size(32.dp)
                                                )
                                                Text(
                                                    if (fileName.isBlank()) "Pilih file dari HP" else fileName,
                                                    color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis
                                                )
                                                Text(
                                                    if (type == "Audio") "Pilih audio yang didukung Roblox" else "Pilih gambar PNG/JPG",
                                                    color = Muted, fontSize = 11.sp
                                                )
                                            }
                                        }
                                    }
                                } else {
                                    // MODE LINK
                                    Text("LINK AUDIO", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.height(8.dp))

                                    // ── Import link hanya TikTok ──
                                    Row(
                                        Modifier.fillMaxWidth()
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(Color(0xFF0E0F18))
                                            .border(1.dp, Color(0xFF69C9D0).copy(alpha = 0.7f), RoundedCornerShape(12.dp))
                                            .padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("♪", color = Color(0xFF69C9D0), fontSize = 16.sp)
                                        Spacer(Modifier.width(8.dp))
                                        Text("TikTok", color = Color(0xFF69C9D0), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        Spacer(Modifier.weight(1f))
                                        Text("IMPORT LINK", color = Muted, fontSize = 10.sp)
                                    }
                                    Spacer(Modifier.height(12.dp))

                                    val platColor = Color(0xFF69C9D0)
                                    val platHint = "Paste link TikTok (tiktok.com / vt.tiktok.com)"

                                    OutlinedTextField(
                                        value = linkInput,
                                        onValueChange = { v ->
                                            linkInput = v
                                            linkStatus = ""
                                            // Reset audio bytes kalau link berubah
                                            linkAudioBytes = null
                                            linkMediaPlayer?.release(); linkMediaPlayer = null; linkIsPlaying = false
                                            // Link yang didukung hanya TikTok.
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        label = { Text(platHint, fontSize = 11.sp) },
                                        singleLine = true,
                                        leadingIcon = {
                                            Text(
                                                "♪",
                                                color = platColor,
                                                fontSize = 14.sp,
                                                modifier = Modifier.padding(start = 4.dp)
                                            )
                                        },
                                        trailingIcon = {
                                            if (linkInput.isNotBlank()) {
                                                IconButton(onClick = { linkInput = ""; linkStatus = "" }) {
                                                    Icon(Icons.Default.Clear, null, tint = Muted)
                                                }
                                            }
                                        }
                                    )

                                    // Status / error message
                                    if (linkStatus.isNotBlank()) {
                                        Spacer(Modifier.height(6.dp))
                                        Text(
                                            linkStatus,
                                            color = when {
                                                linkStatus.startsWith("✓") -> Teal
                                                linkStatus.startsWith("✗") || linkStatus.startsWith("Gagal") -> Color(0xFFFF8B8B)
                                                else -> Muted
                                            },
                                            fontSize = 11.sp
                                        )
                                    }

                                    // Validasi link realtime
                                    if (linkInput.isNotBlank()) {
                                        val detected = LinkDownloader.detectType(linkInput)
                                        Spacer(Modifier.height(4.dp))
                                        when {
                                            detected == LinkDownloader.LinkType.UNSUPPORTED -> {
                                                Text(
                                                    "⚠ Link tidak dikenali. Gunakan link TikTok yang valid.",
                                                    color = Color(0xFFFFC56A), fontSize = 11.sp
                                                )
                                            }
                                            detected == LinkDownloader.LinkType.TIKTOK && linkPlatform == "TikTok" -> {
                                                Text("TikTok terdeteksi ♪", color = Color(0xFF69C9D0), fontSize = 11.sp)
                                            }
                                            detected != LinkDownloader.LinkType.UNSUPPORTED -> {
                                                Text("TikTok terdeteksi ♪", color = Color(0xFF69C9D0), fontSize = 11.sp)
                                            }
                                        }
                                    }

                                    // ── Auto-fetch di background begitu link valid ──
                                    val isLinkValid = linkInput.isNotBlank() &&
                                        LinkDownloader.detectType(linkInput) != LinkDownloader.LinkType.UNSUPPORTED

                                    LaunchedEffect(linkInput) {
                                        if (isLinkValid && linkAudioBytes == null && !linkFetching) {
                                            linkFetching = true
                                            linkStatus = "⏳ Memuat audio…"
                                            try {
                                                val ltype = LinkDownloader.detectType(linkInput)
                                                val dl = withContext(Dispatchers.IO) {
                                                    LinkDownloader.download(linkInput.trim(), ltype)
                                                }
                                                val bytes = withContext(Dispatchers.IO) { dl.stream.use { it.readBytes() } }
                                                linkAudioBytes = bytes
                                                linkAudioMime  = dl.mimeType
                                                linkAudioName  = dl.fileName
                                                linkStatus = "✓ Audio siap (${bytes.size / 1024} KB)"
                                            } catch (e: Exception) {
                                                linkStatus = "✗ Gagal: ${e.message ?: "Error"}"
                                            } finally {
                                                linkFetching = false
                                            }
                                        }
                                    }

                                    // ── Tampil speed + preview setelah link valid (sama persis kayak File mode) ──
                                    if (isLinkValid) {
                                        Spacer(Modifier.height(14.dp))
                                        Divider(color = Color(0xFF2C2F3B))
                                        Spacer(Modifier.height(12.dp))

                                        // Speed selector
                                        Row(
                                            Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.Speed, null, tint = Muted, modifier = Modifier.size(14.dp))
                                                Spacer(Modifier.width(4.dp))
                                                Text("SPEED PLAYBACK", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                            Text("${linkSelectedSpeed}x", color = Teal, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        }
                                        Spacer(Modifier.height(8.dp))
                                        val linkSpeeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f)
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                            linkSpeeds.forEach { spd ->
                                                val isSel = linkSelectedSpeed == spd
                                                Box(
                                                    Modifier
                                                        .weight(1f)
                                                        .background(if (isSel) Teal else Color(0xFF1E212C), RoundedCornerShape(8.dp))
                                                        .border(1.dp, if (isSel) Teal else Color(0xFF34384A), RoundedCornerShape(8.dp))
                                                        .clickable {
                                                            linkSelectedSpeed = spd
                                                            linkMediaPlayer?.playbackParams =
                                                                linkMediaPlayer?.playbackParams?.setSpeed(spd) ?: return@clickable
                                                        }
                                                        .padding(vertical = 6.dp),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        if (spd == 1.0f) "1.0x" else "${spd}x",
                                                        color = if (isSel) Color.Black else Color.White,
                                                        fontSize = 10.sp,
                                                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                                                    )
                                                }
                                            }
                                        }
                                        Spacer(Modifier.height(12.dp))

                                        // ── VOLUME CONTROL (BARU) ──
                                        Row(
                                            Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.VolumeUp, null, tint = Muted, modifier = Modifier.size(14.dp))
                                                Spacer(Modifier.width(4.dp))
                                                Text("VOLUME AUDIO", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                            val volLabel = when (linkSelectedVolume) {
                                                0.5f -> "50%"
                                                0.75f -> "75%"
                                                1.0f -> "100%"
                                                1.25f -> "125%"
                                                1.5f -> "150%"
                                                1.75f -> "175%"
                                                else -> "200%"
                                            }
                                            Text(volLabel, color = Purple, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        }
                                        Spacer(Modifier.height(8.dp))
                                        val linkVolumes = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f)
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                            linkVolumes.forEach { vol ->
                                                val isVol = linkSelectedVolume == vol
                                                Box(
                                                    Modifier
                                                        .weight(1f)
                                                        .background(if (isVol) Purple else Color(0xFF1E212C), RoundedCornerShape(8.dp))
                                                        .border(1.dp, if (isVol) Purple else Color(0xFF34384A), RoundedCornerShape(8.dp))
                                                        .clickable {
                                                            linkSelectedVolume = vol
                                                            // Reset audio bytes agar diproses ulang dengan volume baru
                                                            linkAudioBytes = null
                                                            linkMediaPlayer?.release(); linkMediaPlayer = null; linkIsPlaying = false
                                                        }
                                                        .padding(vertical = 6.dp),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        when (vol) {
                                                            0.5f -> "50%"
                                                            0.75f -> "75%"
                                                            1.0f -> "100%"
                                                            1.25f -> "125%"
                                                            1.5f -> "150%"
                                                            1.75f -> "175%"
                                                            else -> "200%"
                                                        },
                                                        color = if (isVol) Color.Black else Color.White,
                                                        fontSize = 9.sp,
                                                        fontWeight = if (isVol) FontWeight.Bold else FontWeight.Normal
                                                    )
                                                }
                                            }
                                        }
                                        if (linkSelectedVolume != 1.0f) {
                                            Spacer(Modifier.height(4.dp))
                                            Text(
                                                if (linkSelectedVolume > 1.0f)
                                                    "⚡ Volume diperbesar — audio di-upload dengan gain ${(linkSelectedVolume * 100).toInt()}%"
                                                else
                                                    "🔉 Volume diperkecil — audio di-upload dengan gain ${(linkSelectedVolume * 100).toInt()}%",
                                                color = if (linkSelectedVolume > 1.5f) Color(0xFFFFC56A) else Muted,
                                                fontSize = 10.sp
                                            )
                                        }
                                        Spacer(Modifier.height(10.dp))

                                        // Preview button — loading spinner kalau masih fetch, play/pause kalau udah siap
                                        OutlinedButton(
                                            onClick = {
                                                if (linkFetching) return@OutlinedButton // masih loading, abaikan tap
                                                if (linkIsPlaying) {
                                                    linkMediaPlayer?.pause()
                                                    linkIsPlaying = false
                                                } else {
                                                    try {
                                                        if (linkMediaPlayer == null) {
                                                            val tmpFile = java.io.File(context.cacheDir, linkAudioName)
                                                            // Apply volume gain ke preview juga
                                                            val previewBytes = AudioProcessor.applyGain(linkAudioBytes!!, linkSelectedVolume)
                                                            tmpFile.writeBytes(previewBytes)
                                                            linkMediaPlayer = MediaPlayer().apply {
                                                                setDataSource(tmpFile.absolutePath)
                                                                prepare()
                                                                playbackParams = playbackParams.setSpeed(linkSelectedSpeed)
                                                                setOnCompletionListener { linkIsPlaying = false }
                                                            }
                                                        } else {
                                                            linkMediaPlayer?.playbackParams =
                                                                linkMediaPlayer!!.playbackParams.setSpeed(linkSelectedSpeed)
                                                        }
                                                        linkMediaPlayer?.start()
                                                        linkIsPlaying = true
                                                    } catch (e: Exception) {
                                                        linkStatus = "✗ Gagal preview: ${e.message}"
                                                    }
                                                }
                                            },
                                            Modifier.fillMaxWidth(),
                                            enabled = !linkFetching || linkAudioBytes != null,
                                            border = androidx.compose.foundation.BorderStroke(1.dp, Teal)
                                        ) {
                                            when {
                                                linkFetching -> {
                                                    CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp, color = Teal)
                                                    Spacer(Modifier.width(8.dp))
                                                    Text("MEMUAT AUDIO…", color = Teal, fontSize = 12.sp)
                                                }
                                                linkIsPlaying -> {
                                                    Icon(Icons.Default.Pause, null, tint = Teal)
                                                    Spacer(Modifier.width(6.dp))
                                                    Text("PAUSE PREVIEW", color = Teal, fontSize = 12.sp)
                                                }
                                                else -> {
                                                    Icon(Icons.Default.PlayArrow, null, tint = Teal)
                                                    Spacer(Modifier.width(6.dp))
                                                    Text("PREVIEW AUDIO (${linkSelectedSpeed}x)", color = Teal, fontSize = 12.sp)
                                                }
                                            }
                                        }
                                        Spacer(Modifier.height(4.dp))
                                        Divider(color = Color(0xFF2C2F3B))
                                    }
                                }

                                if (type == "Audio" && uri != null) {
                                    Spacer(Modifier.height(14.dp))
                                    AudioEditorCard(
                                        fileName        = fileName,
                                        fileSizeBytes   = fileSizeBytes,
                                        durationMs      = audioDurationMs,
                                        isPlaying       = isPlaying,
                                        progressMs      = audioProgressMs,
                                        selectedSpeed   = selectedSpeed,
                                        selectedVolume  = selectedVolume,
                                        selectedFilter  = selectedFilter,
                                        onPickFile      = {
                                            mediaPlayer?.release(); mediaPlayer = null; isPlaying = false
                                            uri = null; fileName = ""; audioProgressMs = 0L; audioDurationMs = 0L; fileSizeBytes = 0L
                                        },
                                        onPlayPause     = {
                                            if (isPlaying) {
                                                mediaPlayer?.pause(); isPlaying = false
                                            } else {
                                                try {
                                                    if (mediaPlayer == null) {
                                                        val rawBytes = context.contentResolver.openInputStream(uri!!)?.use { it.readBytes() }
                                                        if (rawBytes != null) {
                                                            // 1. Tulis raw bytes ke temp file untuk decode
                                                            val srcTmp = java.io.File(context.cacheDir, "src_${System.currentTimeMillis()}.audio")
                                                            srcTmp.writeBytes(rawBytes)

                                                            // 2. Decode ke WAV PCM supaya semua processing work (volume 0 = mute, filter, speed)
                                                            val wavBytes = decodeToPcmWav(srcTmp) ?: rawBytes
                                                            srcTmp.delete()

                                                            // 3. Apply semua processing: gain + filter + speed (di-bake ke file)
                                                            val processed = AudioProcessor.processAll(
                                                                wavBytes, selectedVolume, 1.0f, selectedFilter
                                                                // Speed TIDAK di-bake ke preview, hanya lewat playbackParams
                                                                // supaya preview tetap realtime; tapi speed DI-BAKE saat upload
                                                            )

                                                            val tmpFile = java.io.File(context.cacheDir, "prev_${System.currentTimeMillis()}.wav")
                                                            tmpFile.writeBytes(processed)
                                                            mediaPlayer = MediaPlayer().apply {
                                                                setDataSource(tmpFile.absolutePath)
                                                                prepare()
                                                                // Speed lewat playbackParams untuk preview realtime
                                                                playbackParams = playbackParams.setSpeed(selectedSpeed)
                                                                setOnCompletionListener { isPlaying = false; audioProgressMs = 0L }
                                                            }
                                                            if (audioDurationMs == 0L) audioDurationMs = mediaPlayer?.duration?.toLong() ?: 0L
                                                        } else {
                                                            mediaPlayer = MediaPlayer().apply {
                                                                setDataSource(context, uri!!)
                                                                prepare()
                                                                playbackParams = playbackParams.setSpeed(selectedSpeed)
                                                                setOnCompletionListener { isPlaying = false; audioProgressMs = 0L }
                                                            }
                                                        }
                                                    } else {
                                                        // Player sudah ada, update speed saja realtime
                                                        mediaPlayer?.playbackParams = mediaPlayer!!.playbackParams.setSpeed(selectedSpeed)
                                                    }
                                                    mediaPlayer?.start(); isPlaying = true
                                                } catch (e: Exception) { status = "Gagal preview: ${e.message}" }
                                            }
                                        },
                                        onSeek          = { fraction ->
                                            val seekMs = (fraction * audioDurationMs).toLong()
                                            mediaPlayer?.seekTo(seekMs.toInt())
                                            audioProgressMs = seekMs
                                        },
                                        onSpeedChange   = { spd ->
                                            selectedSpeed = spd
                                            // Update realtime di player yang sudah jalan
                                            try {
                                                mediaPlayer?.playbackParams = mediaPlayer?.playbackParams?.setSpeed(spd) ?: return@AudioEditorCard
                                            } catch (_: Exception) {
                                                // Player belum siap, akan apply saat play berikutnya
                                            }
                                        },
                                        onVolumeChange  = { vol ->
                                            selectedVolume = vol
                                            // Reset player supaya gain + filter diproses ulang dari decode
                                            mediaPlayer?.release(); mediaPlayer = null; isPlaying = false; audioProgressMs = 0L
                                        },
                                        onFilterChange  = { f ->
                                            selectedFilter = f
                                            // Reset player supaya filter diproses ulang
                                            mediaPlayer?.release(); mediaPlayer = null; isPlaying = false; audioProgressMs = 0L
                                        }
                                    )
                                    Spacer(Modifier.height(4.dp))
                                }

                                Spacer(Modifier.height(12.dp))
                                OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("Display Name") }, singleLine = true)
                                Spacer(Modifier.height(8.dp))
                                OutlinedTextField(desc, { desc = it }, Modifier.fillMaxWidth(), label = { Text("Deskripsi") }, minLines = 2)
                                Spacer(Modifier.height(12.dp))

                                Button(
                                    onClick = {
                                        // ── Validasi input ──
                                        val isLinkMode = type == "Audio" && uploadMode == "Link"
                                        if (apiKey.isBlank() || creator.toLongOrNull() == null || name.isBlank()) {
                                            status = "Lengkapi API Key, Creator ID, dan nama asset."
                                            return@Button
                                        }
                                        if (!isLinkMode && uri == null) {
                                            status = "Pilih file terlebih dahulu."
                                            return@Button
                                        }
                                        if (isLinkMode && linkInput.isBlank()) {
                                            status = "Paste link TikTok dulu."
                                            return@Button
                                        }
                                        if (isLinkMode && LinkDownloader.detectType(linkInput) == LinkDownloader.LinkType.UNSUPPORTED) {
                                            status = "Link tidak dikenali. Gunakan link TikTok."
                                            return@Button
                                        }
                                        val limitError = UploadLimit.checkAllowed(context)
                                        if (limitError != null) { status = limitError; return@Button }

                                        busy = true
                                        status = if (isLinkMode) "Memproses & upload audio dari link…" else "Mengirim file ke Roblox…"
                                        linkStatus = if (isLinkMode) "⏳ Memproses audio…" else ""

                                        scope.launch {
                                            try {
                                                val result = withContext(Dispatchers.IO) {
                                                    if (isLinkMode) {
                                                        // Pakai audio yang sudah di-fetch (dari tombol preview), kalau belum fetch dulu
                                                        val (bytes, fname, mime) = if (linkAudioBytes != null) {
                                                            withContext(kotlinx.coroutines.Dispatchers.Main) {
                                                                linkStatus = "✓ Pakai audio yang sudah diambil — mengirim ke Roblox…"
                                                                status = linkStatus
                                                            }
                                                            Triple(linkAudioBytes!!, linkAudioName, linkAudioMime)
                                                        } else {
                                                            val ltype = LinkDownloader.detectType(linkInput)
                                                            val dl = LinkDownloader.download(linkInput.trim(), ltype)
                                                            val b = dl.stream.use { it.readBytes() }
                                                            withContext(kotlinx.coroutines.Dispatchers.Main) {
                                                                linkStatus = "✓ Audio siap (${b.size / 1024} KB) — mengirim ke Roblox…"
                                                                status = linkStatus
                                                                linkAudioBytes = b
                                                                linkAudioMime  = dl.mimeType
                                                                linkAudioName  = dl.fileName
                                                            }
                                                            Triple(b, dl.fileName, dl.mimeType)
                                                        }
                                                        // LINK MODE UPLOAD:
                                                        // Decode ke WAV PCM dulu → apply gain+filter+speed (di-bake) → upload WAV
                                                        // Ini bikin speed setting beneran ter-encode di file yang diupload ke Roblox
                                                        val srcTmpLink = java.io.File(context.cacheDir, "upload_link_${System.currentTimeMillis()}.audio")
                                                        srcTmpLink.writeBytes(bytes)
                                                        val wavBytesLink = decodeToPcmWav(srcTmpLink) ?: bytes
                                                        srcTmpLink.delete()

                                                        val processedBytes = AudioProcessor.processAll(
                                                            wavBytesLink,
                                                            linkSelectedVolume,
                                                            linkSelectedSpeed,   // speed DI-BAKE ke file upload
                                                            linkSelectedFilter
                                                        )
                                                        // Upload sebagai WAV (Roblox support WAV) — nama file tetap asli tanpa berubah
                                                        val uploadFname = fname.substringBeforeLast(".") + ".wav"
                                                        RobloxAssetUploader(context).uploadFromBytes(
                                                            apiKey.trim(), processedBytes, uploadFname, "audio/wav",
                                                            "Audio", name.trim(), desc.trim(), creator.toLong()
                                                        )
                                                    } else {
                                                        // FILE MODE UPLOAD:
                                                        // Selalu decode ke WAV → apply semua processing (gain+filter+speed di-bake)
                                                        if (type == "Audio") {
                                                            val rawBytes = context.contentResolver.openInputStream(uri!!)?.use { it.readBytes() }
                                                                ?: error("File tidak bisa dibaca")
                                                            // Decode ke WAV PCM supaya semua processing 100% work
                                                            val srcTmp = java.io.File(context.cacheDir, "upload_src_${System.currentTimeMillis()}.audio")
                                                            srcTmp.writeBytes(rawBytes)
                                                            val wavBytes = decodeToPcmWav(srcTmp) ?: rawBytes
                                                            srcTmp.delete()

                                                            val processedBytes = AudioProcessor.processAll(
                                                                wavBytes,
                                                                selectedVolume,   // volume di-bake
                                                                selectedSpeed,    // speed DI-BAKE ke file (anti-copyright + Roblox deteksi speed asli)
                                                                selectedFilter    // filter di-bake
                                                            )
                                                            // Nama file tidak berubah (sesuai request) tapi content sudah dimodif
                                                            val origName = uri!!.lastPathSegment?.substringAfterLast('/') ?: "audio"
                                                            val uploadName = origName.substringBeforeLast(".") + ".wav"
                                                            RobloxAssetUploader(context).uploadFromBytes(
                                                                apiKey.trim(), processedBytes, uploadName, "audio/wav",
                                                                type, name.trim(), desc.trim(), creator.toLong()
                                                            )
                                                        } else {
                                                            RobloxAssetUploader(context).upload(
                                                                apiKey.trim(), uri!!, type, name.trim(), desc.trim(), creator.toLong()
                                                            )
                                                        }
                                                    }
                                                }
                                                UploadLimit.recordUpload(context)
                                                refreshLimit()

                                                val operation = result.operationId.orEmpty()
                                                val assetId   = result.assetId.orEmpty()
                                                val tempId    = assetId.ifBlank { operation.ifBlank { System.currentTimeMillis().toString() } }
                                                status = if (assetId.isNotBlank()) "Upload berhasil. Asset ID: $assetId" else "Upload diterima. Memeriksa status…"
                                                if (isLinkMode) linkStatus = "✓ ${status}"

                                                val pendingItem = HistoryItem(
                                                    type = type, name = name, id = tempId,
                                                    status = status, date = System.currentTimeMillis().toString(),
                                                    operationId = operation, pending = assetId.isBlank() && operation.isNotBlank()
                                                )
                                                persistHistory(listOf(pendingItem) + history)

                                                if (assetId.isBlank() && operation.isNotBlank()) {
                                                    pollOperation(apiKey.trim(), operation, tempId)
                                                }
                                            } catch (e: Exception) {
                                                status = "Gagal: ${e.message ?: "Kesalahan tidak diketahui"}"
                                                if (isLinkMode) linkStatus = "✗ ${e.message ?: "Gagal"}"
                                            } finally {
                                                busy = false
                                            }
                                        }
                                    },
                                    Modifier.fillMaxWidth().height(52.dp),
                                    enabled = !busy,
                                    colors = ButtonDefaults.buttonColors(containerColor = Purple)
                                ) {
                                    if (busy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                                    else Icon(Icons.Default.CloudUpload, null)
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        if (busy) "SEDANG UPLOAD…" else "UPLOAD ASSET",
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                AnimatedVisibility(visible = status.isNotBlank()) {
                                    Column {
                                        Spacer(Modifier.height(10.dp))
                                        Text(
                                            status,
                                            color = when {
                                                status.startsWith("Gagal") || status.startsWith("Limit") -> Color(0xFFFF8B8B)
                                                else -> Color(0xFFBBA3FF)
                                            },
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            }
                        }

                        // ===================================================
                        // PAGE: HISTORY
                        // ===================================================
                        Page.History -> {
                            Title("Riwayat Upload", "Riwayat tersimpan lokal di perangkat ini.")
                            if (history.isEmpty()) CardBox { Text("Belum ada riwayat upload.", color = Muted) }
                            else history.forEach { h ->
                                CardBox {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("${h.type.uppercase()} • ${h.name}", color = Color.White, fontWeight = FontWeight.Bold)
                                        if (h.pending) {
                                            Box(
                                                Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xFF2A2412)).padding(horizontal = 8.dp, vertical = 3.dp)
                                            ) { Text("PENDING", color = Color(0xFFFFC56A), fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                                        }
                                    }
                                    Text("ID: ${h.id}", color = Teal, fontSize = 12.sp)
                                    Text(h.status, color = Muted, fontSize = 11.sp)
                                    if (h.pending && h.operationId.isNotBlank()) {
                                        Spacer(Modifier.height(6.dp))
                                        OutlinedButton(
                                            onClick = {
                                                if (apiKey.isBlank()) {
                                                    scope.launch { snackbar.showSnackbar("Isi API Key dulu di menu Akun") }
                                                } else {
                                                    pollOperation(apiKey.trim(), h.operationId, h.id)
                                                }
                                            },
                                            Modifier.fillMaxWidth()
                                        ) { Text("CEK STATUS LAGI", fontSize = 12.sp) }
                                    }
                                }
                                Spacer(Modifier.height(8.dp))
                            }
                            OutlinedButton(
                                onClick = { persistHistory(emptyList()) },
                                Modifier.fillMaxWidth()
                            ) { Text("HAPUS RIWAYAT") }
                        }

                        // ===================================================
                        // PAGE: HELP — Diperbarui v4.0, lebih rapi & terstruktur
                        // ===================================================
                        Page.Help -> {
                            Title("Bantuan", "Panduan penggunaan & kontak owner")

                            // ── CARA UPLOAD ──────────────────────────────────
                            CardBox {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CloudUpload, null, tint = Teal, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text("CARA UPLOAD", color = Teal, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                }
                                Spacer(Modifier.height(12.dp))

                                data class HelpStep(val num: String, val title: String, val desc: String)
                                listOf(
                                    HelpStep("1", "Setup Akun", "Buka menu Akun → verifikasi sidik jari/PIN → isi API Key & Creator User ID."),
                                    HelpStep("2", "Pilih Tipe Asset", "Pilih Audio untuk upload musik/suara, atau Decal untuk gambar PNG/JPG."),
                                    HelpStep("3a", "Mode File", "Pilih tab File → tap area pilih file → pilih audio/gambar dari penyimpanan HP."),
                                    HelpStep("3b", "Mode Link", "Pilih tab Link → paste URL TikTok → sistem otomatis download audio."),
                                    HelpStep("4", "Atur Speed & Volume", "Sesuaikan speed playback (0.5x–2.0x) dan volume audio (50%–200%) sesuai kebutuhan."),
                                    HelpStep("5", "Upload", "Isi Display Name & Deskripsi → tekan UPLOAD ASSET → tunggu konfirmasi Asset ID."),
                                    HelpStep("6", "Cek Status", "Jika status masih 'Diproses', buka tab History → tekan CEK STATUS LAGI.")
                                ).forEach { s ->
                                    Row(
                                        Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 5.dp),
                                        verticalAlignment = Alignment.Top
                                    ) {
                                        Box(
                                            Modifier
                                                .size(26.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(Teal.copy(alpha = 0.15f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(s.num, color = Teal, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                        Spacer(Modifier.width(10.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(s.title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            Text(s.desc, color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
                                        }
                                    }
                                }

                                Spacer(Modifier.height(8.dp))
                                Divider(color = Color(0xFF2C2F3B))
                                Spacer(Modifier.height(8.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Security, null, tint = Muted, modifier = Modifier.size(13.dp))
                                    Spacer(Modifier.width(5.dp))
                                    Text(
                                        "API Key tersimpan terenkripsi via Android Keystore & dikunci biometrik/PIN.",
                                        color = Muted, fontSize = 10.sp, lineHeight = 15.sp
                                    )
                                }
                            }

                            // ── FITUR VOLUME & SPEED ─────────────────────────
                            CardBox {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Tune, null, tint = Purple, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text("FITUR SPEED & VOLUME", color = Purple, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                }
                                Spacer(Modifier.height(10.dp))

                                // Speed info
                                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                    Icon(Icons.Default.Speed, null, tint = Teal, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text("Speed Playback", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Text("Ubah kecepatan audio: 0.5x (lambat) hingga 2.0x (cepat). Berlaku saat preview & upload.", color = Muted, fontSize = 11.sp, lineHeight = 15.sp)
                                    }
                                }
                                Spacer(Modifier.height(6.dp))

                                // Volume info
                                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                    Icon(Icons.Default.VolumeUp, null, tint = Purple, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text("Volume Audio", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Text("Atur keras/kecilnya suara: 50%–200%. Audio diproses sebelum di-upload — Roblox menerima volume yang sudah diatur.", color = Muted, fontSize = 11.sp, lineHeight = 15.sp)
                                        Spacer(Modifier.height(3.dp))
                                        Text("⚠ Volume > 150% dapat menyebabkan clipping jika audio sumber sudah keras.", color = Color(0xFFFFC56A), fontSize = 10.sp, lineHeight = 14.sp)
                                    }
                                }
                                Spacer(Modifier.height(4.dp))
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFF1A1030))
                                        .padding(10.dp)
                                ) {
                                    Icon(Icons.Default.Info, null, tint = Purple.copy(alpha = 0.7f), modifier = Modifier.size(13.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Untuk audio MP3/AAC, volume lebih akurat jika file adalah WAV. MP3 diproses secara sederhana.", color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
                                }
                            }

                            // ── LIMIT UPLOAD ─────────────────────────────────
                            CardBox {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CloudUpload, null, tint = Purple, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text("LIMIT UPLOAD", color = Purple, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                }
                                Spacer(Modifier.height(10.dp))

                                data class LimitRow(val icon: androidx.compose.ui.graphics.vector.ImageVector, val tint: Color, val text: String)
                                listOf(
                                    LimitRow(Icons.Default.Person, Muted, "User biasa: maks ${UploadLimit.DAILY_LIMIT} upload per 24 jam."),
                                    LimitRow(Icons.Default.Refresh, Muted, "Limit rolling — slot terbuka kembali tepat 24 jam setelah upload dilakukan."),
                                    LimitRow(Icons.Default.Star, Gold, "User VIP: upload tak terbatas, tidak ada limit harian."),
                                    LimitRow(Icons.Default.ShoppingCart, Gold, "VIP Key bisa dibeli langsung dari owner.")
                                ).forEach { r ->
                                    Row(
                                        Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(r.icon, null, tint = r.tint, modifier = Modifier.size(15.dp))
                                        Spacer(Modifier.width(8.dp))
                                        Text(r.text, color = Color.White, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.weight(1f))
                                    }
                                }
                            }

                            // ── KONTAK OWNER ──────────────────────────────────
                            CardBox {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.ContactPhone, null, tint = Gold, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text("KONTAK OWNER", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                }
                                Spacer(Modifier.height(12.dp))

                                // WhatsApp
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color(0xFF0D1A10))
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        Modifier
                                            .size(36.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(Color(0xFF4CAF50).copy(alpha = 0.18f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Phone, null, tint = Color(0xFF4CAF50), modifier = Modifier.size(18.dp))
                                    }
                                    Spacer(Modifier.width(12.dp))
                                    Column {
                                        Text("WhatsApp / No. HP", color = Muted, fontSize = 10.sp)
                                        Text("082324919412", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    }
                                }
                                Spacer(Modifier.height(8.dp))

                                // Discord
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color(0xFF0D1020))
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        Modifier
                                            .size(36.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(Color(0xFF7289DA).copy(alpha = 0.18f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Chat, null, tint = Color(0xFF7289DA), modifier = Modifier.size(18.dp))
                                    }
                                    Spacer(Modifier.width(12.dp))
                                    Column {
                                        Text("Discord", color = Muted, fontSize = 10.sp)
                                        Text("reyytzyyy", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    }
                                }
                                Spacer(Modifier.height(10.dp))
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFF1A1500))
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Info, null, tint = Gold.copy(alpha = 0.7f), modifier = Modifier.size(13.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Hubungi owner untuk membeli VIP Key atau melaporkan bug.", color = Gold.copy(alpha = 0.85f), fontSize = 11.sp)
                                }
                            }

                            // ── VERSI APP ────────────────────────────────────
                            Box(
                                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("Rexyy Uploader v4.0 — Roblox Asset Uploader", color = Muted.copy(alpha = 0.5f), fontSize = 10.sp)
                            }
                        }
                    }

                    Spacer(Modifier.height(20.dp))
                }
            }
        }
    }
}

// ============================================================
// AUDIO EDITOR CARD — mirip screenshot: file info, waveform,
// play/progress, speed chips, volume slider, 12 filter badges
// ============================================================
@Composable
private fun AudioEditorCard(
    fileName: String,
    fileSizeBytes: Long,
    durationMs: Long,
    isPlaying: Boolean,
    progressMs: Long,
    selectedSpeed: Float,
    selectedVolume: Float,          // 0f–1.5f  (0%–150%)
    selectedFilter: String,
    onPickFile: () -> Unit,
    onPlayPause: () -> Unit,
    onSeek: (Float) -> Unit,        // fraction 0f–1f
    onSpeedChange: (Float) -> Unit,
    onVolumeChange: (Float) -> Unit,
    onFilterChange: (String) -> Unit,
) {
    val infiniteTransition = rememberInfiniteTransition(label = "waveform")

    // 24 waveform bars — animate height only when playing
    val barHeights = (0 until 24).map { i ->
        val phase = (i * 0.42f) % 1f
        val animVal by infiniteTransition.animateFloat(
            initialValue = 0.2f + phase * 0.3f,
            targetValue  = 0.7f + phase * 0.3f,
            animationSpec = infiniteRepeatable(
                tween((600 + i * 30), easing = LinearEasing),
                RepeatMode.Reverse
            ),
            label = "bar$i"
        )
        if (isPlaying) animVal else (0.25f + phase * 0.45f)
    }

    val filters = listOf("Normal","Chipmunk","Banana","Chill","Bas","Grill","Boy","Koboy","Robot","Deep","Speed","Echo","Girl")

    val fileSizeKb  = fileSizeBytes / 1024
    val durationSec = durationMs / 1000
    val durMin      = durationSec / 60
    val durSec      = durationSec % 60
    val progSec     = progressMs / 1000
    val progMin     = progSec / 60
    val progSecRem  = progSec % 60

    val progressFraction = if (durationMs > 0L) (progressMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
    val volPercent = (selectedVolume * 100).toInt().coerceIn(0, 150)

    Column(
        Modifier
            .fillMaxWidth()
            .premiumBorder(16.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF191B26))
            .padding(16.dp)
    ) {
        // ── Header: file name + × button ──
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.MusicNote, null, tint = Teal, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    fileName.ifBlank { "—" },
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(onClick = onPickFile, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Default.Close, null, tint = Muted, modifier = Modifier.size(16.dp))
            }
        }

        // ── File meta row ──
        Spacer(Modifier.height(6.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            MetaChip("Ukuran", if (fileSizeKb > 0) "${fileSizeKb} KB" else "—")
            MetaChip("Format", if (fileName.contains('.')) fileName.substringAfterLast('.').uppercase() else "—")
            MetaChip("Durasi", if (durationMs > 0) "%02d:%02d".format(durMin, durSec) else "--:--")
        }

        Spacer(Modifier.height(14.dp))

        // ── AUDIO EDITOR label + reset button ──
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.GraphicEq, null, tint = Muted, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Column {
                    Text("AUDIO EDITOR", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(
                        when (selectedFilter) {
                            "Normal" -> "Suara Normal (Real-time)"
                            else -> "Filter: $selectedFilter"
                        },
                        color = Muted, fontSize = 10.sp
                    )
                }
            }
            OutlinedButton(
                onClick = {
                    onSpeedChange(1.0f)
                    onVolumeChange(1.0f)
                    onFilterChange("Normal")
                },
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF34384A)),
                modifier = Modifier.height(30.dp)
            ) {
                Icon(Icons.Default.Refresh, null, tint = Muted, modifier = Modifier.size(12.dp))
                Spacer(Modifier.width(4.dp))
                Text("Reset", color = Muted, fontSize = 10.sp)
            }
        }

        Spacer(Modifier.height(12.dp))

        // ── Waveform + play button ──
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF111318))
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Play/Pause button
            Box(
                Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color(0xFF2C2F3D))
                    .clickable(onClick = onPlayPause),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    null,
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(Modifier.width(10.dp))

            // Waveform bars + seek bar overlay
            Box(Modifier.weight(1f)) {
                // Waveform visualization
                Canvas(
                    Modifier
                        .fillMaxWidth()
                        .height(40.dp)
                ) {
                    val barWidth = size.width / (barHeights.size * 1.8f)
                    val gap = barWidth * 0.8f
                    val totalWidth = barHeights.size * (barWidth + gap) - gap
                    val startX = (size.width - totalWidth) / 2f
                    barHeights.forEachIndexed { i, h ->
                        val barH = size.height * h
                        val x = startX + i * (barWidth + gap)
                        val isBeforeProgress = (i.toFloat() / barHeights.size) < progressFraction
                        drawRect(
                            color = if (isBeforeProgress) androidx.compose.ui.graphics.Color(0xFF4FE3C1) else androidx.compose.ui.graphics.Color(0xFF2C2F3D),
                            topLeft = Offset(x, (size.height - barH) / 2f),
                            size = androidx.compose.ui.geometry.Size(barWidth, barH)
                        )
                    }
                }

                // Invisible seek overlay
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(40.dp)
                        .clickable { /* tap center = toggle play */ }
                )
            }
        }

        // Progress time display
        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("%02d:%02d".format(progMin, progSecRem), color = Muted, fontSize = 10.sp)
            Text(if (durationMs > 0) "%02d:%02d".format(durMin, durSec) else "--:--", color = Muted, fontSize = 10.sp)
        }

        Spacer(Modifier.height(16.dp))

        // ── SPEED PLAYBACK ──
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Speed, null, tint = Muted, modifier = Modifier.size(13.dp))
                Spacer(Modifier.width(4.dp))
                Text("SPEED PLAYBACK", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Text("${selectedSpeed}x", color = Teal, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(6.dp))
        val speeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            speeds.forEach { spd ->
                val sel = selectedSpeed == spd
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (sel) Teal else Color(0xFF1E212C))
                        .border(1.dp, if (sel) Teal else Color(0xFF34384A), RoundedCornerShape(6.dp))
                        .clickable { onSpeedChange(spd) }
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        if (spd == 1.0f) "1.0x" else "${spd}x",
                        color = if (sel) Color.Black else Color.White,
                        fontSize = 9.sp,
                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        // ── VOLUME PLAYBACK slider ──
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.VolumeUp, null, tint = Muted, modifier = Modifier.size(13.dp))
                Spacer(Modifier.width(4.dp))
                Text("VOLUME PLAYBACK", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Text("$volPercent%", color = Purple, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(4.dp))
        Slider(
            value = selectedVolume,
            onValueChange = onVolumeChange,
            valueRange = 0f..1.5f,
            modifier = Modifier.fillMaxWidth(),
            colors = SliderDefaults.colors(
                thumbColor = Purple,
                activeTrackColor = Purple,
                inactiveTrackColor = Color(0xFF2C2F3D)
            )
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("0%", color = Muted, fontSize = 9.sp)
            Text("50%", color = Muted, fontSize = 9.sp)
            Text("100% (Normal)", color = Muted, fontSize = 9.sp)
            Text("150% (Boost)", color = Muted, fontSize = 9.sp)
        }

        Spacer(Modifier.height(14.dp))

        // Filter suara dihapus dari UI — processing tetap jalan di background (Normal by default)

        Spacer(Modifier.height(4.dp))

        // Ganti File button
        OutlinedButton(
            onClick = onPickFile,
            modifier = Modifier.fillMaxWidth(),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF34384A))
        ) {
            Icon(Icons.Default.FolderOpen, null, tint = Muted, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(6.dp))
            Text("Ganti File", color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun MetaChip(label: String, value: String) {
    Column {
        Text(label, color = Muted, fontSize = 9.sp)
        Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

// ============================================================
// LIMIT COUNTDOWN CARD — muncul saat limit habis,
// countdown tick tiap detik, auto-reset saat mencapai 0
// ============================================================
@Composable
private fun LimitCountdownCard(
    context: android.content.Context,
    onLimitReset: () -> Unit
) {
    val millisLeft = remember { mutableStateOf(UploadLimit.millisUntilNextSlot(context)) }

    LaunchedEffect(Unit) {
        while (millisLeft.value > 0L) {
            delay(1000L)
            millisLeft.value = UploadLimit.millisUntilNextSlot(context)
            if (millisLeft.value <= 0L) {
                onLimitReset()
            }
        }
    }

    if (millisLeft.value <= 0L) return  // limit sudah reset, jangan tampil

    val totalSec = millisLeft.value / 1000
    val hours    = totalSec / 3600
    val minutes  = (totalSec % 3600) / 60
    val seconds  = totalSec % 60

    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF1A0E1A))
            .border(1.dp, Purple.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Timer, null, tint = Purple, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Column {
                    Text("LIMIT TERCAPAI", color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("Reset otomatis dalam:", color = Muted, fontSize = 10.sp)
                }
            }
            // Countdown display
            Box(
                Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF2A1A2A))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    "%02d:%02d:%02d".format(hours, minutes, seconds),
                    color = Purple,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
private fun Title(t: String, s: String) {
    Text(t, color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
    Text(s, color = Muted, fontSize = 12.sp)
    Spacer(Modifier.height(14.dp))
}

@Composable
private fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .premiumBorder(20.dp, 1.2.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF1C1E29), Panel)))
            .padding(16.dp),
        content = content
    )
    Spacer(Modifier.height(10.dp))
}

@Composable
private fun FilterButton(t: String, selected: Boolean, m: Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick, modifier = m,
        colors = ButtonDefaults.buttonColors(containerColor = if (selected) Purple else Color(0xFF1E212C))
    ) { Text(t) }
}

private fun saveHistory(items: List<HistoryItem>) = org.json.JSONArray().apply {
    items.take(100).forEach {
        put(
            JSONObject()
                .put("type", it.type).put("name", it.name).put("id", it.id)
                .put("status", it.status).put("date", it.date)
                .put("operationId", it.operationId).put("pending", it.pending)
        )
    }
}.toString()

private fun loadHistory(raw: String): List<HistoryItem> {
    return try {
        val a = org.json.JSONArray(raw)
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            HistoryItem(
                o.optString("type"), o.optString("name"), o.optString("id"),
                o.optString("status"), o.optString("date"),
                o.optString("operationId"), o.optBoolean("pending", false)
            )
        }
    } catch (_: Exception) { emptyList() }
}

/**
 * Decode MP3/AAC/apapun ke WAV PCM 16-bit stereo menggunakan MediaCodec.
 * Wajib dipanggil sebelum AudioProcessor.applyGain / applySpeed / applyFilter
 * kalau file source adalah MP3, supaya processing beneran work.
 *
 * Return: ByteArray WAV (header + PCM 16-bit LE stereo), atau null kalau gagal.
 */
fun decodeToPcmWav(srcFile: java.io.File): ByteArray? {
    return try {
        val extractor = MediaExtractor()
        extractor.setDataSource(srcFile.absolutePath)

        // Cari audio track
        var audioTrackIndex = -1
        var format: MediaFormat? = null
        for (i in 0 until extractor.trackCount) {
            val fmt = extractor.getTrackFormat(i)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("audio/")) {
                audioTrackIndex = i
                format = fmt
                break
            }
        }
        if (audioTrackIndex == -1 || format == null) {
            extractor.release()
            return null
        }

        extractor.selectTrack(audioTrackIndex)
        val mime = format.getString(MediaFormat.KEY_MIME)!!
        val sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        val channelCount = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT))
            format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2

        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(format, null, null, 0)
        codec.start()

        val pcmData = java.io.ByteArrayOutputStream()
        val bufInfo = MediaCodec.BufferInfo()
        var inputDone = false
        var outputDone = false

        while (!outputDone) {
            if (!inputDone) {
                val inputIdx = codec.dequeueInputBuffer(10_000L)
                if (inputIdx >= 0) {
                    val inputBuf = codec.getInputBuffer(inputIdx)!!
                    inputBuf.clear()
                    val sampleSize = extractor.readSampleData(inputBuf, 0)
                    if (sampleSize < 0) {
                        codec.queueInputBuffer(inputIdx, 0, 0, 0,
                            MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        inputDone = true
                    } else {
                        codec.queueInputBuffer(inputIdx, 0, sampleSize,
                            extractor.sampleTime, 0)
                        extractor.advance()
                    }
                }
            }

            val outputIdx = codec.dequeueOutputBuffer(bufInfo, 10_000L)
            if (outputIdx >= 0) {
                val outBuf = codec.getOutputBuffer(outputIdx)
                if (outBuf != null && bufInfo.size > 0) {
                    val chunk = ByteArray(bufInfo.size)
                    outBuf.get(chunk)
                    pcmData.write(chunk)
                }
                codec.releaseOutputBuffer(outputIdx, false)
                if (bufInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                    outputDone = true
                }
            }
        }

        codec.stop()
        codec.release()
        extractor.release()

        val rawPcm = pcmData.toByteArray()
        if (rawPcm.isEmpty()) return null

        // Build WAV header
        val byteRate = sampleRate * channelCount * 2
        val blockAlign = channelCount * 2
        val header = ByteArray(44)
        val hBuf = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
        hBuf.put("RIFF".toByteArray(Charsets.US_ASCII))
        hBuf.putInt(36 + rawPcm.size)
        hBuf.put("WAVE".toByteArray(Charsets.US_ASCII))
        hBuf.put("fmt ".toByteArray(Charsets.US_ASCII))
        hBuf.putInt(16)
        hBuf.putShort(1)
        hBuf.putShort(channelCount.toShort())
        hBuf.putInt(sampleRate)
        hBuf.putInt(byteRate)
        hBuf.putShort(blockAlign.toShort())
        hBuf.putShort(16)
        hBuf.put("data".toByteArray(Charsets.US_ASCII))
        hBuf.putInt(rawPcm.size)

        header + rawPcm
    } catch (_: Exception) { null }
}
