package com.rexyy.uploader.security

import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/**
 * Lapisan "akun aman": minta sidik jari / PIN / pola layar kunci perangkat
 * sebelum menampilkan atau mengubah API Key. Kalau perangkat tidak punya
 * sensor biometrik atau belum setup kunci layar, langsung diizinkan masuk
 * (tidak mengunci user keluar dari fitur) tapi callback tetap memberi tahu
 * statusnya lewat [BiometricResult.Unavailable].
 */
object BiometricHelper {

    sealed class BiometricResult {
        data object Success : BiometricResult()
        data object Unavailable : BiometricResult()
        data class Failed(val reason: String) : BiometricResult()
    }

    fun canUseBiometric(activity: FragmentActivity): Boolean {
        val manager = BiometricManager.from(activity)
        val result = manager.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_WEAK or
                BiometricManager.Authenticators.DEVICE_CREDENTIAL
        )
        return result == BiometricManager.BIOMETRIC_SUCCESS
    }

    fun authenticate(
        activity: FragmentActivity,
        title: String = "Buka kunci Akun Rexyy",
        subtitle: String = "Verifikasi untuk melihat/mengubah API Key",
        onResult: (BiometricResult) -> Unit
    ) {
        if (!canUseBiometric(activity)) {
            onResult(BiometricResult.Unavailable)
            return
        }
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(
            activity,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onResult(BiometricResult.Success)
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    onResult(BiometricResult.Failed(errString.toString()))
                }
                override fun onAuthenticationFailed() {
                    // Percobaan gagal (misal sidik jari tidak cocok) — biarkan user coba lagi,
                    // prompt sistem akan menangani retry-nya sendiri.
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle(subtitle)
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_WEAK or
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )
            .build()
        prompt.authenticate(info)
    }
}
