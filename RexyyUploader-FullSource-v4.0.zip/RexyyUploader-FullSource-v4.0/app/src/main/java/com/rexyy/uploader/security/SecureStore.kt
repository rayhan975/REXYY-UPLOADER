package com.rexyy.uploader.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Penyimpanan lokal terenkripsi untuk data sensitif (API Key, Creator ID).
 *
 * Menggunakan Android Keystore lewat AndroidX Security-Crypto, jadi key
 * enkripsinya tersimpan di hardware-backed keystore perangkat (bukan di
 * dalam APK atau file biasa). Kalau library/keystore gagal diinisialisasi
 * (misal device lama/aneh), otomatis fallback ke SharedPreferences biasa
 * supaya aplikasi tidak crash — tapi ini jarang terjadi di Android 8+.
 */
object SecureStore {
    private const val FILE_NAME = "rexyy_secure"
    private const val FALLBACK_FILE_NAME = "rexyy_local"

    @Volatile private var cached: SharedPreferences? = null

    fun get(context: Context): SharedPreferences {
        cached?.let { return it }
        synchronized(this) {
            cached?.let { return it }
            val prefs = try {
                val masterKey = MasterKey.Builder(context.applicationContext)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build()
                EncryptedSharedPreferences.create(
                    context.applicationContext,
                    FILE_NAME,
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
                )
            } catch (e: Exception) {
                // Fallback: tetap jalan walau tanpa enkripsi hardware-backed
                context.applicationContext.getSharedPreferences(FALLBACK_FILE_NAME, Context.MODE_PRIVATE)
            }
            cached = prefs
            return prefs
        }
    }

    /** Hapus semua data akun tersimpan (API Key, Creator ID) dari perangkat. */
    fun wipeAccount(context: Context) {
        get(context).edit()
            .remove("api_key")
            .remove("creator_id")
            .apply()
    }
}
