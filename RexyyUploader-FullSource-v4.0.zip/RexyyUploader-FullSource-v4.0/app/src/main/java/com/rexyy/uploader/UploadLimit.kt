package com.rexyy.uploader

import android.content.Context
import com.rexyy.uploader.security.SecureStore
import org.json.JSONArray
import org.json.JSONObject

/**
 * Upload limit engine — 5 upload per 24 jam untuk user biasa.
 * VIP users (key tersimpan di prefs["vip_key"] bernilai "REXYY-VIP") tidak ada batas.
 *
 * Struktur penyimpanan di SharedPreferences (key = "upload_log"):
 *   JSONArray of timestamp (Long) — epoch ms setiap upload yang berhasil dikirim.
 *   Di-filter setiap query: entri > 24 jam otomatis dibuang, jadi window selalu rolling 24 jam.
 *
 * Tidak ada server — semua state lokal di perangkat.
 */
object UploadLimit {

    const val DAILY_LIMIT = 5
    private const val WINDOW_MS = 24L * 60 * 60 * 1000   // 24 jam dalam ms
    private const val LOG_KEY = "upload_log"
    const val VIP_KEY_VALUE = "REXYY-VIP"
    private const val VIP_PREF_KEY = "vip_key"

    /**
     * Apakah user ini VIP?
     * VIP = prefs["vip_key"] == "REXYY-VIP".
     * Di masa depan bisa ditukar dengan validasi server, tapi sekarang lokal saja.
     */
    fun isVip(context: Context): Boolean {
        val prefs = SecureStore.get(context)
        return prefs.getString(VIP_PREF_KEY, "").orEmpty().trim().uppercase() == VIP_KEY_VALUE
    }

    /** Simpan VIP key ke SharedPreferences terenkripsi. */
    fun saveVipKey(context: Context, key: String) {
        SecureStore.get(context).edit().putString(VIP_PREF_KEY, key.trim()).apply()
    }

    /** Hapus VIP key (downgrade ke free). */
    fun clearVipKey(context: Context) {
        SecureStore.get(context).edit().remove(VIP_PREF_KEY).apply()
    }

    /**
     * Baca log upload yang masih dalam window 24 jam.
     * Sekaligus bersihkan entri lama agar tidak menumpuk selamanya.
     */
    private fun recentTimestamps(context: Context): MutableList<Long> {
        val prefs = SecureStore.get(context)
        val raw = prefs.getString(LOG_KEY, "[]") ?: "[]"
        val now = System.currentTimeMillis()
        val cutoff = now - WINDOW_MS
        return try {
            val arr = JSONArray(raw)
            val list = mutableListOf<Long>()
            for (i in 0 until arr.length()) {
                val ts = arr.getLong(i)
                if (ts >= cutoff) list.add(ts)   // buang yang sudah > 24 jam
            }
            list
        } catch (_: Exception) {
            mutableListOf()
        }
    }

    /** Berapa upload tersisa untuk user biasa dalam window 24 jam sekarang. */
    fun remainingUploads(context: Context): Int {
        if (isVip(context)) return Int.MAX_VALUE
        val used = recentTimestamps(context).size
        return maxOf(0, DAILY_LIMIT - used)
    }

    /**
     * Berapa milidetik sampai slot upload pertama yang paling lama terbuka (reset).
     * Hanya relevan kalau limit sudah penuh.
     * Return 0 jika masih ada slot.
     */
    fun millisUntilNextSlot(context: Context): Long {
        if (isVip(context)) return 0L
        val timestamps = recentTimestamps(context)
        if (timestamps.size < DAILY_LIMIT) return 0L
        val oldest = timestamps.minOrNull() ?: return 0L
        val resetAt = oldest + WINDOW_MS
        return maxOf(0L, resetAt - System.currentTimeMillis())
    }

    /**
     * Cek apakah upload diizinkan.
     * Return null = boleh. Return String = pesan error + info sisa waktu.
     */
    fun checkAllowed(context: Context): String? {
        if (isVip(context)) return null
        val remaining = remainingUploads(context)
        if (remaining > 0) return null
        val ms = millisUntilNextSlot(context)
        val hours = ms / (1000 * 60 * 60)
        val minutes = (ms % (1000 * 60 * 60)) / (1000 * 60)
        return "Limit harian tercapai (${DAILY_LIMIT}x per 24 jam). " +
                "Reset dalam ${hours}j ${minutes}m. " +
                "Aktifkan VIP untuk upload tanpa batas."
    }

    /**
     * Catat satu upload berhasil dikirim ke Roblox.
     * Dipanggil setelah HTTP 2xx, BUKAN setelah polling selesai —
     * supaya slot terpakai saat file sudah benar-benar terkirim.
     */
    fun recordUpload(context: Context) {
        if (isVip(context)) return   // VIP: tidak perlu tracking
        val prefs = SecureStore.get(context)
        val list = recentTimestamps(context)
        list.add(System.currentTimeMillis())
        val arr = JSONArray().apply { list.forEach { put(it) } }
        prefs.edit().putString(LOG_KEY, arr.toString()).apply()
    }

    /** Format teks badge sisa upload untuk ditampilkan di UI. */
    fun badgeText(context: Context): String {
        if (isVip(context)) return "VIP · Upload Tak Terbatas"
        val r = remainingUploads(context)
        return "Sisa hari ini: $r / $DAILY_LIMIT upload"
    }
}
