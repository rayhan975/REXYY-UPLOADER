package com.rexyy.uploader.network

import android.content.Context
import android.net.Uri
import org.json.JSONObject
import java.io.DataOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

class RobloxAssetUploader(private val context: Context) {
    data class Result(val operationId: String?, val assetId: String?, val raw: String)

    // ── Upload dari file Uri (file picker) ────────────────────────────────────
    fun upload(
        apiKey: String,
        fileUri: Uri,
        assetType: String,
        displayName: String,
        description: String,
        creatorUserId: Long
    ): Result {
        require(apiKey.isNotBlank()) { "API Key belum diisi" }
        require(assetType == "Audio" || assetType == "Decal") { "Jenis asset tidak didukung" }
        val mime = context.contentResolver.getType(fileUri) ?: "application/octet-stream"
        val fileName = queryFileName(fileUri)
        val stream = context.contentResolver.openInputStream(fileUri)
            ?: error("File tidak bisa dibaca")
        return uploadStream(apiKey, stream, fileName, mime, assetType, displayName, description, creatorUserId)
    }

    // ── Upload dari ByteArray (hasil download link / audio processor) ─────────
    fun uploadFromBytes(
        apiKey: String,
        bytes: ByteArray,
        fileName: String,
        mimeType: String,
        assetType: String,
        displayName: String,
        description: String,
        creatorUserId: Long
    ): Result = uploadStream(
        apiKey, bytes.inputStream(), fileName, mimeType,
        assetType, displayName, description, creatorUserId,
        contentLength = bytes.size.toLong()
    )

    // ── Internal multipart POST — streaming, tidak buffer semua di memory ──────
    private fun uploadStream(
        apiKey: String,
        inputStream: InputStream,
        fileName: String,
        mimeType: String,
        assetType: String,
        displayName: String,
        description: String,
        creatorUserId: Long,
        contentLength: Long = -1L
    ): Result {
        val boundary = "Rexyy-${UUID.randomUUID()}"
        val requestJson = JSONObject().apply {
            put("assetType", assetType)
            put("displayName", displayName)
            put("description", description)
            put("creationContext", JSONObject().put("creator", JSONObject().put("userId", creatorUserId.toString())))
        }

        val requestJsonBytes = requestJson.toString().toByteArray(Charsets.UTF_8)

        // Hitung bagian header/footer multipart
        val partHeader = buildString {
            append("--$boundary\r\n")
            append("Content-Disposition: form-data; name=\"request\"\r\n")
            append("Content-Type: application/json; charset=utf-8\r\n\r\n")
        }.toByteArray(Charsets.UTF_8)

        val partSep = "\r\n".toByteArray(Charsets.UTF_8)

        val fileHeader = buildString {
            append("--$boundary\r\n")
            append("Content-Disposition: form-data; name=\"fileContent\"; filename=\"$fileName\"\r\n")
            append("Content-Type: $mimeType\r\n\r\n")
        }.toByteArray(Charsets.UTF_8)

        val footer = "\r\n--$boundary--\r\n".toByteArray(Charsets.UTF_8)

        // Kalau content length diketahui, hitung total agar tidak perlu chunked
        val knownTotalLength = if (contentLength >= 0) {
            (partHeader.size + requestJsonBytes.size + partSep.size +
                fileHeader.size + contentLength + footer.size).also { _ -> }
        } else -1L

        val connection = (URL("https://apis.roblox.com/assets/v1/assets").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 30_000
            readTimeout   = 300_000   // 5 menit — file gede butuh waktu lebih
            doOutput      = true
            setRequestProperty("x-api-key", apiKey)
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")

            if (knownTotalLength > 0) {
                // Pakai fixed content-length — lebih stabil, hindari chunked encoding issues
                setFixedLengthStreamingMode(knownTotalLength)
            } else {
                // Fallback chunked 256KB
                setChunkedStreamingMode(256 * 1024)
            }
        }

        try {
            DataOutputStream(connection.outputStream).use { out ->
                // Part 1: JSON request
                out.write(partHeader)
                out.write(requestJsonBytes)
                out.write(partSep)

                // Part 2: file content — streaming, tidak buffer semua
                out.write(fileHeader)
                val buf = ByteArray(64 * 1024) // 64KB buffer
                var read: Int
                while (inputStream.read(buf).also { read = it } != -1) {
                    out.write(buf, 0, read)
                }
                out.write(footer)
                out.flush()
            }

            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IllegalStateException("Roblox HTTP $code: $body")
            val json = JSONObject(body)
            return Result(
                operationId = json.optString("path").takeIf { it.isNotBlank() },
                assetId     = json.optString("assetId").takeIf { it.isNotBlank() },
                raw         = body
            )
        } finally {
            try { inputStream.close() } catch (_: Exception) {}
            connection.disconnect()
        }
    }

    private fun queryFileName(uri: Uri): String {
        val fallback = "asset"
        return try {
            context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0)?.replace(Regex("[^A-Za-z0-9._-]"), "_")?.take(100) ?: fallback else fallback
            } ?: fallback
        } catch (_: Exception) { fallback }
    }

    fun checkOperation(apiKey: String, operationIdOrPath: String): String {
        val path = if (operationIdOrPath.startsWith("operations/")) operationIdOrPath else "operations/$operationIdOrPath"
        val conn = (URL("https://apis.roblox.com/assets/v1/$path").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15_000
            readTimeout   = 30_000
            setRequestProperty("x-api-key", apiKey)
        }
        try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IllegalStateException("Roblox HTTP $code: $body")
            return body
        } finally { conn.disconnect() }
    }
}
