package com.rexyy.uploader.network

import android.content.Context
import android.net.Uri
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

class RobloxAssetUploader(private val context: Context) {
    data class Result(val operationId: String?, val assetId: String?, val raw: String)

    // ── Upload dari file Uri (file picker) ────────────────────────────────────
    fun upload(
        apiKey: String,
        fileUri: Uri,
        assetType: String,
        displayName: String,
        description: String,
        creatorUserId: Long
    ): Result {
        require(apiKey.isNotBlank()) { "API Key belum diisi" }
        require(assetType == "Audio" || assetType == "Decal") { "Jenis asset tidak didukung" }
        val mime = context.contentResolver.getType(fileUri) ?: "application/octet-stream"
        val fileName = queryFileName(fileUri)

        // FIX: Baca semua bytes dulu ke memory sebelum upload
        // Hindari broken pipe karena stream Uri Android sering tidak mendukung
        // proper streaming ke HttpURLConnection
        val stream = context.contentResolver.openInputStream(fileUri)
            ?: error("File tidak bisa dibaca")
        val bytes = stream.use { it.readBytes() }

        return uploadFromBytes(apiKey, bytes, fileName, mime, assetType, displayName, description, creatorUserId)
    }

    // ── Upload dari ByteArray (hasil download link / audio processor) ─────────
    fun uploadFromBytes(
        apiKey: String,
        bytes: ByteArray,
        fileName: String,
        mimeType: String,
        assetType: String,
        displayName: String,
        description: String,
        creatorUserId: Long
    ): Result = uploadBytes(
        apiKey, bytes, fileName, mimeType,
        assetType, displayName, description, creatorUserId
    )

    // ── Internal multipart POST — buffer penuh di memory, lebih stabil ────────
    // FIX UTAMA: Gunakan buffer penuh (bukan streaming) untuk hindari broken pipe.
    // Roblox API kadang tutup koneksi kalau data tidak datang cepat/stabil —
    // dengan buffer penuh kita kirim sekaligus tanpa jeda, jauh lebih reliable.
    private fun uploadBytes(
        apiKey: String,
        fileBytes: ByteArray,
        fileName: String,
        mimeType: String,
        assetType: String,
        displayName: String,
        description: String,
        creatorUserId: Long
    ): Result {
        val boundary = "RexyyBound-${UUID.randomUUID().toString().replace("-", "")}"

        val requestJson = JSONObject().apply {
            put("assetType", assetType)
            put("displayName", displayName)
            put("description", description)
            put("creationContext", JSONObject().put(
                "creator", JSONObject().put("userId", creatorUserId.toString())
            ))
        }

        // Bangun seluruh body multipart di memory → kirim sekaligus
        val body = ByteArrayOutputStream().apply {
            // Part 1: JSON request metadata
            write(("--$boundary\r\n").toByteArray(Charsets.UTF_8))
            write(("Content-Disposition: form-data; name=\"request\"\r\n").toByteArray(Charsets.UTF_8))
            write(("Content-Type: application/json; charset=utf-8\r\n\r\n").toByteArray(Charsets.UTF_8))
            write(requestJson.toString().toByteArray(Charsets.UTF_8))
            write(("\r\n").toByteArray(Charsets.UTF_8))

            // Part 2: file content
            write(("--$boundary\r\n").toByteArray(Charsets.UTF_8))
            write(("Content-Disposition: form-data; name=\"fileContent\"; filename=\"$fileName\"\r\n").toByteArray(Charsets.UTF_8))
            write(("Content-Type: $mimeType\r\n\r\n").toByteArray(Charsets.UTF_8))
            write(fileBytes)
            write(("\r\n--$boundary--\r\n").toByteArray(Charsets.UTF_8))
        }.toByteArray()

        // FIX: Retry logic — coba sampai 3 kali kalau gagal broken pipe / timeout
        var lastException: Exception? = null
        repeat(3) { attempt ->
            try {
                return doPost(apiKey, boundary, body)
            } catch (e: Exception) {
                lastException = e
                val msg = e.message?.lowercase() ?: ""
                // Retry hanya untuk network errors, bukan HTTP 4xx
                val isRetryable = msg.contains("broken pipe") ||
                    msg.contains("connection reset") ||
                    msg.contains("timeout") ||
                    msg.contains("econnreset") ||
                    msg.contains("eof") ||
                    msg.contains("socket")
                if (!isRetryable || attempt == 2) throw e
                // Tunggu sebentar sebelum retry
                Thread.sleep(1500L * (attempt + 1))
            }
        }
        throw lastException ?: IllegalStateException("Upload gagal setelah 3 percobaan")
    }

    private fun doPost(apiKey: String, boundary: String, body: ByteArray): Result {
        val conn = (URL("https://apis.roblox.com/assets/v1/assets")
            .openConnection() as HttpURLConnection).apply {
            requestMethod        = "POST"
            connectTimeout       = 30_000      // 30 detik connect
            readTimeout          = 300_000     // 5 menit read (file besar)
            doOutput             = true
            doInput              = true
            useCaches            = false
            // FIX: Paksa HTTP/1.1 untuk hindari chunked encoding masalah
            setRequestProperty("Connection", "keep-alive")
            setRequestProperty("x-api-key", apiKey)
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            // FIX: Set content-length tepat → server tahu ukuran data → tidak ada broken pipe
            setFixedLengthStreamingMode(body.size.toLong())
        }

        try {
            // Tulis body sekaligus — satu write, langsung flush
            conn.outputStream.use { out ->
                out.write(body)
                out.flush()
            }

            val code = conn.responseCode
            val responseStream = if (code in 200..299) conn.inputStream else conn.errorStream
            val responseBody = responseStream?.bufferedReader()?.use { it.readText() }.orEmpty()

            if (code !in 200..299) {
                throw IllegalStateException("Roblox HTTP $code: $responseBody")
            }

            val json = JSONObject(responseBody)
            return Result(
                operationId = json.optString("path").takeIf { it.isNotBlank() },
                assetId     = json.optString("assetId").takeIf { it.isNotBlank() },
                raw         = responseBody
            )
        } finally {
            conn.disconnect()
        }
    }

    private fun queryFileName(uri: Uri): String {
        val fallback = "asset"
        return try {
            context.contentResolver.query(
                uri,
                arrayOf(android.provider.OpenableColumns.DISPLAY_NAME),
                null, null, null
            )?.use { c ->
                if (c.moveToFirst())
                    c.getString(0)
                        ?.replace(Regex("[^A-Za-z0-9._-]"), "_")
                        ?.take(100)
                        ?: fallback
                else fallback
            } ?: fallback
        } catch (_: Exception) { fallback }
    }

    fun checkOperation(apiKey: String, operationIdOrPath: String): String {
        val path = if (operationIdOrPath.startsWith("operations/"))
            operationIdOrPath else "operations/$operationIdOrPath"
        val conn = (URL("https://apis.roblox.com/assets/v1/$path")
            .openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15_000
            readTimeout   = 30_000
            setRequestProperty("x-api-key", apiKey)
        }
        try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IllegalStateException("Roblox HTTP $code: $body")
            return body
        } finally { conn.disconnect() }
    }
}
