package com.rexyy.uploader.network

import android.content.Context
import android.net.Uri
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.net.UnknownHostException
import java.util.UUID
import java.util.concurrent.TimeUnit

class RobloxAssetUploader(private val context: Context) {
    data class Result(val operationId: String?, val assetId: String?, val raw: String)

    companion object {
        // Satu OkHttpClient shared — connection pool, DNS cache, lebih cepat
        private val client: OkHttpClient by lazy {
            OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(5, TimeUnit.MINUTES)
                .writeTimeout(5, TimeUnit.MINUTES)
                .retryOnConnectionFailure(true)
                .build()
        }

        private const val API_URL = "https://apis.roblox.com/assets/v1/assets"
        private const val MAX_RETRY = 3
    }

    // ── Upload dari file Uri (file picker) ────────────────────────────────────
    fun upload(
        apiKey: String,
        fileUri: Uri,
        assetType: String,
        displayName: String,
        description: String,
        creatorUserId: Long
    ): Result {
        require(apiKey.isNotBlank()) { "API Key belum diisi" }
        require(assetType == "Audio" || assetType == "Decal") { "Jenis asset tidak didukung" }

        val mime     = context.contentResolver.getType(fileUri) ?: "application/octet-stream"
        val fileName = queryFileName(fileUri)
        val bytes    = context.contentResolver.openInputStream(fileUri)?.use { it.readBytes() }
            ?: error("File tidak bisa dibaca")

        return uploadFromBytes(apiKey, bytes, fileName, mime, assetType, displayName, description, creatorUserId)
    }

    // ── Upload dari ByteArray (hasil download link / audio processor) ─────────
    fun uploadFromBytes(
        apiKey: String,
        bytes: ByteArray,
        fileName: String,
        mimeType: String,
        assetType: String,
        displayName: String,
        description: String,
        creatorUserId: Long
    ): Result = uploadWithRetry(apiKey, bytes, fileName, mimeType, assetType, displayName, description, creatorUserId)

    // ── Retry wrapper — handle DNS fail, connection reset, timeout ────────────
    private fun uploadWithRetry(
        apiKey: String,
        bytes: ByteArray,
        fileName: String,
        mimeType: String,
        assetType: String,
        displayName: String,
        description: String,
        creatorUserId: Long
    ): Result {
        var lastError: Exception? = null
        repeat(MAX_RETRY) { attempt ->
            try {
                return doUpload(apiKey, bytes, fileName, mimeType, assetType, displayName, description, creatorUserId)
            } catch (e: Exception) {
                lastError = e
                val msg = e.message?.lowercase() ?: ""
                val isDns        = e is UnknownHostException
                val isRetryable  = isDns
                    || msg.contains("broken pipe")
                    || msg.contains("connection reset")
                    || msg.contains("timeout")
                    || msg.contains("eof")
                    || msg.contains("socket")
                    || msg.contains("econnreset")
                if (!isRetryable || attempt == MAX_RETRY - 1) throw e
                // Delay sebelum retry: 2s, 4s
                Thread.sleep(2000L * (attempt + 1))
            }
        }
        throw lastError ?: IllegalStateException("Upload gagal setelah $MAX_RETRY percobaan")
    }

    // ── OkHttp multipart POST ─────────────────────────────────────────────────
    private fun doUpload(
        apiKey: String,
        fileBytes: ByteArray,
        fileName: String,
        mimeType: String,
        assetType: String,
        displayName: String,
        description: String,
        creatorUserId: Long
    ): Result {
        val requestJson = JSONObject().apply {
            put("assetType", assetType)
            put("displayName", displayName)
            put("description", description)
            put("creationContext", JSONObject().put(
                "creator", JSONObject().put("userId", creatorUserId.toString())
            ))
        }.toString()

        val safeFileName = fileName.replace(Regex("[^A-Za-z0-9._-]"), "_").take(100)
        val fileMime     = mimeType.toMediaType()

        val body = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart(
                "request", null,
                requestJson.toRequestBody("application/json; charset=utf-8".toMediaType())
            )
            .addFormDataPart(
                "fileContent", safeFileName,
                fileBytes.toRequestBody(fileMime)
            )
            .build()

        val request = Request.Builder()
            .url(API_URL)
            .addHeader("x-api-key", apiKey)
            .post(body)
            .build()

        val response = client.newCall(request).execute()
        val responseBody = response.body?.string().orEmpty()

        if (!response.isSuccessful) {
            throw IllegalStateException("Roblox HTTP ${response.code}: $responseBody")
        }

        val json = JSONObject(responseBody)
        return Result(
            operationId = json.optString("path").takeIf { it.isNotBlank() },
            assetId     = json.optString("assetId").takeIf { it.isNotBlank() },
            raw         = responseBody
        )
    }

    private fun queryFileName(uri: Uri): String {
        val fallback = "asset"
        return try {
            context.contentResolver.query(
                uri,
                arrayOf(android.provider.OpenableColumns.DISPLAY_NAME),
                null, null, null
            )?.use { c ->
                if (c.moveToFirst())
                    c.getString(0)
                        ?.replace(Regex("[^A-Za-z0-9._-]"), "_")
                        ?.take(100)
                        ?: fallback
                else fallback
            } ?: fallback
        } catch (_: Exception) { fallback }
    }

    fun checkOperation(apiKey: String, operationIdOrPath: String): String {
        val path = if (operationIdOrPath.startsWith("operations/"))
            operationIdOrPath else "operations/$operationIdOrPath"

        val request = Request.Builder()
            .url("https://apis.roblox.com/assets/v1/$path")
            .addHeader("x-api-key", apiKey)
            .get()
            .build()

        val response = client.newCall(request).execute()
        val body = response.body?.string().orEmpty()
        if (!response.isSuccessful) throw IllegalStateException("Roblox HTTP ${response.code}: $body")
        return body
    }
}
