package com.rexyy.uploader.network

import android.content.Context
import android.net.Uri
import org.json.JSONObject
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

class RobloxAssetUploader(private val context: Context) {
    data class Result(val operationId: String?, val assetId: String?, val raw: String)

    // ── Upload dari file Uri (file picker) ────────────────────────────────────
    fun upload(
        apiKey: String,
        fileUri: Uri,
        assetType: String,
        displayName: String,
        description: String,
        creatorUserId: Long
    ): Result {
        require(apiKey.isNotBlank()) { "API Key belum diisi" }
        require(assetType == "Audio" || assetType == "Decal") { "Jenis asset tidak didukung" }
        val mime = context.contentResolver.getType(fileUri) ?: "application/octet-stream"
        val fileName = queryFileName(fileUri)
        val bytes = context.contentResolver.openInputStream(fileUri)?.use { it.readBytes() }
            ?: error("File tidak bisa dibaca")
        return uploadBytes(apiKey, bytes, fileName, mime, assetType, displayName, description, creatorUserId)
    }

    // ── Upload dari ByteArray (hasil download link) ───────────────────────────
    fun uploadFromBytes(
        apiKey: String,
        bytes: ByteArray,
        fileName: String,
        mimeType: String,
        assetType: String,
        displayName: String,
        description: String,
        creatorUserId: Long
    ): Result = uploadBytes(apiKey, bytes, fileName, mimeType, assetType, displayName, description, creatorUserId)

    // ── Internal multipart POST ───────────────────────────────────────────────
    private fun uploadBytes(
        apiKey: String,
        bytes: ByteArray,
        fileName: String,
        mimeType: String,
        assetType: String,
        displayName: String,
        description: String,
        creatorUserId: Long
    ): Result {
        val boundary = "Rexyy-${UUID.randomUUID()}"
        val requestJson = JSONObject().apply {
            put("assetType", assetType)
            put("displayName", displayName)
            put("description", description)
            put("creationContext", JSONObject().put("creator", JSONObject().put("userId", creatorUserId.toString())))
        }
        val connection = (URL("https://apis.roblox.com/assets/v1/assets").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 30_000
            readTimeout   = 60_000
            doOutput      = true
            setRequestProperty("x-api-key", apiKey)
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        }
        try {
            DataOutputStream(connection.outputStream).use { out ->
                fun field(name: String, value: String) {
                    out.writeBytes("--$boundary\r\n")
                    out.writeBytes("Content-Disposition: form-data; name=\"$name\"\r\n")
                    out.writeBytes("Content-Type: application/json; charset=utf-8\r\n\r\n")
                    out.write(value.toByteArray(Charsets.UTF_8))
                    out.writeBytes("\r\n")
                }
                field("request", requestJson.toString())
                out.writeBytes("--$boundary\r\n")
                out.writeBytes("Content-Disposition: form-data; name=\"fileContent\"; filename=\"$fileName\"\r\n")
                out.writeBytes("Content-Type: $mimeType\r\n\r\n")
                out.write(bytes)
                out.writeBytes("\r\n--$boundary--\r\n")
                out.flush()
            }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IllegalStateException("Roblox HTTP $code: $body")
            val json = JSONObject(body)
            return Result(
                operationId = json.optString("path").takeIf { it.isNotBlank() },
                assetId     = json.optString("assetId").takeIf { it.isNotBlank() },
                raw         = body
            )
        } finally {
            connection.disconnect()
        }
    }

    private fun queryFileName(uri: Uri): String {
        val fallback = "asset"
        return try {
            context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0)?.replace(Regex("[^A-Za-z0-9._-]"), "_")?.take(100) ?: fallback else fallback
            } ?: fallback
        } catch (_: Exception) { fallback }
    }

    fun checkOperation(apiKey: String, operationIdOrPath: String): String {
        val path = if (operationIdOrPath.startsWith("operations/")) operationIdOrPath else "operations/$operationIdOrPath"
        val conn = (URL("https://apis.roblox.com/assets/v1/$path").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15_000
            readTimeout   = 30_000
            setRequestProperty("x-api-key", apiKey)
        }
        try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IllegalStateException("Roblox HTTP $code: $body")
            return body
        } finally { conn.disconnect() }
    }
}
