package com.rexyy.uploader.network

import org.json.JSONObject
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Download audio dari link TikTok via multiple API fallback.
 *
 * Strategi download TikTok:
 *   1. tikwm.com API
 *   2. douyin.wtf / tiktok-dl API
 *   3. Cobalt API v10 fallback
 */
object LinkDownloader {

    enum class LinkType { TIKTOK, UNSUPPORTED }

    fun detectType(url: String): LinkType {
        val u = url.trim().lowercase()
        return when {
            u.contains("tiktok.com") || u.contains("vt.tiktok.com")
                || u.contains("vm.tiktok.com") -> LinkType.TIKTOK
            else -> LinkType.UNSUPPORTED
        }
    }

    data class DownloadResult(val stream: InputStream, val fileName: String, val mimeType: String)

    fun download(rawUrl: String, type: LinkType): DownloadResult {
        return when (type) {
            LinkType.TIKTOK  -> downloadTiktok(rawUrl)
            else -> throw IllegalArgumentException("Link tidak didukung. Gunakan link TikTok.")
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // COBALT INSTANCES — diperbarui 2025
    // ══════════════════════════════════════════════════════════════════════════

    private val COBALT_INSTANCES = listOf(
        "https://api.cobalt.tools",              // official cobalt
        "https://cobalt.api.timelessnesses.me",  // community
        "https://capi.bloatcat.xyz",             // community
        "https://cobalt.ggtyler.dev",            // community (baru)
        "https://cobalt.privacydev.net"          // community (baru)
    )

    // ══════════════════════════════════════════════════════════════════════════
    // TIKTOK DOWNLOADER — tidak berubah, sudah stabil
    // ══════════════════════════════════════════════════════════════════════════

    private fun downloadTiktok(url: String): DownloadResult {
        var lastError = "Semua server TikTok gagal"

        try {
            val audioUrl = tryTikwm(url)
            if (audioUrl != null) return fetchStream(audioUrl, "tt_audio.mp3", "audio/mpeg")
        } catch (e: Exception) { lastError = e.message ?: "tikwm gagal" }

        try {
            val audioUrl = tryMusicalDown(url)
            if (audioUrl != null) return fetchStream(audioUrl, "tt_audio.mp3", "audio/mpeg")
        } catch (e: Exception) { lastError = e.message ?: "musicaldown gagal" }

        for (base in COBALT_INSTANCES) {
            try {
                val audioUrl = tryCobaltV10Instance(base, url)
                    ?: tryCobaltInstance("$base/api/json", buildCobaltBodyV7(url), "application/json")
                if (audioUrl != null) return fetchStream(audioUrl, "tt_audio.mp3", "audio/mpeg")
            } catch (e: Exception) { lastError = e.message ?: "cobalt gagal di $base" }
        }

        throw RuntimeException(
            "Gagal unduh audio TikTok.\n" +
            "Pastikan: link publik, bukan FYP private, & koneksi stabil.\n" +
            "Detail: $lastError"
        )
    }

    private fun tryTikwm(url: String): String? {
        val formBody = "url=${java.net.URLEncoder.encode(url.trim(), "UTF-8")}&count=12&cursor=0&web=1&hd=1"
        val conn = (URL("https://www.tikwm.com/api/").openConnection() as HttpURLConnection).apply {
            requestMethod  = "POST"
            connectTimeout = 15_000
            readTimeout    = 30_000
            doOutput       = true
            setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            setRequestProperty("User-Agent", "Mozilla/5.0 (Android 14) RexyyUploader/4.0")
            setRequestProperty("Referer", "https://www.tikwm.com/")
        }
        conn.outputStream.use { it.write(formBody.toByteArray()) }
        val code = conn.responseCode
        val raw  = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.bufferedReader()?.use { it.readText() }?.trim() ?: ""
        conn.disconnect()
        if (raw.isBlank() || !raw.startsWith("{")) return null
        val j    = JSONObject(raw)
        val data = j.optJSONObject("data") ?: return null
        return data.optString("music_info")
            .takeIf { it.isNotBlank() }
            ?.let { runCatching { JSONObject(it).optString("play") }.getOrNull() }
            ?.takeIf { it.startsWith("http") }
            ?: data.optString("music").takeIf { it.startsWith("http") }
            ?: data.optString("hdplay").takeIf { it.startsWith("http") }
    }

    private fun tryMusicalDown(url: String): String? {
        val apis = listOf(
            "https://api.douyin.wtf/api?url=${java.net.URLEncoder.encode(url.trim(), "UTF-8")}&minimal=true",
            "https://tiktok-dl.siilas.workers.dev/?url=${java.net.URLEncoder.encode(url.trim(), "UTF-8")}"
        )
        for (apiUrl in apis) {
            try {
                val raw = httpGet(apiUrl)
                if (raw.isBlank() || !raw.startsWith("{")) continue
                val j = JSONObject(raw)
                val audio = j.optString("music_url").takeIf { it.startsWith("http") }
                    ?: j.optJSONObject("data")?.optString("music")?.takeIf { it.startsWith("http") }
                if (audio != null) return audio
            } catch (_: Exception) {}
        }
        return null
    }

    // ══════════════════════════════════════════════════════════════════════════
    // COBALT HELPERS
    // ══════════════════════════════════════════════════════════════════════════

    private fun buildCobaltBodyV7(url: String) = JSONObject().apply {
        put("url", url.trim())
        put("isAudioOnly", true)
        put("aFormat", "mp3")
        put("vQuality", "720")
        put("disableMetadata", false)
    }.toString()

    private fun tryCobaltV10Instance(baseUrl: String, videoUrl: String): String? {
        val body = JSONObject().apply {
            put("url", videoUrl.trim())
            put("downloadMode", "audio")
            put("audioFormat", "mp3")
            put("audioBitrate", "128")
        }.toString()

        val endpoint = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"

        val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod  = "POST"
            connectTimeout = 20_000
            readTimeout    = 60_000
            doOutput       = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "Mozilla/5.0 (Android 14; Mobile) RexyyUploader/4.0")
        }
        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val raw  = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.bufferedReader()?.use { it.readText() }?.trim() ?: ""
        conn.disconnect()
        if (raw.isBlank() || !raw.startsWith("{")) return null
        val j      = JSONObject(raw)
        val status = j.optString("status")
        return when (status) {
            "tunnel", "redirect", "stream" ->
                j.optString("url").takeIf { it.startsWith("http") }
            else -> null
        }
    }

    private fun tryCobaltInstance(endpoint: String, body: String, accept: String): String? {
        val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod  = "POST"
            connectTimeout = 20_000
            readTimeout    = 60_000
            doOutput       = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", accept)
            setRequestProperty("User-Agent", "Mozilla/5.0 (Android 14) RexyyUploader/4.0")
        }
        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val raw  = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.bufferedReader()?.use { it.readText() }?.trim() ?: ""
        conn.disconnect()
        if (raw.isBlank() || !raw.startsWith("{")) return null
        val j      = JSONObject(raw)
        val status = j.optString("status")
        val dlUrl  = j.optString("url").takeIf { it.startsWith("http") }
            ?: j.optString("audio").takeIf { it.startsWith("http") }
        return when (status) {
            "tunnel", "redirect", "stream" -> dlUrl
            "error" -> null
            else -> dlUrl
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // HTTP HELPERS
    // ══════════════════════════════════════════════════════════════════════════

    private fun httpGet(url: String, userAgent: String = "Mozilla/5.0 RexyyUploader/4.0"): String {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 20_000
            readTimeout    = 30_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", userAgent)
        }
        val code = conn.responseCode
        val body = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.bufferedReader()?.use { it.readText() } ?: ""
        conn.disconnect()
        if (code !in 200..299) throw RuntimeException("HTTP $code dari $url")
        return body
    }

    fun fetchStream(url: String, fileName: String, mime: String): DownloadResult {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 30_000
            readTimeout    = 180_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "Mozilla/5.0 (Android 14) RexyyUploader/4.0")
        }
        val code = conn.responseCode
        if (code !in 200..299) {
            conn.disconnect()
            throw RuntimeException("Download stream gagal HTTP $code")
        }
        val actualMime = conn.contentType?.substringBefore(";")?.trim()?.takeIf { it.isNotBlank() } ?: mime
        return DownloadResult(stream = conn.inputStream, fileName = fileName, mimeType = actualMime)
    }
}
