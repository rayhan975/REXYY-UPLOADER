package com.rexyy.uploader.network

import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.InputStream
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Download audio dari link TikTok via multiple API fallback.
 *
 * Strategi download TikTok:
 *   1. tikwm.com API
 *   2. douyin.wtf / tiktok-dl API
 *   3. Cobalt API v10 fallback
 */
object LinkDownloader {

    enum class LinkType { TIKTOK, UNSUPPORTED }

    fun detectType(url: String): LinkType {
        val u = url.trim().lowercase()
        return when {
            u.contains("tiktok.com") || u.contains("vt.tiktok.com")
                || u.contains("vm.tiktok.com") -> LinkType.TIKTOK
            else -> LinkType.UNSUPPORTED
        }
    }

    data class DownloadResult(val stream: InputStream, val fileName: String, val mimeType: String)

    // OkHttpClient shared — connection pool, lebih cepat dari HttpURLConnection
    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .followRedirects(true)
            .retryOnConnectionFailure(true)
            .build()
    }

    fun download(rawUrl: String, type: LinkType): DownloadResult {
        return when (type) {
            LinkType.TIKTOK -> downloadTiktok(rawUrl)
            else -> throw IllegalArgumentException("Link tidak didukung. Gunakan link TikTok.")
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // COBALT INSTANCES — diperbarui 2025
    // ══════════════════════════════════════════════════════════════════════════

    private val COBALT_INSTANCES = listOf(
        "https://api.cobalt.tools",
        "https://cobalt.api.timelessnesses.me",
        "https://capi.bloatcat.xyz",
        "https://cobalt.ggtyler.dev",
        "https://cobalt.privacydev.net"
    )

    // ══════════════════════════════════════════════════════════════════════════
    // TIKTOK DOWNLOADER
    // ══════════════════════════════════════════════════════════════════════════

    private fun downloadTiktok(url: String): DownloadResult {
        var lastError = "Semua server TikTok gagal"

        try {
            val audioUrl = tryTikwm(url)
            if (audioUrl != null) return fetchStream(audioUrl, "tt_audio.mp3", "audio/mpeg")
        } catch (e: Exception) { lastError = e.message ?: "tikwm gagal" }

        try {
            val audioUrl = tryMusicalDown(url)
            if (audioUrl != null) return fetchStream(audioUrl, "tt_audio.mp3", "audio/mpeg")
        } catch (e: Exception) { lastError = e.message ?: "musicaldown gagal" }

        for (base in COBALT_INSTANCES) {
            try {
                val audioUrl = tryCobaltV10Instance(base, url)
                    ?: tryCobaltInstance("$base/api/json", buildCobaltBodyV7(url), "application/json")
                if (audioUrl != null) return fetchStream(audioUrl, "tt_audio.mp3", "audio/mpeg")
            } catch (e: Exception) { lastError = e.message ?: "cobalt gagal di $base" }
        }

        throw RuntimeException(
            "Gagal unduh audio TikTok.\n" +
            "Pastikan: link publik, bukan FYP private, & koneksi stabil.\n" +
            "Detail: $lastError"
        )
    }

    private fun tryTikwm(url: String): String? {
        val formBody = FormBody.Builder()
            .add("url", url.trim())
            .add("count", "12")
            .add("cursor", "0")
            .add("web", "1")
            .add("hd", "1")
            .build()

        val request = Request.Builder()
            .url("https://www.tikwm.com/api/")
            .addHeader("User-Agent", "Mozilla/5.0 (Android 14) RexyyUploader/4.0")
            .addHeader("Referer", "https://www.tikwm.com/")
            .post(formBody)
            .build()

        val raw = client.newCall(request).execute().use { resp ->
            if (!resp.isSuccessful) return null
            resp.body?.string()?.trim() ?: return null
        }
        if (raw.isBlank() || !raw.startsWith("{")) return null

        val j    = JSONObject(raw)
        val data = j.optJSONObject("data") ?: return null
        return data.optString("music_info")
            .takeIf { it.isNotBlank() }
            ?.let { runCatching { JSONObject(it).optString("play") }.getOrNull() }
            ?.takeIf { it.startsWith("http") }
            ?: data.optString("music").takeIf { it.startsWith("http") }
            ?: data.optString("hdplay").takeIf { it.startsWith("http") }
    }

    private fun tryMusicalDown(url: String): String? {
        val apis = listOf(
            "https://api.douyin.wtf/api?url=${URLEncoder.encode(url.trim(), "UTF-8")}&minimal=true",
            "https://tiktok-dl.siilas.workers.dev/?url=${URLEncoder.encode(url.trim(), "UTF-8")}"
        )
        for (apiUrl in apis) {
            try {
                val raw = httpGet(apiUrl)
                if (raw.isBlank() || !raw.startsWith("{")) continue
                val j = JSONObject(raw)
                val audio = j.optString("music_url").takeIf { it.startsWith("http") }
                    ?: j.optJSONObject("data")?.optString("music")?.takeIf { it.startsWith("http") }
                if (audio != null) return audio
            } catch (_: Exception) {}
        }
        return null
    }

    // ══════════════════════════════════════════════════════════════════════════
    // COBALT HELPERS
    // ══════════════════════════════════════════════════════════════════════════

    private fun buildCobaltBodyV7(url: String) = JSONObject().apply {
        put("url", url.trim())
        put("isAudioOnly", true)
        put("aFormat", "mp3")
        put("vQuality", "720")
        put("disableMetadata", false)
    }.toString()

    private fun tryCobaltV10Instance(baseUrl: String, videoUrl: String): String? {
        val body = JSONObject().apply {
            put("url", videoUrl.trim())
            put("downloadMode", "audio")
            put("audioFormat", "mp3")
            put("audioBitrate", "128")
        }.toString()

        val endpoint = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
        val request = Request.Builder()
            .url(endpoint)
            .addHeader("Content-Type", "application/json")
            .addHeader("Accept", "application/json")
            .addHeader("User-Agent", "Mozilla/5.0 (Android 14; Mobile) RexyyUploader/4.0")
            .post(body.toRequestBody("application/json".toMediaType()))
            .build()

        val raw = client.newCall(request).execute().use { resp ->
            if (!resp.isSuccessful) return null
            resp.body?.string()?.trim() ?: return null
        }
        if (raw.isBlank() || !raw.startsWith("{")) return null

        val j      = JSONObject(raw)
        val status = j.optString("status")
        return when (status) {
            "tunnel", "redirect", "stream" ->
                j.optString("url").takeIf { it.startsWith("http") }
            else -> null
        }
    }

    private fun tryCobaltInstance(endpoint: String, body: String, accept: String): String? {
        val request = Request.Builder()
            .url(endpoint)
            .addHeader("Content-Type", "application/json")
            .addHeader("Accept", accept)
            .addHeader("User-Agent", "Mozilla/5.0 (Android 14) RexyyUploader/4.0")
            .post(body.toRequestBody("application/json".toMediaType()))
            .build()

        val raw = client.newCall(request).execute().use { resp ->
            if (!resp.isSuccessful) return null
            resp.body?.string()?.trim() ?: return null
        }
        if (raw.isBlank() || !raw.startsWith("{")) return null

        val j      = JSONObject(raw)
        val status = j.optString("status")
        val dlUrl  = j.optString("url").takeIf { it.startsWith("http") }
            ?: j.optString("audio").takeIf { it.startsWith("http") }
        return when (status) {
            "tunnel", "redirect", "stream" -> dlUrl
            "error" -> null
            else -> dlUrl
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // HTTP HELPERS
    // ══════════════════════════════════════════════════════════════════════════

    private fun httpGet(url: String, userAgent: String = "Mozilla/5.0 RexyyUploader/4.0"): String {
        val request = Request.Builder()
            .url(url)
            .addHeader("User-Agent", userAgent)
            .get()
            .build()

        return client.newCall(request).execute().use { resp ->
            if (!resp.isSuccessful) throw RuntimeException("HTTP ${resp.code} dari $url")
            resp.body?.string() ?: ""
        }
    }

    fun fetchStream(url: String, fileName: String, mime: String): DownloadResult {
        val request = Request.Builder()
            .url(url)
            .addHeader("User-Agent", "Mozilla/5.0 (Android 14) RexyyUploader/4.0")
            .get()
            .build()

        // Tidak pakai .use{} karena stream harus tetap terbuka untuk dibaca di luar
        val response = client.newCall(request).execute()
        if (!response.isSuccessful) {
            response.close()
            throw RuntimeException("Download stream gagal HTTP ${response.code}")
        }
        val actualMime = response.body?.contentType()?.toString()
            ?.substringBefore(";")?.trim()?.takeIf { it.isNotBlank() } ?: mime
        val stream = response.body?.byteStream()
            ?: throw RuntimeException("Response body kosong")
        return DownloadResult(stream = stream, fileName = fileName, mimeType = actualMime)
    }
}
