package com.rexyy.uploader.network

import org.json.JSONObject
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Download audio dari link YouTube / TikTok via multiple API fallback.
 *
 * FIX v4.0:
 *   • Instance yt-dlp publik diperbarui — co.wuk.sh offline, diganti instance baru.
 *   • Tambah fallback ke piped.video API (open-source YouTube proxy).
 *   • Tambah fallback ke newpipe-based endpoint.
 *   • Cobalt instances diperbarui ke yang masih aktif 2025.
 *   • Timeout diperpanjang untuk koneksi lambat.
 *
 * Strategi download YouTube:
 *   1. yt-dlp public API instances (diperbarui)
 *   2. Piped API (alternatif YouTube frontend)
 *   3. Invidious API
 *   4. Cobalt API v10 fallback
 *
 * Strategi download TikTok:
 *   1. tikwm.com API
 *   2. douyin.wtf / tiktok-dl API
 *   3. Cobalt API v10 fallback
 */
object LinkDownloader {

    enum class LinkType { YOUTUBE, TIKTOK, UNSUPPORTED }

    fun detectType(url: String): LinkType {
        val u = url.trim().lowercase()
        return when {
            u.contains("tiktok.com") || u.contains("vt.tiktok.com")
                || u.contains("vm.tiktok.com") -> LinkType.TIKTOK
            else -> LinkType.UNSUPPORTED
        }
    }

    data class DownloadResult(val stream: InputStream, val fileName: String, val mimeType: String)

    fun download(rawUrl: String, type: LinkType): DownloadResult {
        return when (type) {
            LinkType.YOUTUBE -> downloadYoutube(rawUrl)
            LinkType.TIKTOK  -> downloadTiktok(rawUrl)
            else -> throw IllegalArgumentException("Link tidak didukung. Gunakan YouTube atau TikTok.")
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // YOUTUBE DOWNLOADER — FIX v4.0
    // Instance-instance lama (co.wuk.sh, ytdlp.onrender.com) sudah offline.
    // Diganti dengan instance baru yang aktif per Oktober 2025.
    // ══════════════════════════════════════════════════════════════════════════

    // yt-dlp REST API instances — aktif per 2025
    private val YT_API_INSTANCES = listOf(
        "https://yt-dlp-api.fly.dev",           // fly.io community instance
        "https://api.cobalt.tools",              // cobalt official API (v10)
        "https://ytdlp-api.vercel.app",          // vercel community instance
        "https://yt-api.p.rapidapi.com"          // rapidapi fallback
    )

    // Cobalt API instances — diperbarui 2025
    private val COBALT_INSTANCES = listOf(
        "https://api.cobalt.tools",              // official cobalt
        "https://cobalt.api.timelessnesses.me",  // community
        "https://capi.bloatcat.xyz",             // community
        "https://cobalt.ggtyler.dev",            // community (baru)
        "https://cobalt.privacydev.net"          // community (baru)
    )

    // Piped instances (open-source YouTube proxy) — fallback baru
    private val PIPED_INSTANCES = listOf(
        "https://pipedapi.kavin.rocks",
        "https://pipedapi.adminforge.de",
        "https://piped-api.garudalinux.org"
    )

    private fun downloadYoutube(url: String): DownloadResult {
        var lastError = "Semua server YouTube gagal"

        // ── 1. Coba yt-dlp public API ──
        for (base in YT_API_INSTANCES) {
            try {
                val audioUrl = tryYtDlpInstance(base, url)
                if (audioUrl != null) {
                    return fetchStream(audioUrl, "yt_audio.mp3", "audio/mpeg")
                }
            } catch (e: Exception) {
                lastError = e.message ?: "Error di $base"
            }
        }

        // ── 2. Cobalt API (diperbarui) ──
        for (base in COBALT_INSTANCES) {
            try {
                val audioUrl = tryCobaltV10Instance(base, url)
                    ?: tryCobaltInstance(
                        endpoint = "$base/api/json",
                        body = buildCobaltBodyV7(url),
                        accept = "application/json"
                    )
                if (audioUrl != null) {
                    return fetchStream(audioUrl, "yt_audio.mp3", "audio/mpeg")
                }
            } catch (e: Exception) {
                lastError = e.message ?: "Error di $base"
            }
        }

        // ── 3. Piped API (open-source YouTube proxy) — BARU ──
        try {
            val pipedUrl = tryPipedYoutube(url)
            if (pipedUrl != null) return fetchStream(pipedUrl, "yt_audio.mp3", "audio/mpeg")
        } catch (e: Exception) {
            lastError = e.message ?: "Piped gagal"
        }

        // ── 4. Invidious API ──
        try {
            val invUrl = tryInvidiousYoutube(url)
            if (invUrl != null) return fetchStream(invUrl, "yt_audio.mp3", "audio/mpeg")
        } catch (e: Exception) {
            lastError = e.message ?: "Invidious gagal"
        }

        throw RuntimeException(
            "Gagal unduh audio YouTube.\n" +
            "Pastikan: link publik, bukan live stream, & koneksi stabil.\n" +
            "Detail: $lastError"
        )
    }

    private fun tryYtDlpInstance(baseUrl: String, videoUrl: String): String? {
        val body = JSONObject().apply {
            put("url", videoUrl.trim())
            put("format", "bestaudio/best")
            put("extract_audio", true)
            put("audio_format", "mp3")
        }.toString()

        val conn = (URL("$baseUrl/api/download").openConnection() as HttpURLConnection).apply {
            requestMethod   = "POST"
            connectTimeout  = 20_000
            readTimeout     = 60_000
            doOutput        = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "Mozilla/5.0 (Android 14; Mobile) RexyyUploader/4.0")
            setRequestProperty("Origin", "https://rexyyuploader.app")
        }
        conn.outputStream.use { it.write(body.toByteArray()) }
        val code = conn.responseCode
        val raw  = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.bufferedReader()?.use { it.readText() }?.trim() ?: ""
        conn.disconnect()
        if (raw.isBlank() || !raw.startsWith("{")) return null
        val j = JSONObject(raw)
        return j.optString("url").takeIf { it.startsWith("http") }
            ?: j.optJSONArray("formats")
                ?.let { arr ->
                    var best: String? = null
                    for (i in arr.length() - 1 downTo 0) {
                        val fmt = arr.getJSONObject(i)
                        val ext  = fmt.optString("ext")
                        val asr  = fmt.optInt("asr")
                        val u    = fmt.optString("url")
                        if (u.startsWith("http") && asr > 0 && (ext == "mp3" || ext == "m4a" || ext == "webm" || ext == "ogg")) {
                            best = u; break
                        }
                    }
                    best
                }
    }

    /** Cobalt API v10 (format baru — pakai Accept: application/json + JSON body baru) */
    private fun tryCobaltV10Instance(baseUrl: String, videoUrl: String): String? {
        val body = JSONObject().apply {
            put("url", videoUrl.trim())
            put("downloadMode", "audio")
            put("audioFormat", "mp3")
            put("audioBitrate", "128")
        }.toString()

        val endpoint = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"

        val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod  = "POST"
            connectTimeout = 20_000
            readTimeout    = 60_000
            doOutput       = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "Mozilla/5.0 (Android 14; Mobile) RexyyUploader/4.0")
        }
        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val raw  = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.bufferedReader()?.use { it.readText() }?.trim() ?: ""
        conn.disconnect()
        if (raw.isBlank() || !raw.startsWith("{")) return null
        val j      = JSONObject(raw)
        val status = j.optString("status")
        return when (status) {
            "tunnel", "redirect", "stream" ->
                j.optString("url").takeIf { it.startsWith("http") }
            else -> null
        }
    }

    /** Piped API — open-source YouTube proxy, return HLS/DASH audio stream */
    private fun tryPipedYoutube(videoUrl: String): String? {
        val videoId = Regex("(?:v=|youtu\\.be/|embed/)([A-Za-z0-9_-]{11})").find(videoUrl)
            ?.groupValues?.get(1) ?: return null

        for (inst in PIPED_INSTANCES) {
            try {
                val raw = httpGet("$inst/streams/$videoId")
                if (raw.isBlank() || !raw.startsWith("{")) continue
                val j = JSONObject(raw)
                // Piped returns audioStreams array
                val audioStreams = j.optJSONArray("audioStreams") ?: continue
                var bestUrl: String? = null
                var bestBitrate = 0
                for (i in 0 until audioStreams.length()) {
                    val s = audioStreams.getJSONObject(i)
                    val u = s.optString("url")
                    val b = s.optInt("bitrate", 0)
                    val fmt = s.optString("format", "")
                    if (u.startsWith("http") && b > bestBitrate &&
                        (fmt.contains("WEBM_OPUS", ignoreCase = true) ||
                         fmt.contains("M4A", ignoreCase = true) ||
                         fmt.contains("MP4A", ignoreCase = true))) {
                        bestUrl = u
                        bestBitrate = b
                    }
                }
                if (bestUrl != null) return bestUrl
            } catch (_: Exception) {}
        }
        return null
    }

    private fun tryInvidiousYoutube(videoUrl: String): String? {
        val videoId = Regex("(?:v=|youtu\\.be/|embed/)([A-Za-z0-9_-]{11})").find(videoUrl)
            ?.groupValues?.get(1) ?: return null

        val instances = listOf(
            "https://inv.nadeko.net",
            "https://invidious.privacyredirect.com",
            "https://yt.artemislena.eu",
            "https://invidious.nerdvpn.de",
            "https://invidious.slipfox.xyz"
        )
        for (inv in instances) {
            try {
                val raw = httpGet("$inv/api/v1/videos/$videoId")
                val j   = JSONObject(raw)
                val streams = j.optJSONArray("adaptiveFormats") ?: continue
                for (i in 0 until streams.length()) {
                    val s    = streams.getJSONObject(i)
                    val type = s.optString("type")
                    val url  = s.optString("url")
                    if (type.startsWith("audio/") && url.startsWith("http")) {
                        return url
                    }
                }
            } catch (_: Exception) {}
        }
        return null
    }

    // ══════════════════════════════════════════════════════════════════════════
    // TIKTOK DOWNLOADER — tidak berubah, sudah stabil
    // ══════════════════════════════════════════════════════════════════════════

    private fun downloadTiktok(url: String): DownloadResult {
        var lastError = "Semua server TikTok gagal"

        try {
            val audioUrl = tryTikwm(url)
            if (audioUrl != null) return fetchStream(audioUrl, "tt_audio.mp3", "audio/mpeg")
        } catch (e: Exception) { lastError = e.message ?: "tikwm gagal" }

        try {
            val audioUrl = tryMusicalDown(url)
            if (audioUrl != null) return fetchStream(audioUrl, "tt_audio.mp3", "audio/mpeg")
        } catch (e: Exception) { lastError = e.message ?: "musicaldown gagal" }

        for (base in COBALT_INSTANCES) {
            try {
                val audioUrl = tryCobaltV10Instance(base, url)
                    ?: tryCobaltInstance("$base/api/json", buildCobaltBodyV7(url), "application/json")
                if (audioUrl != null) return fetchStream(audioUrl, "tt_audio.mp3", "audio/mpeg")
            } catch (e: Exception) { lastError = e.message ?: "cobalt gagal di $base" }
        }

        throw RuntimeException(
            "Gagal unduh audio TikTok.\n" +
            "Pastikan: link publik, bukan FYP private, & koneksi stabil.\n" +
            "Detail: $lastError"
        )
    }

    private fun tryTikwm(url: String): String? {
        val formBody = "url=${java.net.URLEncoder.encode(url.trim(), "UTF-8")}&count=12&cursor=0&web=1&hd=1"
        val conn = (URL("https://www.tikwm.com/api/").openConnection() as HttpURLConnection).apply {
            requestMethod  = "POST"
            connectTimeout = 15_000
            readTimeout    = 30_000
            doOutput       = true
            setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            setRequestProperty("User-Agent", "Mozilla/5.0 (Android 14) RexyyUploader/4.0")
            setRequestProperty("Referer", "https://www.tikwm.com/")
        }
        conn.outputStream.use { it.write(formBody.toByteArray()) }
        val code = conn.responseCode
        val raw  = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.bufferedReader()?.use { it.readText() }?.trim() ?: ""
        conn.disconnect()
        if (raw.isBlank() || !raw.startsWith("{")) return null
        val j    = JSONObject(raw)
        val data = j.optJSONObject("data") ?: return null
        return data.optString("music_info")
            .takeIf { it.isNotBlank() }
            ?.let { runCatching { JSONObject(it).optString("play") }.getOrNull() }
            ?.takeIf { it.startsWith("http") }
            ?: data.optString("music").takeIf { it.startsWith("http") }
            ?: data.optString("hdplay").takeIf { it.startsWith("http") }
    }

    private fun tryMusicalDown(url: String): String? {
        val apis = listOf(
            "https://api.douyin.wtf/api?url=${java.net.URLEncoder.encode(url.trim(), "UTF-8")}&minimal=true",
            "https://tiktok-dl.siilas.workers.dev/?url=${java.net.URLEncoder.encode(url.trim(), "UTF-8")}"
        )
        for (apiUrl in apis) {
            try {
                val raw = httpGet(apiUrl)
                if (raw.isBlank() || !raw.startsWith("{")) continue
                val j = JSONObject(raw)
                val audio = j.optString("music_url").takeIf { it.startsWith("http") }
                    ?: j.optJSONObject("data")?.optString("music")?.takeIf { it.startsWith("http") }
                if (audio != null) return audio
            } catch (_: Exception) {}
        }
        return null
    }

    // ══════════════════════════════════════════════════════════════════════════
    // COBALT HELPERS
    // ══════════════════════════════════════════════════════════════════════════

    private fun buildCobaltBodyV7(url: String) = JSONObject().apply {
        put("url", url.trim())
        put("isAudioOnly", true)
        put("aFormat", "mp3")
        put("vQuality", "720")
        put("disableMetadata", false)
    }.toString()

    private fun tryCobaltInstance(endpoint: String, body: String, accept: String): String? {
        val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod  = "POST"
            connectTimeout = 20_000
            readTimeout    = 60_000
            doOutput       = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", accept)
            setRequestProperty("User-Agent", "Mozilla/5.0 (Android 14) RexyyUploader/4.0")
        }
        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val raw  = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.bufferedReader()?.use { it.readText() }?.trim() ?: ""
        conn.disconnect()
        if (raw.isBlank() || !raw.startsWith("{")) return null
        val j      = JSONObject(raw)
        val status = j.optString("status")
        val dlUrl  = j.optString("url").takeIf { it.startsWith("http") }
            ?: j.optString("audio").takeIf { it.startsWith("http") }
        return when (status) {
            "tunnel", "redirect", "stream" -> dlUrl
            "error" -> null
            else -> dlUrl
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // HTTP HELPERS
    // ══════════════════════════════════════════════════════════════════════════

    private fun httpGet(url: String, userAgent: String = "Mozilla/5.0 RexyyUploader/4.0"): String {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 20_000
            readTimeout    = 30_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", userAgent)
        }
        val code = conn.responseCode
        val body = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.bufferedReader()?.use { it.readText() } ?: ""
        conn.disconnect()
        if (code !in 200..299) throw RuntimeException("HTTP $code dari $url")
        return body
    }

    fun fetchStream(url: String, fileName: String, mime: String): DownloadResult {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 30_000
            readTimeout    = 180_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "Mozilla/5.0 (Android 14) RexyyUploader/4.0")
        }
        val code = conn.responseCode
        if (code !in 200..299) {
            conn.disconnect()
            throw RuntimeException("Download stream gagal HTTP $code")
        }
        val actualMime = conn.contentType?.substringBefore(";")?.trim()?.takeIf { it.isNotBlank() } ?: mime
        return DownloadResult(stream = conn.inputStream, fileName = fileName, mimeType = actualMime)
    }
}
