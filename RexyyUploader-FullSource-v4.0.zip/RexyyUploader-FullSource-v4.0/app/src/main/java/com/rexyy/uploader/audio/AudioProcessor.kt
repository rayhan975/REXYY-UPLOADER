package com.rexyy.uploader.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * AudioProcessor — apply speed (tempo) + optimasi ukuran sebelum upload.
 *
 * Cara kerja speed:
 *   • WAV  → ubah sample rate di header (Roblox decode ulang → efek speed berubah).
 *   • MP3  → decode ke raw PCM 16-bit signed via MediaCodec, lalu buat WAV baru dengan
 *             sample rate yang sudah di-adjust. Hasilnya di-upload sebagai WAV
 *             sehingga Roblox memainkan dengan speed yang sesuai.
 *
 * Optimasi ukuran (biar upload lebih cepat):
 *   • Downsample ke 22050 Hz kalau sample rate asli > 22050 (Roblox tetap bagus di 22050)
 *   • Stereo → Mono (kurangi ukuran 50%) kalau file stereo
 *   • Khusus WAV: keduanya diterapkan otomatis
 *   • Khusus MP3 yang tidak kena speed: langsung upload as-is (MP3 sudah kecil)
 *
 * speedMultiplier:
 *   0.5f = setengah kecepatan, 1.0f = asli, 2.0f = dua kali lebih cepat
 *
 * CATATAN Roblox: sample rate max yang di-support = 44100 Hz.
 */
object AudioProcessor {

    private const val ROBLOX_MAX_SAMPLE_RATE = 44100
    private const val ROBLOX_MIN_SAMPLE_RATE = 8000
    // Target sample rate untuk optimasi — Roblox tetap jernih di 22050 Hz
    private const val OPTIMIZED_SAMPLE_RATE  = 22050

    /**
     * Apply speed + optimasi ke bytes audio. Return bytes baru yang sudah diproses.
     * Kalau speed == 1.0f dan file MP3, langsung return bytes asli (MP3 sudah kecil).
     * Kalau speed == 1.0f dan file WAV, tetap optimasi (downsample + mono).
     */
    fun applySpeed(bytes: ByteArray, speedMultiplier: Float, context: Context? = null): ByteArray {
        return when {
            isWav(bytes) -> applySpeedAndOptimizeWav(bytes, speedMultiplier)
            context != null -> applySpeedMp3(bytes, speedMultiplier, context)
            else -> bytes
        }
    }

    // ── WAV detection ──────────────────────────────────────────────────────────

    private fun isWav(bytes: ByteArray): Boolean {
        if (bytes.size < 12) return false
        val riff = String(bytes, 0, 4, Charsets.US_ASCII)
        val wave = String(bytes, 8, 4, Charsets.US_ASCII)
        return riff == "RIFF" && wave == "WAVE"
    }

    // ── WAV: speed + optimasi (downsample + stereo→mono) ──────────────────────
    private fun applySpeedAndOptimizeWav(bytes: ByteArray, speed: Float): ByteArray {
        // Parse WAV header untuk ambil info
        var fmtOffset = -1
        var dataOffset = -1
        var dataSize = 0
        var offset = 12

        while (offset + 8 < bytes.size) {
            val chunkId   = String(bytes, offset, 4, Charsets.US_ASCII)
            val chunkSize = ByteBuffer.wrap(bytes, offset + 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
            if (chunkId == "fmt ") fmtOffset = offset
            if (chunkId == "data") { dataOffset = offset + 8; dataSize = chunkSize }
            offset += 8 + chunkSize
            if (offset % 2 != 0) offset++ // word alignment
        }

        if (fmtOffset < 0 || dataOffset < 0 || dataSize <= 0) {
            // Tidak bisa parse WAV, fallback ke speed-only via header rewrite
            return applySpeedWavHeaderOnly(bytes, speed)
        }

        val audioFormat   = ByteBuffer.wrap(bytes, fmtOffset + 8,  2).order(ByteOrder.LITTLE_ENDIAN).short.toInt()
        val numChannels   = ByteBuffer.wrap(bytes, fmtOffset + 10, 2).order(ByteOrder.LITTLE_ENDIAN).short.toInt()
        val origSampleRate= ByteBuffer.wrap(bytes, fmtOffset + 12, 4).order(ByteOrder.LITTLE_ENDIAN).int
        val bitsPerSample = ByteBuffer.wrap(bytes, fmtOffset + 22, 2).order(ByteOrder.LITTLE_ENDIAN).short.toInt()

        // Hanya proses PCM 16-bit (audioFormat == 1)
        if (audioFormat != 1 || bitsPerSample != 16) {
            return applySpeedWavHeaderOnly(bytes, speed)
        }

        val pcmData = bytes.copyOfRange(dataOffset, dataOffset + dataSize)

        // === OPTIMASI 1: Stereo → Mono (kurangi ukuran 50%) ===
        val (monoPcm, monoChannels) = if (numChannels == 2) {
            Pair(stereoToMono(pcmData), 1)
        } else {
            Pair(pcmData, numChannels)
        }

        // === OPTIMASI 2: Downsample ke 22050 Hz kalau > 22050 ===
        // Speed juga diterapkan di sini: newSampleRate = origSampleRate / speed
        val speedAdjustedRate = (origSampleRate / speed).toInt()
            .coerceIn(ROBLOX_MIN_SAMPLE_RATE, ROBLOX_MAX_SAMPLE_RATE)

        // Kalau setelah speed adjustment masih > 22050, downsample
        val finalSampleRate = if (speedAdjustedRate > OPTIMIZED_SAMPLE_RATE) {
            // Downsample dengan simple decimation
            OPTIMIZED_SAMPLE_RATE
        } else {
            speedAdjustedRate
        }

        val finalPcm = if (speedAdjustedRate > OPTIMIZED_SAMPLE_RATE) {
            // Downsample PCM dari speedAdjustedRate ke 22050
            downsamplePcm(monoPcm, speedAdjustedRate, OPTIMIZED_SAMPLE_RATE, monoChannels)
        } else {
            monoPcm
        }

        return buildWav(finalPcm, finalSampleRate, monoChannels, 16)
    }

    // Fallback: cuma ubah sample rate di header (tanpa decode ulang PCM)
    private fun applySpeedWavHeaderOnly(bytes: ByteArray, speed: Float): ByteArray {
        if (speed == 1.0f) return bytes
        val output = bytes.copyOf()
        var offset = 12
        while (offset + 8 < output.size) {
            val chunkId   = String(output, offset, 4, Charsets.US_ASCII)
            val chunkSize = ByteBuffer.wrap(output, offset + 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
            if (chunkId == "fmt ") {
                val srOffset = offset + 8
                if (srOffset + 4 <= output.size) {
                    val origSr = ByteBuffer.wrap(output, srOffset, 4).order(ByteOrder.LITTLE_ENDIAN).int
                    val newSr  = (origSr / speed).toInt().coerceIn(ROBLOX_MIN_SAMPLE_RATE, ROBLOX_MAX_SAMPLE_RATE)
                    val srBuf  = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN)
                    srBuf.putInt(newSr)
                    srBuf.array().copyInto(output, srOffset)
                    val brOffset = srOffset + 4
                    if (brOffset + 4 <= output.size) {
                        val numChannels   = ByteBuffer.wrap(output, offset + 10, 2).order(ByteOrder.LITTLE_ENDIAN).short.toInt()
                        val bitsPerSample = if (offset + 22 < output.size)
                            ByteBuffer.wrap(output, offset + 22, 2).order(ByteOrder.LITTLE_ENDIAN).short.toInt() else 16
                        val newByteRate = newSr * numChannels * bitsPerSample / 8
                        val brBuf = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN)
                        brBuf.putInt(newByteRate)
                        brBuf.array().copyInto(output, brOffset)
                    }
                }
                break
            }
            offset += 8 + chunkSize
        }
        return output
    }

    // ── Stereo → Mono: rata-rata channel kiri + kanan ─────────────────────────
    private fun stereoToMono(stereoBytes: ByteArray): ByteArray {
        val sampleCount = stereoBytes.size / 4 // 2 channel × 2 bytes per sample
        val mono = ByteArray(sampleCount * 2)
        val inBuf  = ByteBuffer.wrap(stereoBytes).order(ByteOrder.LITTLE_ENDIAN)
        val outBuf = ByteBuffer.wrap(mono).order(ByteOrder.LITTLE_ENDIAN)
        repeat(sampleCount) {
            val left  = inBuf.short.toInt()
            val right = inBuf.short.toInt()
            outBuf.putShort(((left + right) / 2).toShort())
        }
        return mono
    }

    // ── Simple downsample via decimation ──────────────────────────────────────
    // Ambil setiap N-th sample. Cukup untuk audio Roblox (tidak perlu anti-alias filter).
    private fun downsamplePcm(
        pcm: ByteArray,
        fromRate: Int,
        toRate: Int,
        channels: Int
    ): ByteArray {
        if (fromRate <= toRate) return pcm
        val ratio = fromRate.toDouble() / toRate.toDouble()
        val bytesPerSample = 2 // 16-bit
        val frameSize = channels * bytesPerSample
        val inputFrames = pcm.size / frameSize
        val outputFrames = (inputFrames / ratio).toInt()
        val out = ByteArray(outputFrames * frameSize)
        val inBuf  = ByteBuffer.wrap(pcm).order(ByteOrder.LITTLE_ENDIAN)
        val outBuf = ByteBuffer.wrap(out).order(ByteOrder.LITTLE_ENDIAN)
        var inputPos = 0.0
        repeat(outputFrames) {
            val frameIdx = inputPos.toInt().coerceIn(0, inputFrames - 1)
            val byteIdx  = frameIdx * frameSize
            repeat(channels) { ch ->
                val sampleIdx = byteIdx + ch * bytesPerSample
                if (sampleIdx + 1 < pcm.size) {
                    val sample = ByteBuffer.wrap(pcm, sampleIdx, 2).order(ByteOrder.LITTLE_ENDIAN).short
                    outBuf.putShort(sample)
                } else {
                    outBuf.putShort(0)
                }
            }
            inputPos += ratio
        }
        return out
    }

    // ── MP3 speed processing via MediaCodec decode → WAV encode ───────────────
    private fun applySpeedMp3(bytes: ByteArray, speed: Float, context: Context): ByteArray {
        val tmpFile = File(context.cacheDir, "_speed_proc_${System.currentTimeMillis()}.mp3")
        return try {
            tmpFile.writeBytes(bytes)
            val pcmData = decodeMp3ToPcm(tmpFile.absolutePath)
                ?: return bytes

            val sampleRate   = pcmData.sampleRate
            val channelCount = pcmData.channelCount
            val pcmBytes     = pcmData.data

            // Speed adjustment: divide by speed
            val speedAdjustedRate = (sampleRate / speed).toInt()
                .coerceIn(ROBLOX_MIN_SAMPLE_RATE, ROBLOX_MAX_SAMPLE_RATE)

            // === OPTIMASI: Stereo → Mono ===
            val (processedPcm, finalChannels) = if (channelCount == 2) {
                Pair(stereoToMono(pcmBytes), 1)
            } else {
                Pair(pcmBytes, channelCount)
            }

            // === OPTIMASI: Downsample ke 22050 Hz kalau perlu ===
            val (finalPcm, finalRate) = if (speedAdjustedRate > OPTIMIZED_SAMPLE_RATE) {
                Pair(
                    downsamplePcm(processedPcm, speedAdjustedRate, OPTIMIZED_SAMPLE_RATE, finalChannels),
                    OPTIMIZED_SAMPLE_RATE
                )
            } else {
                Pair(processedPcm, speedAdjustedRate)
            }

            buildWav(finalPcm, finalRate, finalChannels, bitsPerSample = 16)
        } catch (_: Exception) {
            bytes
        } finally {
            tmpFile.delete()
        }
    }

    private data class PcmData(
        val data: ByteArray,
        val sampleRate: Int,
        val channelCount: Int,
        val isFloat: Boolean = false
    )

    private fun decodeMp3ToPcm(filePath: String): PcmData? {
        val extractor = MediaExtractor()
        return try {
            extractor.setDataSource(filePath)
            var audioTrackIndex = -1
            var audioFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val fmt  = extractor.getTrackFormat(i)
                val mime = fmt.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) { audioTrackIndex = i; audioFormat = fmt; break }
            }
            if (audioTrackIndex < 0 || audioFormat == null) return null

            val mime         = audioFormat.getString(MediaFormat.KEY_MIME)!!
            val sampleRate   = audioFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            val channelCount = audioFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)

            extractor.selectTrack(audioTrackIndex)
            val codec = MediaCodec.createDecoderByType(mime)
            codec.configure(audioFormat, null, null, 0)
            codec.start()

            val outputStream = ByteArrayOutputStream()
            val bufferInfo   = MediaCodec.BufferInfo()
            var inputDone    = false
            var outputDone   = false
            var isFloat      = false

            while (!outputDone) {
                if (!inputDone) {
                    val inputIdx = codec.dequeueInputBuffer(10_000)
                    if (inputIdx >= 0) {
                        val inputBuf   = codec.getInputBuffer(inputIdx)!!
                        val sampleSize = extractor.readSampleData(inputBuf, 0)
                        if (sampleSize < 0) {
                            codec.queueInputBuffer(inputIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inputIdx, 0, sampleSize, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val outputIdx = codec.dequeueOutputBuffer(bufferInfo, 10_000)
                if (outputIdx >= 0) {
                    val outBuf = codec.getOutputBuffer(outputIdx)!!
                    if (bufferInfo.size > 0) {
                        val chunk = ByteArray(bufferInfo.size)
                        outBuf.get(chunk)
                        outputStream.write(chunk)
                    }
                    codec.releaseOutputBuffer(outputIdx, false)
                    if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                } else if (outputIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val outFmt = codec.outputFormat
                    val pcmEncoding = try {
                        outFmt.getInteger(MediaFormat.KEY_PCM_ENCODING)
                    } catch (_: Exception) { android.media.AudioFormat.ENCODING_PCM_16BIT }
                    isFloat = (pcmEncoding == android.media.AudioFormat.ENCODING_PCM_FLOAT)
                }
            }

            codec.stop(); codec.release()
            var pcmBytes = outputStream.toByteArray()
            if (pcmBytes.isEmpty()) return null
            if (isFloat) pcmBytes = floatPcmToInt16(pcmBytes)
            PcmData(pcmBytes, sampleRate, channelCount, isFloat = false)
        } catch (_: Exception) { null }
        finally { extractor.release() }
    }

    private fun floatPcmToInt16(floatBytes: ByteArray): ByteArray {
        val floatCount = floatBytes.size / 4
        val out   = ByteArray(floatCount * 2)
        val inBuf  = ByteBuffer.wrap(floatBytes).order(ByteOrder.LITTLE_ENDIAN)
        val outBuf = ByteBuffer.wrap(out).order(ByteOrder.LITTLE_ENDIAN)
        repeat(floatCount) {
            val f = inBuf.float.coerceIn(-1f, 1f)
            outBuf.putShort((f * 32767f).toInt().toShort())
        }
        return out
    }

    private fun buildWav(pcmData: ByteArray, sampleRate: Int, channelCount: Int, bitsPerSample: Int): ByteArray {
        val byteRate   = sampleRate * channelCount * bitsPerSample / 8
        val blockAlign = channelCount * bitsPerSample / 8
        val dataSize   = pcmData.size
        val buf = ByteBuffer.allocate(44 + dataSize).order(ByteOrder.LITTLE_ENDIAN)
        buf.put("RIFF".toByteArray(Charsets.US_ASCII))
        buf.putInt(36 + dataSize)
        buf.put("WAVE".toByteArray(Charsets.US_ASCII))
        buf.put("fmt ".toByteArray(Charsets.US_ASCII))
        buf.putInt(16)
        buf.putShort(1)
        buf.putShort(channelCount.toShort())
        buf.putInt(sampleRate)
        buf.putInt(byteRate)
        buf.putShort(blockAlign.toShort())
        buf.putShort(bitsPerSample.toShort())
        buf.put("data".toByteArray(Charsets.US_ASCII))
        buf.putInt(dataSize)
        buf.put(pcmData)
        return buf.array()
    }
}
