package com.rexyy.uploader.audio

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * AudioProcessor — apply speed (tempo) ke ByteArray audio sebelum upload ke Roblox.
 *
 * Pipeline per format:
 *   WAV  → rewrite sample rate di header → output WAV (cepat, no decode)
 *   MP3/AAC/M4A → decode PCM via MediaCodec decoder
 *                → encode ulang ke AAC via MediaCodec encoder (sample rate * speed)
 *                → mux ke container M4A via MediaMuxer
 *                → output M4A kecil & cepat upload, fingerprint beda dari asli
 *
 * Kenapa AAC/M4A bukan WAV:
 *   PCM mentah lagu 3 menit ≈ 30 MB → upload lama.
 *   AAC 128 kbps lagu 3 menit ≈ 2.8 MB → upload cepat ≈ sama seperti MP3 asli.
 *
 * speedMultiplier:
 *   0.5f = setengah kecepatan, 1.0f = asli (no-op), 2.0f = dua kali lebih cepat
 */
object AudioProcessor {

    data class ProcessedAudio(
        val bytes: ByteArray,
        val mimeType: String,   // "audio/mp4" kalau hasil encode AAC
        val fileName: String    // nama file yang disarankan untuk upload
    )

    // ── Entry point utama ──────────────────────────────────────────────────────

    fun applySpeed(
        bytes: ByteArray,
        speed: Float,
        origMime: String = "audio/mpeg",
        origName: String = "audio.mp3",
        cacheDir: File? = null
    ): ProcessedAudio {
        if (speed == 1.0f) return ProcessedAudio(bytes, origMime, origName)

        return if (isWav(bytes)) {
            val result = applySpeedWav(bytes, speed)
            ProcessedAudio(result, "audio/wav", toName(origName, "wav"))
        } else {
            // MP3/AAC → decode PCM → encode AAC baru dengan SR * speed
            val tmpDir = cacheDir ?: File(System.getProperty("java.io.tmpdir") ?: "/tmp")
            val result = transcodeToAac(bytes, speed, tmpDir)
                ?: return ProcessedAudio(bytes, origMime, origName) // fallback ori
            ProcessedAudio(result, "audio/mp4", toName(origName, "m4a"))
        }
    }

    // Backward-compat — kode lama yang panggil applySpeed(bytes, speed)
    fun applySpeed(bytes: ByteArray, speed: Float): ByteArray =
        applySpeed(bytes, speed, "audio/mpeg", "audio.mp3", null).bytes

    // ── WAV detection ──────────────────────────────────────────────────────────

    fun isWav(bytes: ByteArray): Boolean {
        if (bytes.size < 12) return false
        return String(bytes, 0, 4, Charsets.US_ASCII) == "RIFF" &&
               String(bytes, 8, 4, Charsets.US_ASCII) == "WAVE"
    }

    // ── Nama file helper ───────────────────────────────────────────────────────

    private fun toName(orig: String, ext: String): String {
        val base = orig.substringBeforeLast('.').ifBlank { "audio" }
        return "${base}_speed.$ext"
    }

    // ── WAV speed processing via sample rate rewrite ───────────────────────────

    private fun applySpeedWav(bytes: ByteArray, speed: Float): ByteArray {
        val output = bytes.copyOf()
        var offset = 12
        while (offset + 8 < output.size) {
            val chunkId   = String(output, offset, 4, Charsets.US_ASCII)
            val chunkSize = ByteBuffer.wrap(output, offset + 4, 4)
                                .order(ByteOrder.LITTLE_ENDIAN).int
            if (chunkId == "fmt ") {
                val srOffset = offset + 8
                if (srOffset + 4 <= output.size) {
                    val origSr = ByteBuffer.wrap(output, srOffset, 4)
                                    .order(ByteOrder.LITTLE_ENDIAN).int
                    val newSr  = (origSr * speed).toInt().coerceIn(8000, 192000)
                    ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN)
                        .putInt(newSr).array().copyInto(output, srOffset)

                    val brOffset = srOffset + 4
                    if (brOffset + 4 <= output.size) {
                        val ch  = ByteBuffer.wrap(output, offset + 10, 2)
                                    .order(ByteOrder.LITTLE_ENDIAN).short.toInt()
                        val bps = if (offset + 22 < output.size)
                                    ByteBuffer.wrap(output, offset + 22, 2)
                                        .order(ByteOrder.LITTLE_ENDIAN).short.toInt()
                                  else 16
                        ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN)
                            .putInt(newSr * ch * bps / 8).array()
                            .copyInto(output, brOffset)
                    }
                }
                break
            }
            offset += 8 + chunkSize
        }
        return output
    }

    // ── Transcode MP3 → PCM → AAC/M4A dengan sample rate baru ────────────────
    //
    // Flow:
    //   1. Tulis bytes ke temp file (MediaExtractor butuh file path)
    //   2. Decode MP3 → PCM 16-bit via MediaCodec decoder
    //   3. Encode PCM → AAC via MediaCodec encoder (sampleRate * speed)
    //   4. Mux AAC frames ke output M4A via MediaMuxer
    //   5. Baca output M4A ke ByteArray, hapus temp files

    private fun transcodeToAac(bytes: ByteArray, speed: Float, tmpDir: File): ByteArray? {
        val inFile  = File(tmpDir, "rexyy_in_${System.currentTimeMillis()}.tmp")
        val outFile = File(tmpDir, "rexyy_out_${System.currentTimeMillis()}.m4a")
        return try {
            FileOutputStream(inFile).use { it.write(bytes) }
            doTranscode(inFile, outFile, speed)
            if (outFile.exists() && outFile.length() > 0) outFile.readBytes() else null
        } catch (e: Exception) {
            null
        } finally {
            inFile.delete()
            outFile.delete()
        }
    }

    private fun doTranscode(inFile: File, outFile: File, speed: Float) {
        // ── STEP 1: Baca info track dari input ────────────────────────────────
        val extractor = MediaExtractor()
        extractor.setDataSource(inFile.absolutePath)

        var trackIdx = -1
        var inFormat: MediaFormat? = null
        for (i in 0 until extractor.trackCount) {
            val fmt  = extractor.getTrackFormat(i)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("audio/")) { trackIdx = i; inFormat = fmt; break }
        }
        if (trackIdx < 0 || inFormat == null) {
            extractor.release(); return
        }
        extractor.selectTrack(trackIdx)

        val inMime       = inFormat.getString(MediaFormat.KEY_MIME)!!
        val origSr       = inFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        val channelCount = inFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        val newSr        = (origSr * speed).toInt().coerceIn(8000, 96000)

        // ── STEP 2: Setup decoder MP3 → PCM ──────────────────────────────────
        val decoder = MediaCodec.createDecoderByType(inMime)
        decoder.configure(inFormat, null, null, 0)
        decoder.start()

        // ── STEP 3: Setup encoder PCM → AAC ──────────────────────────────────
        val encFormat = MediaFormat.createAudioFormat("audio/mp4a-latm", newSr, channelCount)
        encFormat.setInteger(MediaFormat.KEY_AAC_PROFILE, 2)   // AAC-LC
        encFormat.setInteger(MediaFormat.KEY_BIT_RATE, 128_000) // 128 kbps
        encFormat.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)

        val encoder = MediaCodec.createEncoderByType("audio/mp4a-latm")
        encoder.configure(encFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        encoder.start()

        // ── STEP 4: Setup muxer ───────────────────────────────────────────────
        val muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var muxTrack   = -1
        var muxStarted = false

        // ── STEP 5: Decode loop → pipe PCM ke encoder ────────────────────────
        val decInfo = MediaCodec.BufferInfo()
        val encInfo = MediaCodec.BufferInfo()
        var decInputDone  = false
        var decOutputDone = false
        var encInputDone  = false
        var encOutputDone = false

        // PCM queue sederhana — buffer antar decoder output dan encoder input
        val pcmQueue = ByteArrayOutputStream()

        while (!encOutputDone) {

            // — Feed decoder input —
            if (!decInputDone) {
                val idx = decoder.dequeueInputBuffer(5_000L)
                if (idx >= 0) {
                    val buf  = decoder.getInputBuffer(idx)!!
                    val read = extractor.readSampleData(buf, 0)
                    if (read < 0) {
                        decoder.queueInputBuffer(idx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        decInputDone = true
                    } else {
                        decoder.queueInputBuffer(idx, 0, read, extractor.sampleTime, 0)
                        extractor.advance()
                    }
                }
            }

            // — Drain decoder output → PCM queue —
            if (!decOutputDone) {
                val idx = decoder.dequeueOutputBuffer(decInfo, 5_000L)
                if (idx >= 0) {
                    val buf = decoder.getOutputBuffer(idx)!!
                    if (decInfo.size > 0) {
                        val chunk = ByteArray(decInfo.size)
                        buf.get(chunk)
                        pcmQueue.write(chunk)
                    }
                    decoder.releaseOutputBuffer(idx, false)
                    if (decInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0)
                        decOutputDone = true
                }
            }

            // — Feed encoder input dari PCM queue —
            if (!encInputDone) {
                val idx = encoder.dequeueInputBuffer(5_000L)
                if (idx >= 0) {
                    val encBuf   = encoder.getInputBuffer(idx)!!
                    val capacity = encBuf.capacity()
                    val pcmBytes = pcmQueue.toByteArray()

                    if (pcmBytes.isEmpty() && decOutputDone) {
                        // PCM habis dan decoder selesai → kirim EOS ke encoder
                        encoder.queueInputBuffer(idx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        encInputDone = true
                    } else if (pcmBytes.isNotEmpty()) {
                        val toWrite = minOf(capacity, pcmBytes.size)
                        encBuf.put(pcmBytes, 0, toWrite)
                        encoder.queueInputBuffer(idx, 0, toWrite, 0, 0)
                        // Sisa PCM yang belum dikirim → reset queue
                        pcmQueue.reset()
                        if (toWrite < pcmBytes.size)
                            pcmQueue.write(pcmBytes, toWrite, pcmBytes.size - toWrite)
                    }
                }
            }

            // — Drain encoder output → muxer —
            val idx = encoder.dequeueOutputBuffer(encInfo, 5_000L)
            if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                val outFmt = encoder.outputFormat
                muxTrack   = muxer.addTrack(outFmt)
                muxer.start()
                muxStarted = true
            } else if (idx >= 0) {
                val outBuf = encoder.getOutputBuffer(idx)!!
                if (encInfo.size > 0 && muxStarted &&
                    encInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0) {
                    outBuf.position(encInfo.offset)
                    outBuf.limit(encInfo.offset + encInfo.size)
                    muxer.writeSampleData(muxTrack, outBuf, encInfo)
                }
                encoder.releaseOutputBuffer(idx, false)
                if (encInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0)
                    encOutputDone = true
            }
        }

        // ── STEP 6: Cleanup ───────────────────────────────────────────────────
        decoder.stop(); decoder.release()
        encoder.stop(); encoder.release()
        extractor.release()
        if (muxStarted) { muxer.stop(); muxer.release() }
    }

    // ── WAV builder (masih dipakai untuk WAV input) ───────────────────────────

    fun buildWav(pcm: ByteArray, channelCount: Int, sampleRate: Int, bitsPerSample: Int = 16): ByteArray {
        val byteRate   = sampleRate * channelCount * bitsPerSample / 8
        val blockAlign = channelCount * bitsPerSample / 8
        val dataSize   = pcm.size
        val out = ByteArrayOutputStream(44 + dataSize)
        val buf = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        buf.put("RIFF".toByteArray(Charsets.US_ASCII))
        buf.putInt(36 + dataSize)
        buf.put("WAVE".toByteArray(Charsets.US_ASCII))
        buf.put("fmt ".toByteArray(Charsets.US_ASCII))
        buf.putInt(16); buf.putShort(1)
        buf.putShort(channelCount.toShort())
        buf.putInt(sampleRate); buf.putInt(byteRate)
        buf.putShort(blockAlign.toShort())
        buf.putShort(bitsPerSample.toShort())
        buf.put("data".toByteArray(Charsets.US_ASCII))
        buf.putInt(dataSize)
        out.write(buf.array()); out.write(pcm)
        return out.toByteArray()
    }
}
