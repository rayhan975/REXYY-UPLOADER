package com.rexyy.uploader.audio

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * AudioProcessor — apply speed (tempo) ke ByteArray audio sebelum upload.
 *
 * Cara kerja speed:
 *   • WAV  → ubah sample rate di header (Roblox decode ulang → efek speed berubah).
 *   • MP3  → return bytes asli (MP3 butuh full decode untuk speed change — tidak
 *             dilakukan di sini supaya tidak corrupt file).
 *
 * speedMultiplier:
 *   0.5f = setengah kecepatan, 1.0f = asli, 2.0f = dua kali lebih cepat
 */
object AudioProcessor {

    /**
     * Apply speed ke bytes audio. Return bytes baru yang sudah diproses.
     * Kalau speed == 1.0f, langsung return bytes asli (no-op).
     */
    fun applySpeed(bytes: ByteArray, speedMultiplier: Float): ByteArray {
        if (speedMultiplier == 1.0f) return bytes
        return if (isWav(bytes)) applySpeedWav(bytes, speedMultiplier)
        else bytes // MP3/AAC: return original, speed applied via playbackParams preview only
    }

    // ── WAV detection ──────────────────────────────────────────────────────────

    private fun isWav(bytes: ByteArray): Boolean {
        if (bytes.size < 12) return false
        val riff = String(bytes, 0, 4, Charsets.US_ASCII)
        val wave = String(bytes, 8, 4, Charsets.US_ASCII)
        return riff == "RIFF" && wave == "WAVE"
    }

    // ── WAV speed processing via sample rate rewrite ───────────────────────────
    // Mengubah sample rate di header WAV sehingga Roblox decode dengan tempo berbeda.
    // Ini cara yang paling aman & tidak menyebabkan distorsi pada data audio.

    private fun applySpeedWav(bytes: ByteArray, speed: Float): ByteArray {
        val output = bytes.copyOf()

        // Cari fmt chunk untuk baca & tulis ulang sample rate
        var offset = 12
        while (offset + 8 < output.size) {
            val chunkId   = String(output, offset, 4, Charsets.US_ASCII)
            val chunkSize = ByteBuffer.wrap(output, offset + 4, 4).order(ByteOrder.LITTLE_ENDIAN).int

            if (chunkId == "fmt ") {
                // Sample rate: 4 byte di offset+8 dari awal chunk
                val srOffset = offset + 8
                if (srOffset + 4 <= output.size) {
                    val origSr = ByteBuffer.wrap(output, srOffset, 4).order(ByteOrder.LITTLE_ENDIAN).int
                    val newSr  = (origSr * speed).toInt().coerceIn(8000, 192000)

                    // Tulis sample rate baru
                    val srBuf = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN)
                    srBuf.putInt(newSr)
                    val srBytes = srBuf.array()
                    srBytes.copyInto(output, srOffset)

                    // Byte rate = sampleRate * numChannels * bitsPerSample/8
                    // Letaknya 4 byte setelah sample rate
                    val brOffset = srOffset + 4
                    if (brOffset + 4 <= output.size) {
                        val numChannels   = ByteBuffer.wrap(output, offset + 10, 2).order(ByteOrder.LITTLE_ENDIAN).short.toInt()
                        val bitsPerSample = if (offset + 22 < output.size)
                            ByteBuffer.wrap(output, offset + 22, 2).order(ByteOrder.LITTLE_ENDIAN).short.toInt()
                        else 16
                        val newByteRate = newSr * numChannels * bitsPerSample / 8
                        val brBuf = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN)
                        brBuf.putInt(newByteRate)
                        brBuf.array().copyInto(output, brOffset)
                    }
                }
                break
            }
            offset += 8 + chunkSize
        }

        return output
    }
}
