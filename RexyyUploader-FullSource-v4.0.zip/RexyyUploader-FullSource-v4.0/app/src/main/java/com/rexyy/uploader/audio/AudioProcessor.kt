package com.rexyy.uploader.audio

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * AudioProcessor v2 — apply volume gain ke ByteArray audio sebelum upload.
 *
 * WAV  → proses langsung di PCM samples (lossless, akurat).
 * MP3/AAC → decode via MediaCodec → apply gain di PCM → encode ulang ke AAC/MP4
 *           supaya Roblox bisa terima dan volume benar-benar berubah.
 *
 * gainMultiplier:
 *   0.5f = 50%, 1.0f = normal, 1.5f = 150% (boost)
 */
object AudioProcessor {

    fun applyGain(bytes: ByteArray, gainMultiplier: Float): ByteArray {
        if (gainMultiplier == 1.0f) return bytes
        return if (isWav(bytes)) {
            applyGainWav(bytes, gainMultiplier)
        } else {
            applyGainEncoded(bytes, gainMultiplier)
        }
    }

    // ── WAV detection ──────────────────────────────────────────────────────────

    private fun isWav(bytes: ByteArray): Boolean {
        if (bytes.size < 12) return false
        val riff = String(bytes, 0, 4, Charsets.US_ASCII)
        val wave = String(bytes, 8, 4, Charsets.US_ASCII)
        return riff == "RIFF" && wave == "WAVE"
    }

    // ── WAV PCM gain processing ────────────────────────────────────────────────

    private fun applyGainWav(bytes: ByteArray, gain: Float): ByteArray {
        var dataOffset = 12
        while (dataOffset + 8 < bytes.size) {
            val chunkId   = String(bytes, dataOffset, 4, Charsets.US_ASCII)
            val chunkSize = ByteBuffer.wrap(bytes, dataOffset + 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
            if (chunkId == "data") { dataOffset += 8; break }
            dataOffset += 8 + chunkSize
        }
        val bitsPerSample = findBitsPerSample(bytes)
        val output = bytes.copyOf()
        val buf = ByteBuffer.wrap(output, dataOffset, output.size - dataOffset).order(ByteOrder.LITTLE_ENDIAN)
        if (bitsPerSample == 16) {
            val numSamples = (output.size - dataOffset) / 2
            repeat(numSamples) {
                if (buf.remaining() >= 2) {
                    val sample = buf.short.toInt()
                    val amplified = (sample * gain).toInt().coerceIn(-32768, 32767)
                    val pos = buf.position() - 2
                    output[dataOffset + pos]     = (amplified and 0xFF).toByte()
                    output[dataOffset + pos + 1] = ((amplified shr 8) and 0xFF).toByte()
                }
            }
        } else if (bitsPerSample == 8) {
            for (i in dataOffset until output.size) {
                val sample = (output[i].toInt() and 0xFF) - 128
                val amplified = (sample * gain).toInt().coerceIn(-128, 127)
                output[i] = (amplified + 128).toByte()
            }
        }
        return output
    }

    private fun findBitsPerSample(bytes: ByteArray): Int {
        var offset = 12
        while (offset + 8 < bytes.size) {
            val chunkId   = String(bytes, offset, 4, Charsets.US_ASCII)
            val chunkSize = ByteBuffer.wrap(bytes, offset + 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
            if (chunkId == "fmt ") {
                return if (offset + 22 < bytes.size)
                    ByteBuffer.wrap(bytes, offset + 22, 2).order(ByteOrder.LITTLE_ENDIAN).short.toInt()
                else 16
            }
            offset += 8 + chunkSize
        }
        return 16
    }

    // ── MP3/AAC → decode PCM → apply gain → encode AAC ────────────────────────

    private fun applyGainEncoded(bytes: ByteArray, gain: Float): ByteArray {
        return try {
            // Tulis bytes ke temp file supaya MediaExtractor bisa baca
            val tmpInput = File.createTempFile("aud_in_", ".mp3")
            val tmpOutput = File.createTempFile("aud_out_", ".m4a")
            tmpInput.writeBytes(bytes)

            // --- DECODE ---
            val extractor = MediaExtractor()
            extractor.setDataSource(tmpInput.absolutePath)

            var audioTrackIdx = -1
            var inputFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val fmt = extractor.getTrackFormat(i)
                val mime = fmt.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    audioTrackIdx = i
                    inputFormat = fmt
                    break
                }
            }
            if (audioTrackIdx == -1 || inputFormat == null) {
                tmpInput.delete(); tmpOutput.delete()
                return bytes
            }
            extractor.selectTrack(audioTrackIdx)

            val mime = inputFormat.getString(MediaFormat.KEY_MIME)!!
            val decoder = MediaCodec.createDecoderByType(mime)
            decoder.configure(inputFormat, null, null, 0)
            decoder.start()

            // --- ENCODE ---
            val sampleRate  = inputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            val channelCount = inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val encFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, channelCount).apply {
                setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
                setInteger(MediaFormat.KEY_AAC_PROFILE, android.media.MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            }
            val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            encoder.configure(encFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            encoder.start()

            val muxer = MediaMuxer(tmpOutput.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            var muxerTrack = -1
            var muxerStarted = false

            val pcmBuffer = ByteArrayOutputStream()
            val bufInfo = MediaCodec.BufferInfo()
            var decEOS = false
            var encEOS = false

            // Decode seluruh audio ke PCM dulu
            while (!decEOS) {
                val inIdx = decoder.dequeueInputBuffer(10_000)
                if (inIdx >= 0) {
                    val inBuf = decoder.getInputBuffer(inIdx)!!
                    val sampleSize = extractor.readSampleData(inBuf, 0)
                    if (sampleSize < 0) {
                        decoder.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        decEOS = true
                    } else {
                        decoder.queueInputBuffer(inIdx, 0, sampleSize, extractor.sampleTime, 0)
                        extractor.advance()
                    }
                }
                var outIdx = decoder.dequeueOutputBuffer(bufInfo, 10_000)
                while (outIdx >= 0) {
                    val outBuf = decoder.getOutputBuffer(outIdx)!!
                    val chunk = ByteArray(bufInfo.size)
                    outBuf.get(chunk)
                    pcmBuffer.write(chunk)
                    decoder.releaseOutputBuffer(outIdx, false)
                    if (bufInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) break
                    outIdx = decoder.dequeueOutputBuffer(bufInfo, 10_000)
                }
            }
            decoder.stop(); decoder.release(); extractor.release()

            // Apply gain ke PCM (16-bit little-endian)
            val pcmBytes = pcmBuffer.toByteArray()
            val gainedPcm = ByteArray(pcmBytes.size)
            val pcmBuf = ByteBuffer.wrap(pcmBytes).order(ByteOrder.LITTLE_ENDIAN)
            val gainBuf = ByteBuffer.wrap(gainedPcm).order(ByteOrder.LITTLE_ENDIAN)
            while (pcmBuf.remaining() >= 2) {
                val sample = pcmBuf.short.toInt()
                val amplified = (sample * gain).toInt().coerceIn(-32768, 32767)
                gainBuf.putShort(amplified.toShort())
            }

            // Encode PCM → AAC
            var pcmOffset = 0
            while (!encEOS) {
                val inIdx = encoder.dequeueInputBuffer(10_000)
                if (inIdx >= 0) {
                    val inBuf = encoder.getInputBuffer(inIdx)!!
                    inBuf.clear()
                    if (pcmOffset < gainedPcm.size) {
                        val toWrite = minOf(inBuf.capacity(), gainedPcm.size - pcmOffset)
                        inBuf.put(gainedPcm, pcmOffset, toWrite)
                        pcmOffset += toWrite
                        encoder.queueInputBuffer(inIdx, 0, toWrite, 0, 0)
                    } else {
                        encoder.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    }
                }
                var outIdx = encoder.dequeueOutputBuffer(bufInfo, 10_000)
                while (outIdx >= 0 || outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        if (!muxerStarted) {
                            muxerTrack = muxer.addTrack(encoder.outputFormat)
                            muxer.start(); muxerStarted = true
                        }
                    } else if (outIdx >= 0) {
                        val outBuf = encoder.getOutputBuffer(outIdx)!!
                        if (bufInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0 && muxerStarted) {
                            muxer.writeSampleData(muxerTrack, outBuf, bufInfo)
                        }
                        encoder.releaseOutputBuffer(outIdx, false)
                        if (bufInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                            encEOS = true; break
                        }
                    }
                    outIdx = encoder.dequeueOutputBuffer(bufInfo, 10_000)
                }
            }
            encoder.stop(); encoder.release()
            if (muxerStarted) muxer.stop()
            muxer.release()

            val result = tmpOutput.readBytes()
            tmpInput.delete(); tmpOutput.delete()
            if (result.isNotEmpty()) result else bytes
        } catch (e: Exception) {
            // Fallback: return original if encode fails
            bytes
        }
    }
}
