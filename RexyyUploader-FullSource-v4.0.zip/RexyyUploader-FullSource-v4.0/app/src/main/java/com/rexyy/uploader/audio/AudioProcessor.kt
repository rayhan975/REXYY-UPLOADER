package com.rexyy.uploader.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * AudioProcessor — apply speed (tempo) ke ByteArray audio sebelum upload.
 *
 * Cara kerja speed:
 *   • WAV  → ubah sample rate di header (Roblox decode ulang → efek speed berubah).
 *   • MP3  → decode ke raw PCM 16-bit signed via MediaCodec, lalu buat WAV baru dengan
 *             sample rate yang sudah di-adjust. Hasilnya di-upload sebagai WAV
 *             sehingga Roblox memainkan dengan speed yang sesuai.
 *
 * speedMultiplier:
 *   0.5f = setengah kecepatan, 1.0f = asli, 2.0f = dua kali lebih cepat
 *
 * CATATAN Roblox: sample rate max yang di-support = 44100 Hz.
 * Untuk speed > 1x, sample rate akan dikurangi (audio lebih cepat = lebih sedikit samples/sec
 * yang dibutuhkan dari perspektif Roblox).
 * Rumus: newSampleRate = originalSampleRate / speedMultiplier  (bukan dikali)
 * Kenapa: jika speed 2x, kita upload file dengan sample rate SETENGAHNYA.
 * Roblox akan play 44100 samples/sec tapi data kita hanya menyimpan 22050 samples/sec → play 2x lebih cepat.
 */
object AudioProcessor {

    // Roblox max supported sample rate
    private const val ROBLOX_MAX_SAMPLE_RATE = 44100
    private const val ROBLOX_MIN_SAMPLE_RATE = 8000

    /**
     * Apply speed ke bytes audio. Return bytes baru yang sudah diproses.
     * Kalau speed == 1.0f, langsung return bytes asli (no-op).
     */
    fun applySpeed(bytes: ByteArray, speedMultiplier: Float, context: Context? = null): ByteArray {
        if (speedMultiplier == 1.0f) return bytes
        return when {
            isWav(bytes) -> applySpeedWav(bytes, speedMultiplier)
            context != null -> applySpeedMp3(bytes, speedMultiplier, context)
            else -> bytes
        }
    }

    // ── WAV detection ──────────────────────────────────────────────────────────

    private fun isWav(bytes: ByteArray): Boolean {
        if (bytes.size < 12) return false
        val riff = String(bytes, 0, 4, Charsets.US_ASCII)
        val wave = String(bytes, 8, 4, Charsets.US_ASCII)
        return riff == "RIFF" && wave == "WAVE"
    }

    // ── WAV speed processing via sample rate rewrite ───────────────────────────
    // Mengubah sample rate di header WAV.
    // PENTING: newSampleRate = origSampleRate / speed (bukan dikali!)
    // Contoh: speed 2x, orig 44100Hz → stored 22050Hz
    //   Roblox baca: "ini 22050 samples/sec" → diputar 44100/sec nyata → 2x lebih cepat ✓
    // Ini tetap dalam range Roblox (max 44100Hz).

    private fun applySpeedWav(bytes: ByteArray, speed: Float): ByteArray {
        val output = bytes.copyOf()

        var offset = 12
        while (offset + 8 < output.size) {
            val chunkId   = String(output, offset, 4, Charsets.US_ASCII)
            val chunkSize = ByteBuffer.wrap(output, offset + 4, 4).order(ByteOrder.LITTLE_ENDIAN).int

            if (chunkId == "fmt ") {
                val srOffset = offset + 8
                if (srOffset + 4 <= output.size) {
                    val origSr = ByteBuffer.wrap(output, srOffset, 4).order(ByteOrder.LITTLE_ENDIAN).int
                    // Divide by speed (not multiply) — stays within Roblox range
                    val newSr  = (origSr / speed).toInt().coerceIn(ROBLOX_MIN_SAMPLE_RATE, ROBLOX_MAX_SAMPLE_RATE)

                    val srBuf = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN)
                    srBuf.putInt(newSr)
                    val srBytes = srBuf.array()
                    srBytes.copyInto(output, srOffset)

                    val brOffset = srOffset + 4
                    if (brOffset + 4 <= output.size) {
                        val numChannels   = ByteBuffer.wrap(output, offset + 10, 2).order(ByteOrder.LITTLE_ENDIAN).short.toInt()
                        val bitsPerSample = if (offset + 22 < output.size)
                            ByteBuffer.wrap(output, offset + 22, 2).order(ByteOrder.LITTLE_ENDIAN).short.toInt()
                        else 16
                        val newByteRate = newSr * numChannels * bitsPerSample / 8
                        val brBuf = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN)
                        brBuf.putInt(newByteRate)
                        brBuf.array().copyInto(output, brOffset)
                    }
                }
                break
            }
            offset += 8 + chunkSize
        }

        return output
    }

    // ── MP3 speed processing via MediaCodec decode → WAV encode ───────────────
    // Decode MP3 ke raw PCM 16-bit signed, lalu buat WAV baru dengan sample rate
    // yang sudah di-adjust (sample rate / speed). Roblox akan decode WAV dan
    // memainkan dengan speed yang sesuai.

    private fun applySpeedMp3(bytes: ByteArray, speed: Float, context: Context): ByteArray {
        val tmpFile = File(context.cacheDir, "_speed_proc_${System.currentTimeMillis()}.mp3")
        return try {
            tmpFile.writeBytes(bytes)
            val pcmData = decodeMp3ToPcm(tmpFile.absolutePath)
                ?: return bytes

            val sampleRate   = pcmData.sampleRate
            val channelCount = pcmData.channelCount
            val pcmBytes     = pcmData.data

            // Divide by speed — stays within Roblox supported range
            val newSampleRate = (sampleRate / speed).toInt().coerceIn(ROBLOX_MIN_SAMPLE_RATE, ROBLOX_MAX_SAMPLE_RATE)

            buildWav(pcmBytes, newSampleRate, channelCount, bitsPerSample = 16)
        } catch (_: Exception) {
            bytes
        } finally {
            tmpFile.delete()
        }
    }

    private data class PcmData(
        val data: ByteArray,
        val sampleRate: Int,
        val channelCount: Int,
        val isFloat: Boolean = false
    )

    private fun decodeMp3ToPcm(filePath: String): PcmData? {
        val extractor = MediaExtractor()
        return try {
            extractor.setDataSource(filePath)

            var audioTrackIndex = -1
            var audioFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val fmt = extractor.getTrackFormat(i)
                val mime = fmt.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    audioFormat = fmt
                    break
                }
            }
            if (audioTrackIndex < 0 || audioFormat == null) return null

            val mime         = audioFormat.getString(MediaFormat.KEY_MIME)!!
            val sampleRate   = audioFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            val channelCount = audioFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)

            extractor.selectTrack(audioTrackIndex)

            val codec = MediaCodec.createDecoderByType(mime)
            codec.configure(audioFormat, null, null, 0)
            codec.start()

            val outputStream = ByteArrayOutputStream()
            val bufferInfo   = MediaCodec.BufferInfo()
            var inputDone    = false
            var outputDone   = false
            var isFloat      = false

            while (!outputDone) {
                if (!inputDone) {
                    val inputIdx = codec.dequeueInputBuffer(10_000)
                    if (inputIdx >= 0) {
                        val inputBuf = codec.getInputBuffer(inputIdx)!!
                        val sampleSize = extractor.readSampleData(inputBuf, 0)
                        if (sampleSize < 0) {
                            codec.queueInputBuffer(inputIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inputIdx, 0, sampleSize, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                val outputIdx = codec.dequeueOutputBuffer(bufferInfo, 10_000)
                if (outputIdx >= 0) {
                    val outBuf = codec.getOutputBuffer(outputIdx)!!
                    if (bufferInfo.size > 0) {
                        val chunk = ByteArray(bufferInfo.size)
                        outBuf.get(chunk)
                        outputStream.write(chunk)
                    }
                    codec.releaseOutputBuffer(outputIdx, false)
                    if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                        outputDone = true
                    }
                } else if (outputIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    // Cek apakah output PCM float atau 16-bit integer
                    val outFmt = codec.outputFormat
                    val pcmEncoding = try {
                        outFmt.getInteger(MediaFormat.KEY_PCM_ENCODING)
                    } catch (_: Exception) {
                        android.media.AudioFormat.ENCODING_PCM_16BIT
                    }
                    isFloat = (pcmEncoding == android.media.AudioFormat.ENCODING_PCM_FLOAT)
                }
            }

            codec.stop()
            codec.release()

            var pcmBytes = outputStream.toByteArray()
            if (pcmBytes.isEmpty()) return null

            // Kalau float PCM (32-bit), konversi ke 16-bit signed integer
            if (isFloat) {
                pcmBytes = floatPcmToInt16(pcmBytes)
            }

            PcmData(pcmBytes, sampleRate, channelCount, isFloat = false)

        } catch (_: Exception) {
            null
        } finally {
            extractor.release()
        }
    }

    /**
     * Konversi raw float PCM (32-bit little-endian) ke 16-bit signed PCM.
     * Float range: -1.0f..1.0f → Short range: -32768..32767
     */
    private fun floatPcmToInt16(floatBytes: ByteArray): ByteArray {
        val floatCount = floatBytes.size / 4
        val out = ByteArray(floatCount * 2)
        val inBuf  = ByteBuffer.wrap(floatBytes).order(ByteOrder.LITTLE_ENDIAN)
        val outBuf = ByteBuffer.wrap(out).order(ByteOrder.LITTLE_ENDIAN)
        repeat(floatCount) {
            val f = inBuf.float.coerceIn(-1f, 1f)
            outBuf.putShort((f * 32767f).toInt().toShort())
        }
        return out
    }

    // ── WAV builder dari raw PCM 16-bit ───────────────────────────────────────

    private fun buildWav(pcmData: ByteArray, sampleRate: Int, channelCount: Int, bitsPerSample: Int): ByteArray {
        val byteRate    = sampleRate * channelCount * bitsPerSample / 8
        val blockAlign  = channelCount * bitsPerSample / 8
        val dataSize    = pcmData.size
        val chunkSize   = 36 + dataSize

        val buf = ByteBuffer.allocate(44 + dataSize).order(ByteOrder.LITTLE_ENDIAN)

        buf.put("RIFF".toByteArray(Charsets.US_ASCII))
        buf.putInt(chunkSize)
        buf.put("WAVE".toByteArray(Charsets.US_ASCII))

        buf.put("fmt ".toByteArray(Charsets.US_ASCII))
        buf.putInt(16)
        buf.putShort(1)                         // PCM = 1
        buf.putShort(channelCount.toShort())
        buf.putInt(sampleRate)
        buf.putInt(byteRate)
        buf.putShort(blockAlign.toShort())
        buf.putShort(bitsPerSample.toShort())

        buf.put("data".toByteArray(Charsets.US_ASCII))
        buf.putInt(dataSize)
        buf.put(pcmData)

        return buf.array()
    }
}
