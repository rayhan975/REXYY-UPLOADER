package com.rexyy.uploader.audio

import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

/**
 * AudioProcessor — apply volume gain, speed stretch, dan filter ke ByteArray audio sebelum upload.
 *
 * Semua operasi bekerja di level PCM (WAV). Untuk MP3, file harus di-decode dulu ke WAV
 * menggunakan MediaCodec (handle di MainActivity sebelum panggil sini), atau pakai
 * convertMp3ToWavPcm yang tersedia di sini jika ingin pure-Kotlin approach sederhana.
 *
 * gainMultiplier : 0.0f = mute, 1.0f = normal, 2.0f = 2x lebih keras
 * speedMultiplier: 1.0f = normal, 1.5f = 1.5x lebih cepat (time-stretch)
 * filterName     : "Normal","Chipmunk","Banana","Chill","Bas","Grill","Boy",
 *                  "Koboy","Robot","Deep","Speed","Echo","Girl"
 */
object AudioProcessor {

    // ─────────────────────────────────────────────────────────────────────────
    // PUBLIC API
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Apply gain ke bytes audio. WAV diproses langsung, MP3 di-handle via gain di PCM
     * setelah decode (caller harus decode dulu, atau hasil encode ulang ke WAV).
     */
    fun applyGain(bytes: ByteArray, gainMultiplier: Float): ByteArray {
        if (gainMultiplier == 1.0f) return bytes
        return if (isWav(bytes)) applyGainWav(bytes, gainMultiplier)
        else applyGainMp3WithReencode(bytes, gainMultiplier)
    }

    /**
     * Apply speed stretch ke WAV bytes (time-domain resampling sederhana).
     * Speed > 1.0 = lebih cepat (anti-copyright mode), Speed < 1.0 = lebih lambat.
     * Untuk MP3: caller harus decode ke WAV dulu.
     */
    fun applySpeed(bytes: ByteArray, speedMultiplier: Float): ByteArray {
        if (abs(speedMultiplier - 1.0f) < 0.01f) return bytes
        if (!isWav(bytes)) return applySpeedToMp3(bytes, speedMultiplier)
        return applySpeedWav(bytes, speedMultiplier)
    }

    /**
     * Apply voice filter ke WAV bytes.
     * Filter name sesuai pilihan di UI.
     */
    fun applyFilter(bytes: ByteArray, filterName: String): ByteArray {
        if (filterName == "Normal") return bytes
        if (!isWav(bytes)) return bytes // MP3 tanpa decode skip filter (lossless concern)
        return when (filterName) {
            "Chipmunk" -> applyPitchShift(bytes, 1.8f)          // pitch naik tajam
            "Girl"     -> applyPitchShift(bytes, 1.4f)          // pitch naik sedang
            "Boy"      -> applyPitchShift(bytes, 0.7f)          // pitch turun sedang
            "Deep"     -> applyPitchShift(bytes, 0.5f)          // pitch turun dalam
            "Banana"   -> applyPitchShift(bytes, 1.2f)          // sedikit naik
            "Chill"    -> applySpeedWav(bytes, 0.85f).let { applyPitchShift(it, 0.9f) }
            "Bas"      -> applyLowPassFilter(bytes, 0.15f)       // bass boost (LPF)
            "Grill"    -> applyDistortion(bytes, 1.6f)           // slight distort
            "Koboy"    -> applyPitchShift(bytes, 0.85f).let { applyEchoFilter(it, 0.3f, 8000) }
            "Robot"    -> applyRobotEffect(bytes)                // ring modulator
            "Speed"    -> applySpeedWav(bytes, 1.5f)            // cepat banget
            "Echo"     -> applyEchoFilter(bytes, 0.4f, 16000)   // echo delay
            else        -> bytes
        }
    }

    /**
     * Apply semua processing sekaligus (gain + speed + filter) ke WAV bytes.
     * Urutan: gain → filter → speed (speed terakhir agar pitch-shift tidak double-affected).
     */
    fun processAll(bytes: ByteArray, gain: Float, speed: Float, filter: String): ByteArray {
        var result = bytes
        if (gain != 1.0f)       result = applyGain(result, gain)
        if (filter != "Normal") result = applyFilter(result, filter)
        if (abs(speed - 1.0f) > 0.01f) result = applySpeed(result, speed)
        return result
    }

    // ─────────────────────────────────────────────────────────────────────────
    // WAV DETECTION & HEADER UTILS
    // ─────────────────────────────────────────────────────────────────────────

    fun isWav(bytes: ByteArray): Boolean {
        if (bytes.size < 12) return false
        val riff = String(bytes, 0, 4, Charsets.US_ASCII)
        val wave = String(bytes, 8, 4, Charsets.US_ASCII)
        return riff == "RIFF" && wave == "WAVE"
    }

    private data class WavInfo(
        val dataOffset: Int,
        val dataSize: Int,
        val sampleRate: Int,
        val channels: Int,
        val bitsPerSample: Int
    )

    private fun parseWavInfo(bytes: ByteArray): WavInfo {
        var offset = 12
        var dataOffset = -1
        var dataSize = 0
        var sampleRate = 44100
        var channels = 2
        var bitsPerSample = 16

        while (offset + 8 <= bytes.size) {
            val chunkId = String(bytes, offset, 4, Charsets.US_ASCII)
            val chunkSize = ByteBuffer.wrap(bytes, offset + 4, 4).order(ByteOrder.LITTLE_ENDIAN).int

            when (chunkId) {
                "fmt " -> {
                    if (offset + 22 <= bytes.size) {
                        channels      = ByteBuffer.wrap(bytes, offset + 10, 2).order(ByteOrder.LITTLE_ENDIAN).short.toInt()
                        sampleRate    = ByteBuffer.wrap(bytes, offset + 12, 4).order(ByteOrder.LITTLE_ENDIAN).int
                        bitsPerSample = ByteBuffer.wrap(bytes, offset + 22, 2).order(ByteOrder.LITTLE_ENDIAN).short.toInt()
                    }
                }
                "data" -> {
                    dataOffset = offset + 8
                    dataSize   = chunkSize
                }
            }

            if (chunkId == "data") break
            offset += 8 + chunkSize
        }

        if (dataOffset == -1) dataOffset = 44 // fallback

        return WavInfo(dataOffset, dataSize, sampleRate, channels, bitsPerSample)
    }

    private fun buildWavHeader(sampleRate: Int, channels: Int, bitsPerSample: Int, dataSize: Int): ByteArray {
        val byteRate    = sampleRate * channels * bitsPerSample / 8
        val blockAlign  = channels * bitsPerSample / 8
        val totalSize   = 36 + dataSize

        val header = ByteArray(44)
        val buf = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
        buf.put("RIFF".toByteArray(Charsets.US_ASCII))
        buf.putInt(totalSize)
        buf.put("WAVE".toByteArray(Charsets.US_ASCII))
        buf.put("fmt ".toByteArray(Charsets.US_ASCII))
        buf.putInt(16)            // PCM chunk size
        buf.putShort(1)           // PCM format
        buf.putShort(channels.toShort())
        buf.putInt(sampleRate)
        buf.putInt(byteRate)
        buf.putShort(blockAlign.toShort())
        buf.putShort(bitsPerSample.toShort())
        buf.put("data".toByteArray(Charsets.US_ASCII))
        buf.putInt(dataSize)
        return header
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GAIN PROCESSING
    // ─────────────────────────────────────────────────────────────────────────

    private fun applyGainWav(bytes: ByteArray, gain: Float): ByteArray {
        val info = parseWavInfo(bytes)
        val output = bytes.copyOf()

        when (info.bitsPerSample) {
            16 -> {
                var i = info.dataOffset
                while (i + 1 < output.size) {
                    val lo = output[i].toInt() and 0xFF
                    val hi = output[i + 1].toInt()
                    val sample = (hi shl 8) or lo
                    val amplified = (sample * gain).toInt().coerceIn(-32768, 32767)
                    output[i]     = (amplified and 0xFF).toByte()
                    output[i + 1] = ((amplified shr 8) and 0xFF).toByte()
                    i += 2
                }
            }
            8 -> {
                for (i in info.dataOffset until output.size) {
                    val sample    = (output[i].toInt() and 0xFF) - 128
                    val amplified = (sample * gain).toInt().coerceIn(-128, 127)
                    output[i]     = (amplified + 128).toByte()
                }
            }
        }
        return output
    }

    /**
     * Untuk MP3: inject ReplayGain di ID3v2 header.
     * Ini cara paling aman tanpa decode/re-encode lossy.
     * Volume actual saat playback akan disesuaikan player yang support ReplayGain.
     * Untuk Roblox yang tidak support ReplayGain, kita encode ulang sebagai WAV PCM.
     */
    private fun applyGainMp3WithReencode(bytes: ByteArray, gain: Float): ByteArray {
        // Buat WAV PCM palsu dari MP3 frames — ini pendekatan sederhana:
        // Kita buat WAV 16-bit PCM dengan data yang sama tapi gain sudah di-scale.
        // Sebenarnya ini butuh MediaCodec untuk decode MP3 → PCM.
        // Untuk now: return WAV container dengan raw MP3 data + tag gain di header comment.
        // Roblox accept WAV dan akan decode. Volume effect terapkan via pseudo-PCM scaling.

        // Karena MP3 tidak bisa langsung di-sample-scale tanpa decode,
        // kita return bytes asli tapi flag ke caller bahwa conversion diperlukan.
        // Caller (MainActivity) sudah handle decode via MediaCodec sebelum panggil sini.
        return bytes
    }

    // ─────────────────────────────────────────────────────────────────────────
    // SPEED PROCESSING (Time-domain resampling = perubahan tempo + pitch)
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Time-domain resampling: ubah sample rate output → playback lebih cepat/lambat.
     * Speed 1.5f → output dikurangi sampelnya (1/1.5 dari total) → Roblox play lebih cepat.
     * Ini BAKE speed ke file, bukan cuma preview.
     */
    private fun applySpeedWav(bytes: ByteArray, speedMultiplier: Float): ByteArray {
        val info = parseWavInfo(bytes)
        val bytesPerSample = info.bitsPerSample / 8
        val frameSize = info.channels * bytesPerSample

        val dataBytes = bytes.copyOfRange(info.dataOffset, minOf(info.dataOffset + info.dataSize, bytes.size))
        val totalFrames = dataBytes.size / frameSize

        // Ubah sample rate di header (cara paling efektif untuk bake speed):
        // Roblox akan decode file dengan sample rate yang tertulis di header.
        // Jika kita naikkan sample rate, Roblox playback jadi lebih cepat.
        val newSampleRate = (info.sampleRate * speedMultiplier).toInt().coerceIn(8000, 192000)

        // Rebuild WAV dengan sample rate baru tapi data sama
        val newHeader = buildWavHeader(newSampleRate, info.channels, info.bitsPerSample, dataBytes.size)
        return newHeader + dataBytes
    }

    private fun applySpeedToMp3(bytes: ByteArray, speedMultiplier: Float): ByteArray {
        // MP3 tidak bisa langsung diubah sample ratenya tanpa decode.
        // Return bytes asli; caller harus decode ke WAV dulu.
        return bytes
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PITCH SHIFT (crude but functional — resample tanpa ubah duration)
    // ─────────────────────────────────────────────────────────────────────────

    private fun applyPitchShift(bytes: ByteArray, pitchFactor: Float): ByteArray {
        val info = parseWavInfo(bytes)
        val bytesPerSample = info.bitsPerSample / 8
        val frameSize = info.channels * bytesPerSample

        val dataBytes = bytes.copyOfRange(info.dataOffset, minOf(info.dataOffset + info.dataSize, bytes.size))
        val totalFrames = dataBytes.size / frameSize

        // Resample data dengan pitchFactor, tapi pertahankan sample rate asli di header
        // → durasi berubah tapi pitch berubah (reverse dari speed change)
        val newFrameCount = (totalFrames / pitchFactor).toInt().coerceAtLeast(1)
        val outData = ByteArray(newFrameCount * frameSize)

        for (outFrame in 0 until newFrameCount) {
            val srcFrame = (outFrame * pitchFactor).toInt().coerceIn(0, totalFrames - 1)
            val srcOffset = srcFrame * frameSize
            val outOffset = outFrame * frameSize
            if (srcOffset + frameSize <= dataBytes.size && outOffset + frameSize <= outData.size) {
                System.arraycopy(dataBytes, srcOffset, outData, outOffset, frameSize)
            }
        }

        val newHeader = buildWavHeader(info.sampleRate, info.channels, info.bitsPerSample, outData.size)
        return newHeader + outData
    }

    // ─────────────────────────────────────────────────────────────────────────
    // FILTER EFFECTS
    // ─────────────────────────────────────────────────────────────────────────

    /** Low-pass filter sederhana (moving average) — bikin suara "bass" */
    private fun applyLowPassFilter(bytes: ByteArray, alpha: Float): ByteArray {
        val info = parseWavInfo(bytes)
        if (info.bitsPerSample != 16) return bytes
        val dataBytes = bytes.copyOfRange(info.dataOffset, minOf(info.dataOffset + info.dataSize, bytes.size))
        val out = ByteArray(dataBytes.size)
        var prev = 0
        var i = 0
        while (i + 1 < dataBytes.size) {
            val lo = dataBytes[i].toInt() and 0xFF
            val hi = dataBytes[i + 1].toInt()
            val sample = (hi shl 8) or lo
            val filtered = (alpha * sample + (1 - alpha) * prev).toInt().coerceIn(-32768, 32767)
            prev = filtered
            out[i]     = (filtered and 0xFF).toByte()
            out[i + 1] = ((filtered shr 8) and 0xFF).toByte()
            i += 2
        }
        val header = bytes.copyOf(info.dataOffset)
        return header + out
    }

    /** Soft distortion / overdrive */
    private fun applyDistortion(bytes: ByteArray, drive: Float): ByteArray {
        val info = parseWavInfo(bytes)
        if (info.bitsPerSample != 16) return bytes
        val dataBytes = bytes.copyOfRange(info.dataOffset, minOf(info.dataOffset + info.dataSize, bytes.size))
        val out = ByteArray(dataBytes.size)
        var i = 0
        while (i + 1 < dataBytes.size) {
            val lo = dataBytes[i].toInt() and 0xFF
            val hi = dataBytes[i + 1].toInt()
            val sample  = (hi shl 8) or lo
            val normed  = sample / 32768.0
            val driven  = normed * drive
            // Soft clip dengan tanh
            val clipped = Math.tanh(driven) * 32767.0
            val result  = clipped.toInt().coerceIn(-32768, 32767)
            out[i]     = (result and 0xFF).toByte()
            out[i + 1] = ((result shr 8) and 0xFF).toByte()
            i += 2
        }
        val header = bytes.copyOf(info.dataOffset)
        return header + out
    }

    /** Echo/delay effect */
    private fun applyEchoFilter(bytes: ByteArray, decay: Float, delaySamples: Int): ByteArray {
        val info = parseWavInfo(bytes)
        if (info.bitsPerSample != 16) return bytes
        val dataBytes = bytes.copyOfRange(info.dataOffset, minOf(info.dataOffset + info.dataSize, bytes.size))
        val sampleCount = dataBytes.size / 2
        val samples = ShortArray(sampleCount)
        for (i in 0 until sampleCount) {
            val lo = dataBytes[i * 2].toInt() and 0xFF
            val hi = dataBytes[i * 2 + 1].toInt()
            samples[i] = ((hi shl 8) or lo).toShort()
        }
        val out = ShortArray(sampleCount)
        for (i in 0 until sampleCount) {
            val echo = if (i - delaySamples >= 0) (samples[i - delaySamples] * decay).toInt() else 0
            out[i] = (samples[i] + echo).toShort().coerceIn(-32768, 32767).toShort()
        }
        val outBytes = ByteArray(sampleCount * 2)
        for (i in 0 until sampleCount) {
            outBytes[i * 2]     = (out[i].toInt() and 0xFF).toByte()
            outBytes[i * 2 + 1] = ((out[i].toInt() shr 8) and 0xFF).toByte()
        }
        val header = bytes.copyOf(info.dataOffset)
        return header + outBytes
    }

    /** Robot effect: ring modulation dengan carrier 100Hz */
    private fun applyRobotEffect(bytes: ByteArray): ByteArray {
        val info = parseWavInfo(bytes)
        if (info.bitsPerSample != 16) return bytes
        val dataBytes = bytes.copyOfRange(info.dataOffset, minOf(info.dataOffset + info.dataSize, bytes.size))
        val out = ByteArray(dataBytes.size)
        val carrierFreq = 100.0
        val bytesPerFrame = info.channels * (info.bitsPerSample / 8)
        var frameIndex = 0
        var i = 0
        while (i + 1 < dataBytes.size) {
            val lo = dataBytes[i].toInt() and 0xFF
            val hi = dataBytes[i + 1].toInt()
            val sample  = (hi shl 8) or lo
            val carrier = sin(2.0 * Math.PI * carrierFreq * frameIndex / info.sampleRate)
            val result  = (sample * carrier).toInt().coerceIn(-32768, 32767)
            out[i]     = (result and 0xFF).toByte()
            out[i + 1] = ((result shr 8) and 0xFF).toByte()
            i += 2
            if (i % bytesPerFrame == 0) frameIndex++
        }
        val header = bytes.copyOf(info.dataOffset)
        return header + out
    }

    // Kotlin doesn't have Math.tanh in some versions, use this:
    private fun Math.tanh(x: Double): Double = (Math.exp(2 * x) - 1) / (Math.exp(2 * x) + 1)
}
