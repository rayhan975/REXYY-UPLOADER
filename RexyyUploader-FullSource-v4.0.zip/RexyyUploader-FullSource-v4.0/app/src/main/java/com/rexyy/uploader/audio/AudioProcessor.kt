package com.rexyy.uploader.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * AudioProcessor — apply speed (tempo) ke ByteArray audio sebelum upload.
 *
 * Cara kerja speed:
 *   • WAV  → ubah sample rate di header (Roblox decode ulang → efek speed berubah).
 *   • MP3  → decode ke raw PCM via MediaCodec, lalu buat WAV baru dengan
 *             sample rate yang sudah di-adjust. Hasilnya di-upload sebagai WAV
 *             sehingga Roblox memainkan dengan speed yang sesuai.
 *
 * speedMultiplier:
 *   0.5f = setengah kecepatan, 1.0f = asli, 2.0f = dua kali lebih cepat
 */
object AudioProcessor {

    /**
     * Apply speed ke bytes audio. Return bytes baru yang sudah diproses.
     * Kalau speed == 1.0f, langsung return bytes asli (no-op).
     *
     * Untuk MP3, butuh context agar bisa tulis file sementara ke cacheDir
     * sebelum di-decode dengan MediaExtractor.
     */
    fun applySpeed(bytes: ByteArray, speedMultiplier: Float, context: Context? = null): ByteArray {
        if (speedMultiplier == 1.0f) return bytes
        return when {
            isWav(bytes) -> applySpeedWav(bytes, speedMultiplier)
            context != null -> applySpeedMp3(bytes, speedMultiplier, context)
            else -> bytes // fallback kalau tidak ada context
        }
    }

    // ── WAV detection ──────────────────────────────────────────────────────────

    private fun isWav(bytes: ByteArray): Boolean {
        if (bytes.size < 12) return false
        val riff = String(bytes, 0, 4, Charsets.US_ASCII)
        val wave = String(bytes, 8, 4, Charsets.US_ASCII)
        return riff == "RIFF" && wave == "WAVE"
    }

    // ── WAV speed processing via sample rate rewrite ───────────────────────────
    // Mengubah sample rate di header WAV sehingga Roblox decode dengan tempo berbeda.
    // Ini cara yang paling aman & tidak menyebabkan distorsi pada data audio.

    private fun applySpeedWav(bytes: ByteArray, speed: Float): ByteArray {
        val output = bytes.copyOf()

        // Cari fmt chunk untuk baca & tulis ulang sample rate
        var offset = 12
        while (offset + 8 < output.size) {
            val chunkId   = String(output, offset, 4, Charsets.US_ASCII)
            val chunkSize = ByteBuffer.wrap(output, offset + 4, 4).order(ByteOrder.LITTLE_ENDIAN).int

            if (chunkId == "fmt ") {
                // Sample rate: 4 byte di offset+8 dari awal chunk
                val srOffset = offset + 8
                if (srOffset + 4 <= output.size) {
                    val origSr = ByteBuffer.wrap(output, srOffset, 4).order(ByteOrder.LITTLE_ENDIAN).int
                    val newSr  = (origSr * speed).toInt().coerceIn(8000, 192000)

                    // Tulis sample rate baru
                    val srBuf = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN)
                    srBuf.putInt(newSr)
                    val srBytes = srBuf.array()
                    srBytes.copyInto(output, srOffset)

                    // Byte rate = sampleRate * numChannels * bitsPerSample/8
                    // Letaknya 4 byte setelah sample rate
                    val brOffset = srOffset + 4
                    if (brOffset + 4 <= output.size) {
                        val numChannels   = ByteBuffer.wrap(output, offset + 10, 2).order(ByteOrder.LITTLE_ENDIAN).short.toInt()
                        val bitsPerSample = if (offset + 22 < output.size)
                            ByteBuffer.wrap(output, offset + 22, 2).order(ByteOrder.LITTLE_ENDIAN).short.toInt()
                        else 16
                        val newByteRate = newSr * numChannels * bitsPerSample / 8
                        val brBuf = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN)
                        brBuf.putInt(newByteRate)
                        brBuf.array().copyInto(output, brOffset)
                    }
                }
                break
            }
            offset += 8 + chunkSize
        }

        return output
    }

    // ── MP3 speed processing via MediaCodec decode → WAV encode ───────────────
    // Decode MP3 ke raw PCM 16-bit, lalu buat WAV baru dengan sample rate
    // yang sudah di-adjust (sample rate * speed). Roblox akan decode WAV dan
    // memainkan dengan tempo yang sesuai.

    private fun applySpeedMp3(bytes: ByteArray, speed: Float, context: Context): ByteArray {
        // Tulis bytes ke file sementara agar bisa dibaca MediaExtractor
        val tmpFile = File(context.cacheDir, "_speed_proc_${System.currentTimeMillis()}.mp3")
        return try {
            tmpFile.writeBytes(bytes)
            val pcmData = decodeMp3ToPcm(tmpFile.absolutePath)
                ?: return bytes // gagal decode, return original

            val sampleRate   = pcmData.sampleRate
            val channelCount = pcmData.channelCount
            val pcmBytes     = pcmData.data

            // Hitung sample rate baru (adjusted oleh speed)
            val newSampleRate = (sampleRate * speed).toInt().coerceIn(8000, 192000)

            // Buat WAV dari raw PCM dengan sample rate baru
            buildWav(pcmBytes, newSampleRate, channelCount, bitsPerSample = 16)
        } catch (_: Exception) {
            bytes // jika terjadi error apapun, return original bytes
        } finally {
            tmpFile.delete()
        }
    }

    // Data class untuk menampung hasil decode
    private data class PcmData(
        val data: ByteArray,
        val sampleRate: Int,
        val channelCount: Int
    )

    private fun decodeMp3ToPcm(filePath: String): PcmData? {
        val extractor = MediaExtractor()
        return try {
            extractor.setDataSource(filePath)

            // Cari audio track
            var audioTrackIndex = -1
            var audioFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val fmt = extractor.getTrackFormat(i)
                val mime = fmt.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    audioFormat = fmt
                    break
                }
            }
            if (audioTrackIndex < 0 || audioFormat == null) return null

            val mime         = audioFormat.getString(MediaFormat.KEY_MIME)!!
            val sampleRate   = audioFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            val channelCount = audioFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)

            extractor.selectTrack(audioTrackIndex)

            val codec = MediaCodec.createDecoderByType(mime)
            codec.configure(audioFormat, null, null, 0)
            codec.start()

            val outputStream = ByteArrayOutputStream()
            val bufferInfo   = MediaCodec.BufferInfo()
            var inputDone    = false
            var outputDone   = false

            while (!outputDone) {
                // Feed input
                if (!inputDone) {
                    val inputIdx = codec.dequeueInputBuffer(10_000)
                    if (inputIdx >= 0) {
                        val inputBuf = codec.getInputBuffer(inputIdx)!!
                        val sampleSize = extractor.readSampleData(inputBuf, 0)
                        if (sampleSize < 0) {
                            codec.queueInputBuffer(inputIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inputIdx, 0, sampleSize, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                // Drain output
                val outputIdx = codec.dequeueOutputBuffer(bufferInfo, 10_000)
                if (outputIdx >= 0) {
                    val outBuf = codec.getOutputBuffer(outputIdx)!!
                    if (bufferInfo.size > 0) {
                        val chunk = ByteArray(bufferInfo.size)
                        outBuf.get(chunk)
                        outputStream.write(chunk)
                    }
                    codec.releaseOutputBuffer(outputIdx, false)
                    if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                        outputDone = true
                    }
                } else if (outputIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    // format changed — tidak perlu tindakan khusus
                }
            }

            codec.stop()
            codec.release()

            val pcmBytes = outputStream.toByteArray()
            if (pcmBytes.isEmpty()) null
            else PcmData(pcmBytes, sampleRate, channelCount)

        } catch (_: Exception) {
            null
        } finally {
            extractor.release()
        }
    }

    // ── WAV builder dari raw PCM 16-bit ───────────────────────────────────────

    private fun buildWav(pcmData: ByteArray, sampleRate: Int, channelCount: Int, bitsPerSample: Int): ByteArray {
        val byteRate    = sampleRate * channelCount * bitsPerSample / 8
        val blockAlign  = channelCount * bitsPerSample / 8
        val dataSize    = pcmData.size
        val chunkSize   = 36 + dataSize

        val buf = ByteBuffer.allocate(44 + dataSize).order(ByteOrder.LITTLE_ENDIAN)

        // RIFF header
        buf.put("RIFF".toByteArray(Charsets.US_ASCII))
        buf.putInt(chunkSize)
        buf.put("WAVE".toByteArray(Charsets.US_ASCII))

        // fmt chunk
        buf.put("fmt ".toByteArray(Charsets.US_ASCII))
        buf.putInt(16)                          // subchunk size
        buf.putShort(1)                         // PCM = 1
        buf.putShort(channelCount.toShort())
        buf.putInt(sampleRate)
        buf.putInt(byteRate)
        buf.putShort(blockAlign.toShort())
        buf.putShort(bitsPerSample.toShort())

        // data chunk
        buf.put("data".toByteArray(Charsets.US_ASCII))
        buf.putInt(dataSize)
        buf.put(pcmData)

        return buf.array()
    }
}
