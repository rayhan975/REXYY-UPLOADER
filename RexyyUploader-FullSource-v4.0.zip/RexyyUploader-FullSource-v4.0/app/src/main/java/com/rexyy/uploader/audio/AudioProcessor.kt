package com.rexyy.uploader.audio

import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * AudioProcessor — apply speed (tempo) ke ByteArray audio sebelum upload.
 *
 * Cara kerja speed:
 *   • WAV  → ubah sample rate di header (Roblox decode ulang → efek speed berubah).
 *   • MP3/AAC/M4A → decode ke PCM raw via MediaCodec, lalu bungkus jadi WAV
 *                   dengan sample rate yang sudah di-multiply → speed beneran berubah
 *                   di Roblox, bukan cuma preview.
 *
 * speedMultiplier:
 *   0.5f = setengah kecepatan, 1.0f = asli, 2.0f = dua kali lebih cepat
 *
 * Return value:
 *   Pair(ByteArray, String) → bytes hasil + nama mime yang harus dipakai upload.
 *   Kalau speed == 1.0f → return bytes asli + mime asli (no-op).
 */
object AudioProcessor {

    data class ProcessedAudio(
        val bytes: ByteArray,
        val mimeType: String,        // "audio/wav" kalau sudah dikonversi
        val fileName: String         // nama file yang disarankan untuk upload
    )

    // ── Entry point utama ──────────────────────────────────────────────────────

    /**
     * Proses bytes audio dengan speed multiplier.
     * @param bytes    raw bytes file audio
     * @param speed    multiplier speed (1.0f = no-op)
     * @param origMime mime type asli ("audio/mpeg", "audio/wav", dll)
     * @param origName nama file asli (untuk generate nama output)
     * @param cacheDir temporary dir untuk MediaExtractor (pakai context.cacheDir)
     */
    fun applySpeed(
        bytes: ByteArray,
        speed: Float,
        origMime: String = "audio/mpeg",
        origName: String = "audio.mp3",
        cacheDir: File? = null
    ): ProcessedAudio {
        if (speed == 1.0f) return ProcessedAudio(bytes, origMime, origName)

        return if (isWav(bytes)) {
            // WAV: langsung rewrite sample rate di header
            val result = applySpeedWav(bytes, speed)
            ProcessedAudio(result, "audio/wav", toWavName(origName))
        } else {
            // MP3/AAC/M4A: decode ke PCM dulu, lalu bungkus WAV dengan SR baru
            val decoded = decodeToPcm(bytes, cacheDir) ?: return ProcessedAudio(bytes, origMime, origName)
            val newSr = (decoded.sampleRate * speed).toInt().coerceIn(8000, 192000)
            val wav = buildWav(decoded.pcm, decoded.channelCount, newSr, decoded.bitsPerSample)
            ProcessedAudio(wav, "audio/wav", toWavName(origName))
        }
    }

    // ── Backward-compat overload (untuk kode lama yang pakai ByteArray langsung) ──
    // Kalau codebase lain masih panggil applySpeed(bytes, speed) tanpa mime/name,
    // ini akan handle WAV dengan benar dan MP3 akan di-decode pakai cacheDir null
    // (fallback ke temp system — mungkin butuh cacheDir, lihat catatan di decodeToPcm).
    fun applySpeed(bytes: ByteArray, speed: Float): ByteArray {
        return applySpeed(bytes, speed, "audio/mpeg", "audio.mp3", null).bytes
    }

    // ── WAV detection ──────────────────────────────────────────────────────────

    fun isWav(bytes: ByteArray): Boolean {
        if (bytes.size < 12) return false
        val riff = String(bytes, 0, 4, Charsets.US_ASCII)
        val wave = String(bytes, 8, 4, Charsets.US_ASCII)
        return riff == "RIFF" && wave == "WAVE"
    }

    // ── Nama file helper ───────────────────────────────────────────────────────

    private fun toWavName(orig: String): String {
        val base = orig.substringBeforeLast('.').ifBlank { "audio" }
        return "${base}_speed.wav"
    }

    // ── WAV speed processing via sample rate rewrite ───────────────────────────

    private fun applySpeedWav(bytes: ByteArray, speed: Float): ByteArray {
        val output = bytes.copyOf()
        var offset = 12
        while (offset + 8 < output.size) {
            val chunkId   = String(output, offset, 4, Charsets.US_ASCII)
            val chunkSize = ByteBuffer.wrap(output, offset + 4, 4).order(ByteOrder.LITTLE_ENDIAN).int

            if (chunkId == "fmt ") {
                val srOffset = offset + 8
                if (srOffset + 4 <= output.size) {
                    val origSr = ByteBuffer.wrap(output, srOffset, 4).order(ByteOrder.LITTLE_ENDIAN).int
                    val newSr  = (origSr * speed).toInt().coerceIn(8000, 192000)

                    val srBuf = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN)
                    srBuf.putInt(newSr)
                    srBuf.array().copyInto(output, srOffset)

                    val brOffset = srOffset + 4
                    if (brOffset + 4 <= output.size) {
                        val numChannels   = ByteBuffer.wrap(output, offset + 10, 2).order(ByteOrder.LITTLE_ENDIAN).short.toInt()
                        val bitsPerSample = if (offset + 22 < output.size)
                            ByteBuffer.wrap(output, offset + 22, 2).order(ByteOrder.LITTLE_ENDIAN).short.toInt()
                        else 16
                        val newByteRate = newSr * numChannels * bitsPerSample / 8
                        val brBuf = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN)
                        brBuf.putInt(newByteRate)
                        brBuf.array().copyInto(output, brOffset)
                    }
                }
                break
            }
            offset += 8 + chunkSize
        }
        return output
    }

    // ── MP3/AAC decoder via MediaCodec + MediaExtractor ───────────────────────

    private data class PcmData(
        val pcm: ByteArray,
        val sampleRate: Int,
        val channelCount: Int,
        val bitsPerSample: Int = 16
    )

    /**
     * Decode audio bytes (MP3/AAC/M4A) ke PCM 16-bit via MediaCodec.
     * MediaExtractor butuh file di disk, jadi kita tulis ke temp file dulu.
     * Return null kalau gagal decode (fallback ke bytes asli).
     */
    private fun decodeToPcm(bytes: ByteArray, cacheDir: File?): PcmData? {
        // Tulis bytes ke temp file supaya MediaExtractor bisa baca
        val tmpDir  = cacheDir ?: File(System.getProperty("java.io.tmpdir") ?: "/tmp")
        val tmpFile = File(tmpDir, "rexyy_decode_${System.currentTimeMillis()}.tmp")
        return try {
            FileOutputStream(tmpFile).use { it.write(bytes) }
            decodeToPcmFromFile(tmpFile)
        } catch (e: Exception) {
            null
        } finally {
            tmpFile.delete()
        }
    }

    private fun decodeToPcmFromFile(file: File): PcmData? {
        val extractor = MediaExtractor()
        return try {
            extractor.setDataSource(file.absolutePath)

            // Cari track audio
            var trackIndex = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val fmt = extractor.getTrackFormat(i)
                val mime = fmt.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    trackIndex = i
                    format = fmt
                    break
                }
            }
            if (trackIndex < 0 || format == null) return null

            extractor.selectTrack(trackIndex)

            val mime         = format.getString(MediaFormat.KEY_MIME)!!
            val sampleRate   = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            val channelCount = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)

            val codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()

            val outputStream = ByteArrayOutputStream()
            val bufferInfo   = MediaCodec.BufferInfo()
            var inputDone    = false
            var outputDone   = false

            while (!outputDone) {
                // Feed input
                if (!inputDone) {
                    val inputIdx = codec.dequeueInputBuffer(10_000L)
                    if (inputIdx >= 0) {
                        val inputBuf = codec.getInputBuffer(inputIdx)!!
                        val sampleSize = extractor.readSampleData(inputBuf, 0)
                        if (sampleSize < 0) {
                            codec.queueInputBuffer(inputIdx, 0, 0, 0,
                                MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inputIdx, 0, sampleSize,
                                extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                // Drain output
                val outputIdx = codec.dequeueOutputBuffer(bufferInfo, 10_000L)
                if (outputIdx >= 0) {
                    val outputBuf = codec.getOutputBuffer(outputIdx)!!
                    if (bufferInfo.size > 0) {
                        val chunk = ByteArray(bufferInfo.size)
                        outputBuf.get(chunk)
                        outputStream.write(chunk)
                    }
                    codec.releaseOutputBuffer(outputIdx, false)
                    if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                        outputDone = true
                    }
                } else if (outputIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    // format bisa berubah, tapi kita pakai format awal
                }
            }

            codec.stop()
            codec.release()

            PcmData(
                pcm          = outputStream.toByteArray(),
                sampleRate   = sampleRate,
                channelCount = channelCount,
                bitsPerSample = 16
            )
        } catch (e: Exception) {
            null
        } finally {
            extractor.release()
        }
    }

    // ── WAV builder dari PCM raw ───────────────────────────────────────────────

    /**
     * Bungkus PCM 16-bit ke dalam container WAV.
     * @param pcm          raw PCM bytes (16-bit little-endian)
     * @param channelCount jumlah channel (1=mono, 2=stereo)
     * @param sampleRate   sample rate yang akan ditulis di header (sudah di-multiply speed)
     * @param bitsPerSample biasanya 16
     */
    fun buildWav(
        pcm: ByteArray,
        channelCount: Int,
        sampleRate: Int,
        bitsPerSample: Int = 16
    ): ByteArray {
        val byteRate    = sampleRate * channelCount * bitsPerSample / 8
        val blockAlign  = channelCount * bitsPerSample / 8
        val dataSize    = pcm.size
        val chunkSize   = 36 + dataSize

        val out = ByteArrayOutputStream(44 + dataSize)
        val buf = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)

        // RIFF header
        buf.put("RIFF".toByteArray(Charsets.US_ASCII))
        buf.putInt(chunkSize)
        buf.put("WAVE".toByteArray(Charsets.US_ASCII))

        // fmt chunk
        buf.put("fmt ".toByteArray(Charsets.US_ASCII))
        buf.putInt(16)                       // subchunk1 size
        buf.putShort(1)                      // PCM = 1
        buf.putShort(channelCount.toShort())
        buf.putInt(sampleRate)
        buf.putInt(byteRate)
        buf.putShort(blockAlign.toShort())
        buf.putShort(bitsPerSample.toShort())

        // data chunk header
        buf.put("data".toByteArray(Charsets.US_ASCII))
        buf.putInt(dataSize)

        out.write(buf.array())
        out.write(pcm)
        return out.toByteArray()
    }
}
