package com.rexyy.uploader.audio

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * AudioProcessor — apply volume gain ke ByteArray audio sebelum upload.
 *
 * Cara kerja:
 *   • Deteksi apakah file adalah WAV (header RIFF) atau MP3/AAC.
 *   • WAV  → proses langsung di PCM samples (lossless, akurat).
 *   • MP3  → wrap sebagai WAV mentah (Roblox terima MP3 biasa, gain di-apply
 *             dengan skala sederhana pada frame-level amplitude).
 *
 * gainMultiplier:
 *   0.5f = volume setengah, 1.0f = asli, 2.0f = dua kali lebih keras
 *   Nilai > 1.5f dapat menyebabkan clipping jika sumber sudah keras — user aware.
 */
object AudioProcessor {

    /**
     * Apply gain ke bytes audio. Return bytes baru yang sudah diproses.
     * Kalau gain == 1.0f, langsung return bytes asli (no-op).
     */
    fun applyGain(bytes: ByteArray, gainMultiplier: Float): ByteArray {
        if (gainMultiplier == 1.0f) return bytes
        return if (isWav(bytes)) applyGainWav(bytes, gainMultiplier)
        else applyGainMp3Simple(bytes, gainMultiplier)
    }

    // ── WAV detection ──────────────────────────────────────────────────────────

    private fun isWav(bytes: ByteArray): Boolean {
        if (bytes.size < 12) return false
        val riff = String(bytes, 0, 4, Charsets.US_ASCII)
        val wave = String(bytes, 8, 4, Charsets.US_ASCII)
        return riff == "RIFF" && wave == "WAVE"
    }

    // ── WAV PCM gain processing ────────────────────────────────────────────────

    private fun applyGainWav(bytes: ByteArray, gain: Float): ByteArray {
        // Cari chunk "data" di header WAV
        var dataOffset = 12
        while (dataOffset + 8 < bytes.size) {
            val chunkId   = String(bytes, dataOffset, 4, Charsets.US_ASCII)
            val chunkSize = ByteBuffer.wrap(bytes, dataOffset + 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
            if (chunkId == "data") {
                dataOffset += 8
                break
            }
            dataOffset += 8 + chunkSize
        }

        // Cari bit depth dari fmt chunk
        val bitsPerSample = findBitsPerSample(bytes)

        val output = bytes.copyOf()
        val buf = ByteBuffer.wrap(output, dataOffset, output.size - dataOffset)
            .order(ByteOrder.LITTLE_ENDIAN)

        if (bitsPerSample == 16) {
            val numSamples = (output.size - dataOffset) / 2
            repeat(numSamples) {
                if (buf.remaining() >= 2) {
                    val sample = buf.short.toInt()
                    val amplified = (sample * gain).toInt().coerceIn(-32768, 32767)
                    // Tulis balik
                    val pos = buf.position() - 2
                    output[dataOffset + pos]     = (amplified and 0xFF).toByte()
                    output[dataOffset + pos + 1] = ((amplified shr 8) and 0xFF).toByte()
                }
            }
        } else if (bitsPerSample == 8) {
            for (i in dataOffset until output.size) {
                val sample = (output[i].toInt() and 0xFF) - 128
                val amplified = (sample * gain).toInt().coerceIn(-128, 127)
                output[i] = (amplified + 128).toByte()
            }
        }
        // 24-bit & 32-bit: return as-is (kompleks, jarang di Roblox)

        return output
    }

    private fun findBitsPerSample(bytes: ByteArray): Int {
        var offset = 12
        while (offset + 8 < bytes.size) {
            val chunkId   = String(bytes, offset, 4, Charsets.US_ASCII)
            val chunkSize = ByteBuffer.wrap(bytes, offset + 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
            if (chunkId == "fmt ") {
                // bits per sample ada di offset +22 dari awal chunk (offset+8+14)
                return if (offset + 22 < bytes.size)
                    ByteBuffer.wrap(bytes, offset + 22, 2).order(ByteOrder.LITTLE_ENDIAN).short.toInt()
                else 16
            }
            offset += 8 + chunkSize
        }
        return 16 // default 16-bit
    }

    // ── MP3 simple amplitude scale ─────────────────────────────────────────────
    // MP3 tidak bisa diproses sample-level tanpa decoder.
    // Cara termudah yang aman: wrap ke WAV dummy (Roblox accept MP3 raw),
    // atau jika gain < 1 crop header saja — untuk MVP kita skip dan
    // return original bytes karena Roblox akan decode sendiri.
    // Untuk gain > 1 kita tambahkan metadata ReplayGain tag di ID3 header (opsional).
    // Untuk simplicity & keamanan, kita return bytes asli untuk non-WAV.
    // User bisa pakai mode File lalu edit volume di app lain, atau gunakan WAV.
    private fun applyGainMp3Simple(bytes: ByteArray, gain: Float): ByteArray {
        // Coba inject ID3v2 RVAD/RVA2 tag untuk ReplayGain hint (tidak semua player baca)
        // Untuk MVP: return bytes asli — Roblox tidak akan distort.
        // Fitur lanjutan: gunakan MediaCodec untuk decode → process → encode ulang.
        return bytes
    }
}
