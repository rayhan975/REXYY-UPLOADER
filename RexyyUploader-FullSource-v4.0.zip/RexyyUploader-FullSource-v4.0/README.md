# Rexyy Uploader — source project

Android native app (Kotlin + Jetpack Compose) for Roblox Open Cloud asset upload.

## Included
- Audio / Decal file picker (Android document picker)
- Roblox API key and creator user ID settings
- Multipart upload request to `POST https://apis.roblox.com/assets/v1/assets`
- Polling operation endpoint and display of returned status/asset ID
- Local upload history and help page
- GitHub Actions workflow for building a debug APK

## Build
Open this folder in Android Studio with JDK 17, sync Gradle, then Build > Build APK(s).

## Important limitations
- This is a clean-room implementation, not recovered source from the supplied APK.
- Roblox API requirements, accepted media formats, creator context, and permissions can change; verify current Creator Dashboard requirements. API key needs the relevant asset permissions (at minimum asset write; operation reads may require read permission).
- API key is currently stored in app-private SharedPreferences. It is not included in source, but this is not an encrypted vault; do not use on a shared/rooted device. A production release should add Android Keystore-backed encryption and a privacy/security review.
- Limit page, advanced audio editing/effects, background upload service, multi-account profiles, and automated account verification are not implemented. Roblox does not expose a universal remaining quota endpoint for every asset workflow, so the app does not invent quota values.
- Test with a small non-sensitive asset first. Upload may fail due to permissions, unsupported format/size, creator ID, moderation, or Roblox-side restrictions.
