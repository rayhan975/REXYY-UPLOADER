package com.rexyy.uploader.network

import org.json.JSONObject
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Download audio dari link YouTube / TikTok via multiple API fallback.
 * Spotify DIHAPUS sesuai permintaan.
 *
 * Strategi download YouTube:
 *   1. yt-dlp API (beberapa public instance)
 *   2. Cobalt API v10 fallback
 *
 * Strategi download TikTok:
 *   1. TikTok no-watermark API publik
 *   2. Cobalt API v10 fallback
 */
object LinkDownloader {

    enum class LinkType { YOUTUBE, TIKTOK, UNSUPPORTED }

    fun detectType(url: String): LinkType {
        val u = url.trim().lowercase()
        return when {
            u.contains("youtube.com") || u.contains("youtu.be") -> LinkType.YOUTUBE
            u.contains("tiktok.com") || u.contains("vt.tiktok.com")
                || u.contains("vm.tiktok.com") -> LinkType.TIKTOK
            else -> LinkType.UNSUPPORTED
        }
    }

    data class DownloadResult(val stream: InputStream, val fileName: String, val mimeType: String)

    fun download(rawUrl: String, type: LinkType): DownloadResult {
        return when (type) {
            LinkType.YOUTUBE -> downloadYoutube(rawUrl)
            LinkType.TIKTOK  -> downloadTiktok(rawUrl)
            else -> throw IllegalArgumentException("Link tidak didukung. Gunakan YouTube atau TikTok.")
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // YOUTUBE DOWNLOADER
    // Strategi: coba beberapa public yt-dlp API → fallback cobalt
    // ══════════════════════════════════════════════════════════════════════════

    // Public yt-dlp REST API instances — return JSON dengan field "url" audio
    // Format: POST {url: "..."} → {url: "...direct-audio-url..."}
    private val YT_API_INSTANCES = listOf(
        "https://yt-dlp-api.fly.dev",          // community instance
        "https://ytdlp.onrender.com",          // community instance
    )

    // Cobalt instances sebagai fallback (support YouTube & TikTok)
    private val COBALT_INSTANCES = listOf(
        "https://cobalt.api.timelessnesses.me",
        "https://capi.bloatcat.xyz",
        "https://cobalt.tools",
        "https://co.wuk.sh"
    )

    private fun downloadYoutube(url: String): DownloadResult {
        var lastError = "Semua server YouTube gagal"

        // ── Coba yt-dlp public API ──
        for (base in YT_API_INSTANCES) {
            try {
                val audioUrl = tryYtDlpInstance(base, url)
                if (audioUrl != null) {
                    return fetchStream(audioUrl, "yt_audio.mp3", "audio/mpeg")
                }
            } catch (e: Exception) {
                lastError = e.message ?: "Error di $base"
            }
        }

        // ── Fallback: Cobalt API ──
        for (base in COBALT_INSTANCES) {
            try {
                val audioUrl = tryCobaltInstance(
                    endpoint = "$base/",
                    body = buildCobaltBody(url),
                    accept = "application/json"
                ) ?: tryCobaltInstance(
                    endpoint = "$base/api/json",
                    body = buildCobaltBodyV7(url),
                    accept = "application/json"
                )
                if (audioUrl != null) {
                    return fetchStream(audioUrl, "yt_audio.mp3", "audio/mpeg")
                }
            } catch (e: Exception) {
                lastError = e.message ?: "Error di $base"
            }
        }

        // ── Last resort: invidious API (alternative YouTube frontend) ──
        try {
            val invUrl = tryInvidiousYoutube(url)
            if (invUrl != null) return fetchStream(invUrl, "yt_audio.mp3", "audio/mpeg")
        } catch (e: Exception) {
            lastError = e.message ?: "Invidious gagal"
        }

        throw RuntimeException(
            "Gagal unduh audio YouTube.\n" +
            "Pastikan: link publik, bukan live stream, & koneksi stabil.\n" +
            "Detail: $lastError"
        )
    }

    private fun tryYtDlpInstance(baseUrl: String, videoUrl: String): String? {
        val body = JSONObject().apply {
            put("url", videoUrl.trim())
            put("format", "bestaudio/best")
            put("extract_audio", true)
            put("audio_format", "mp3")
        }.toString()

        val conn = (URL("$baseUrl/api/download").openConnection() as HttpURLConnection).apply {
            requestMethod   = "POST"
            connectTimeout  = 15_000
            readTimeout     = 45_000
            doOutput        = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "Mozilla/5.0 RexyyUploader/3.0")
        }
        conn.outputStream.use { it.write(body.toByteArray()) }
        val code = conn.responseCode
        val raw  = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.bufferedReader()?.use { it.readText() }?.trim() ?: ""
        conn.disconnect()
        if (raw.isBlank() || !raw.startsWith("{")) return null
        val j = JSONObject(raw)
        return j.optString("url").takeIf { it.startsWith("http") }
            ?: j.optJSONArray("formats")
                ?.let { arr ->
                    // Cari format audio terbaik
                    var best: String? = null
                    for (i in arr.length() - 1 downTo 0) {
                        val fmt = arr.getJSONObject(i)
                        val ext  = fmt.optString("ext")
                        val asr  = fmt.optInt("asr")
                        val u    = fmt.optString("url")
                        if (u.startsWith("http") && asr > 0 && (ext == "mp3" || ext == "m4a" || ext == "webm" || ext == "ogg")) {
                            best = u; break
                        }
                    }
                    best
                }
    }

    private fun tryInvidiousYoutube(videoUrl: String): String? {
        // Ekstrak video ID
        val videoId = Regex("(?:v=|youtu\\.be/|embed/)([A-Za-z0-9_-]{11})").find(videoUrl)
            ?.groupValues?.get(1) ?: return null

        val instances = listOf(
            "https://invidious.snopyta.org",
            "https://yt.artemislena.eu",
            "https://invidious.nerdvpn.de"
        )
        for (inv in instances) {
            try {
                val raw = httpGet("$inv/api/v1/videos/$videoId")
                val j   = JSONObject(raw)
                val streams = j.optJSONArray("adaptiveFormats") ?: continue
                for (i in 0 until streams.length()) {
                    val s    = streams.getJSONObject(i)
                    val type = s.optString("type")
                    val url  = s.optString("url")
                    if (type.startsWith("audio/") && url.startsWith("http")) {
                        return url
                    }
                }
            } catch (_: Exception) {}
        }
        return null
    }

    // ══════════════════════════════════════════════════════════════════════════
    // TIKTOK DOWNLOADER
    // Strategi: tikwm API → ssstik API → cobalt fallback
    // ══════════════════════════════════════════════════════════════════════════

    private fun downloadTiktok(url: String): DownloadResult {
        var lastError = "Semua server TikTok gagal"

        // ── Coba tikwm.com API (paling stabil, return JSON dengan audio URL) ──
        try {
            val audioUrl = tryTikwm(url)
            if (audioUrl != null) return fetchStream(audioUrl, "tt_audio.mp3", "audio/mpeg")
        } catch (e: Exception) { lastError = e.message ?: "tikwm gagal" }

        // ── Coba musicaldown / douyin API ──
        try {
            val audioUrl = tryMusicalDown(url)
            if (audioUrl != null) return fetchStream(audioUrl, "tt_audio.mp3", "audio/mpeg")
        } catch (e: Exception) { lastError = e.message ?: "musicaldown gagal" }

        // ── Fallback cobalt ──
        for (base in COBALT_INSTANCES) {
            try {
                val audioUrl = tryCobaltInstance("$base/", buildCobaltBody(url), "application/json")
                    ?: tryCobaltInstance("$base/api/json", buildCobaltBodyV7(url), "application/json")
                if (audioUrl != null) return fetchStream(audioUrl, "tt_audio.mp3", "audio/mpeg")
            } catch (e: Exception) { lastError = e.message ?: "cobalt gagal di $base" }
        }

        throw RuntimeException(
            "Gagal unduh audio TikTok.\n" +
            "Pastikan: link publik, bukan FYP private, & koneksi stabil.\n" +
            "Detail: $lastError"
        )
    }

    private fun tryTikwm(url: String): String? {
        // tikwm.com API: POST form data
        val formBody = "url=${java.net.URLEncoder.encode(url.trim(), "UTF-8")}&count=12&cursor=0&web=1&hd=1"
        val conn = (URL("https://www.tikwm.com/api/").openConnection() as HttpURLConnection).apply {
            requestMethod  = "POST"
            connectTimeout = 15_000
            readTimeout    = 30_000
            doOutput       = true
            setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            setRequestProperty("User-Agent", "Mozilla/5.0 (Android 14) RexyyUploader/3.0")
            setRequestProperty("Referer", "https://www.tikwm.com/")
        }
        conn.outputStream.use { it.write(formBody.toByteArray()) }
        val code = conn.responseCode
        val raw  = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.bufferedReader()?.use { it.readText() }?.trim() ?: ""
        conn.disconnect()
        if (raw.isBlank() || !raw.startsWith("{")) return null
        val j    = JSONObject(raw)
        val data = j.optJSONObject("data") ?: return null
        // Ambil music URL (audio saja, bukan video)
        return data.optString("music_info")
            .takeIf { it.isNotBlank() }
            ?.let { JSONObject(it).optString("play") }
            ?.takeIf { it.startsWith("http") }
            ?: data.optString("music").takeIf { it.startsWith("http") }
            ?: data.optString("hdplay").takeIf { it.startsWith("http") }   // fallback ke video jika terpaksa
    }

    private fun tryMusicalDown(url: String): String? {
        // Coba endpoint alternatif
        val apis = listOf(
            "https://api.douyin.wtf/api?url=${java.net.URLEncoder.encode(url.trim(), "UTF-8")}&minimal=true",
            "https://tiktok-dl.siilas.workers.dev/?url=${java.net.URLEncoder.encode(url.trim(), "UTF-8")}"
        )
        for (apiUrl in apis) {
            try {
                val raw = httpGet(apiUrl)
                if (raw.isBlank() || !raw.startsWith("{")) continue
                val j = JSONObject(raw)
                val audio = j.optString("music_url").takeIf { it.startsWith("http") }
                    ?: j.optJSONObject("data")?.optString("music")?.takeIf { it.startsWith("http") }
                if (audio != null) return audio
            } catch (_: Exception) {}
        }
        return null
    }

    // ══════════════════════════════════════════════════════════════════════════
    // COBALT API HELPER (shared fallback)
    // ══════════════════════════════════════════════════════════════════════════

    private fun buildCobaltBody(url: String) = JSONObject().apply {
        put("url", url.trim())
        put("downloadMode", "audio")
        put("audioFormat", "mp3")
        put("audioBitrate", "128")
        put("filenameStyle", "basic")
        put("disableMetadata", false)
    }.toString()

    private fun buildCobaltBodyV7(url: String) = JSONObject().apply {
        put("url", url.trim())
        put("isAudioOnly", true)
        put("aFormat", "mp3")
        put("vQuality", "720")
        put("disableMetadata", false)
    }.toString()

    private fun tryCobaltInstance(endpoint: String, body: String, accept: String): String? {
        val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod  = "POST"
            connectTimeout = 20_000
            readTimeout    = 45_000
            doOutput       = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", accept)
            setRequestProperty("User-Agent", "Mozilla/5.0 (Android 14) RexyyUploader/3.0")
        }
        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val raw  = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.bufferedReader()?.use { it.readText() }?.trim() ?: ""
        conn.disconnect()
        if (raw.isBlank() || !raw.startsWith("{")) return null
        val j      = JSONObject(raw)
        val status = j.optString("status")
        val dlUrl  = j.optString("url").takeIf { it.startsWith("http") }
            ?: j.optString("audio").takeIf { it.startsWith("http") }
        return when (status) {
            "tunnel", "redirect", "stream" -> dlUrl
            "error" -> null
            else -> dlUrl
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // HTTP HELPERS
    // ══════════════════════════════════════════════════════════════════════════

    private fun httpGet(url: String, userAgent: String = "Mozilla/5.0 RexyyUploader/3.0"): String {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15_000
            readTimeout    = 25_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", userAgent)
        }
        val code = conn.responseCode
        val body = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.bufferedReader()?.use { it.readText() } ?: ""
        conn.disconnect()
        if (code !in 200..299) throw RuntimeException("HTTP $code dari $url")
        return body
    }

    private fun fetchStream(url: String, fileName: String, mime: String): DownloadResult {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 30_000
            readTimeout    = 180_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "Mozilla/5.0 (Android 14) RexyyUploader/3.0")
        }
        val code = conn.responseCode
        if (code !in 200..299) {
            conn.disconnect()
            throw RuntimeException("Download stream gagal HTTP $code")
        }
        val actualMime = conn.contentType?.substringBefore(";")?.trim()?.takeIf { it.isNotBlank() } ?: mime
        return DownloadResult(stream = conn.inputStream, fileName = fileName, mimeType = actualMime)
    }
}
