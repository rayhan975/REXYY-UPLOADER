package com.rexyy.uploader.network

import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Download audio dari link YouTube / TikTok via cobalt.tools public API.
 * Spotify hanya mendukung preview 30 detik via preview URL resmi.
 */
object LinkDownloader {

    enum class LinkType { YOUTUBE, TIKTOK, SPOTIFY, UNSUPPORTED }

    fun detectType(url: String): LinkType {
        val u = url.trim().lowercase()
        return when {
            u.contains("youtube.com") || u.contains("youtu.be") -> LinkType.YOUTUBE
            u.contains("tiktok.com") || u.contains("vm.tiktok.com") -> LinkType.TIKTOK
            u.contains("spotify.com") || u.contains("open.spotify") -> LinkType.SPOTIFY
            else -> LinkType.UNSUPPORTED
        }
    }

    /**
     * Untuk YT & TikTok: minta stream URL via cobalt.tools API.
     * Untuk Spotify: ambil preview 30 detik via oEmbed/iframe trick.
     * Return: InputStream audio siap pakai + nama file.
     */
    data class DownloadResult(val stream: InputStream, val fileName: String, val mimeType: String)

    fun download(rawUrl: String, type: LinkType): DownloadResult {
        return when (type) {
            LinkType.YOUTUBE, LinkType.TIKTOK -> downloadViaCobalt(rawUrl, type)
            LinkType.SPOTIFY -> downloadSpotifyPreview(rawUrl)
            else -> throw IllegalArgumentException("Link tidak didukung")
        }
    }

    // ── COBALT.TOOLS ──────────────────────────────────────────────────────────
    private fun downloadViaCobalt(url: String, type: LinkType): DownloadResult {
        val apiUrl = "https://cobalt.tools/api/json"
        val body = JSONObject().apply {
            put("url", url.trim())
            put("vCodec", "h264")
            put("vQuality", "720")
            put("aFormat", "mp3")
            put("isAudioOnly", true)
            put("disableMetadata", false)
        }.toString()

        val conn = (URL(apiUrl).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 30_000
            readTimeout   = 60_000
            doOutput      = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "RexyyUploader/1.0")
        }
        conn.outputStream.use { it.write(body.toByteArray()) }

        val code = conn.responseCode
        val resp = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.bufferedReader()?.use { it.readText() }
            ?: throw RuntimeException("Cobalt tidak merespons")
        conn.disconnect()

        val json = JSONObject(resp)
        val status = json.optString("status")
        // cobalt bisa return "stream", "redirect", "tunnel"
        val audioUrl = when (status) {
            "stream", "redirect", "tunnel" -> json.optString("url")
            else -> throw RuntimeException("Cobalt error: ${json.optString("text", resp)}")
        }
        if (audioUrl.isBlank()) throw RuntimeException("URL audio kosong dari cobalt")

        val prefix = if (type == LinkType.YOUTUBE) "YT" else "TT"
        return fetchStream(audioUrl, "${prefix}_audio.mp3", "audio/mpeg")
    }

    // ── SPOTIFY PREVIEW ───────────────────────────────────────────────────────
    private fun downloadSpotifyPreview(spotifyUrl: String): DownloadResult {
        // Ekstrak track ID dari URL: open.spotify.com/track/TRACK_ID
        val trackId = Regex("track/([A-Za-z0-9]+)").find(spotifyUrl)?.groupValues?.get(1)
            ?: throw IllegalArgumentException("URL Spotify tidak valid atau bukan track")

        // Ambil metadata via oEmbed untuk mendapat preview_url
        val oembedUrl = "https://open.spotify.com/oembed?url=https://open.spotify.com/track/$trackId"
        val oembedConn = (URL(oembedUrl).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15_000
            readTimeout   = 15_000
            setRequestProperty("User-Agent", "RexyyUploader/1.0")
        }
        val oembedCode = oembedConn.responseCode
        val oembedResp = (if (oembedCode in 200..299) oembedConn.inputStream else oembedConn.errorStream)
            ?.bufferedReader()?.use { it.readText() } ?: ""
        oembedConn.disconnect()

        val trackName = try { JSONObject(oembedResp).optString("title", "spotify_track") } catch (_: Exception) { "spotify_track" }

        // Preview URL Spotify resmi (30 detik): p.scdn.co/mp3-preview/TRACKID
        // Cara alternatif: hit embed page dan parse preview_url dari JSON embedded di HTML
        val embedUrl = "https://open.spotify.com/embed/track/$trackId"
        val embedConn = (URL(embedUrl).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15_000
            readTimeout   = 15_000
            setRequestProperty("User-Agent", "Mozilla/5.0 (Android)")
        }
        val embedCode = embedConn.responseCode
        val embedHtml = (if (embedCode in 200..299) embedConn.inputStream else embedConn.errorStream)
            ?.bufferedReader()?.use { it.readText() } ?: ""
        embedConn.disconnect()

        // Parse preview URL dari JSON yang ada di <script id="__NEXT_DATA__">
        val previewUrl = Regex(""""audioPreview"\s*:\s*\{\s*"url"\s*:\s*"([^"]+)"""")
            .find(embedHtml)?.groupValues?.get(1)
            ?: Regex("preview_url[\"\\s:]+\"(https://[^\"]+p\\.scdn\\.co[^\"]+)\"")
                .find(embedHtml)?.groupValues?.get(1)
            ?: throw RuntimeException("Preview audio Spotify tidak tersedia untuk track ini (mungkin belum ada preview 30 detik)")

        val safeName = trackName.replace(Regex("[^A-Za-z0-9 _-]"), "").take(60).trim().replace(" ", "_")
        return fetchStream(previewUrl, "${safeName}_preview.mp3", "audio/mpeg")
    }

    // ── HELPER ────────────────────────────────────────────────────────────────
    private fun fetchStream(url: String, fileName: String, mime: String): DownloadResult {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 30_000
            readTimeout   = 120_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "RexyyUploader/1.0")
        }
        val code = conn.responseCode
        if (code !in 200..299) {
            conn.disconnect()
            throw RuntimeException("Download gagal HTTP $code")
        }
        return DownloadResult(
            stream   = conn.inputStream,
            fileName = fileName,
            mimeType = conn.contentType?.substringBefore(";")?.trim() ?: mime
        )
    }
}
