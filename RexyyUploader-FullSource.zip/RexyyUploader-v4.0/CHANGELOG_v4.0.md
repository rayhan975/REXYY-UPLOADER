# Rexyy Uploader — Changelog v4.0

## File yang Diubah / Ditambah

### BARU: `audio/AudioProcessor.kt`
- Utility untuk apply volume gain ke audio sebelum upload
- Support WAV (PCM 8-bit & 16-bit) — gain akurat di level sample
- Support MP3/AAC — return bytes asli (Roblox decode sendiri)
- Dipanggil otomatis saat preview dan saat upload

### DIUBAH: `network/LinkDownloader.kt`
- **FIX BUG YouTube** — instance-instance lama offline (co.wuk.sh, ytdlp.onrender.com)
- Diganti: cobalt.tools official API, cobalt.ggtyler.dev, cobalt.privacydev.net
- Tambah fallback **Piped API** (open-source YouTube proxy)
- Tambah lebih banyak instance Invidious
- Timeout diperpanjang (60 detik) untuk koneksi lambat

### DIUBAH: `MainActivity.kt`
- **Fitur Volume Audio** — selector 50%/75%/100%/125%/150%/175%/200%
  - Muncul di mode FILE (Audio)
  - Muncul di mode LINK (YouTube & TikTok)
  - Sama persis tampilannya dengan Speed selector
  - Apply saat preview (bisa denger hasilnya sebelum upload)
  - Apply saat upload ke Roblox (suara di Roblox = setting volume yang dipilih)
- **Halaman Bantuan diperbarui** — lebih rapih:
  - Section CARA UPLOAD: numbered steps dengan judul & deskripsi
  - Section FITUR SPEED & VOLUME: penjelasan kedua fitur
  - Section LIMIT UPLOAD: dengan icon per baris
  - Section KONTAK OWNER: avatar icon + info WA & Discord
  - Section VERSI APP di bawah

## Cara Pasang ke Project
1. Salin `audio/AudioProcessor.kt` ke folder `audio/` (buat folder baru)
2. Replace `network/LinkDownloader.kt` dengan versi baru
3. Replace `MainActivity.kt` dengan versi baru
4. Build seperti biasa — tidak ada dependency baru yang perlu ditambah di build.gradle
