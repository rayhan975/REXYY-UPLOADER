package com.rexyy.uploader

import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rexyy.uploader.network.RobloxAssetUploader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

private val Bg = Color(0xFF08090D)
private val Panel = Color(0xFF171922)
private val Purple = Color(0xFF9B6CFF)
private val Muted = Color(0xFF9BA1B2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RexyyApp() }
    }
}

private enum class Page(val label: String) {
    Upload("Upload"), History("History"), Account("Account"), Help("Bantuan")
}

private data class HistoryItem(
    val type: String, val name: String, val id: String,
    val status: String, val date: String
)

// Ambil nama file bersih dari URI
private fun getFileNameFromUri(context: Context, uri: Uri): String {
    var result = ""
    if (uri.scheme == "content") {
        val cursor = context.contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                val idx = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) result = it.getString(idx)
            }
        }
    }
    if (result.isBlank()) {
        result = uri.lastPathSegment?.substringAfterLast('/') ?: "File dipilih"
    }
    return result
}

@Composable
private fun RexyyApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("rexyy_local", 0) }

    var page by remember { mutableStateOf(Page.Upload) }
    var type by remember { mutableStateOf("Audio") }
    var uri by remember { mutableStateOf<Uri?>(null) }
    var fileName by remember { mutableStateOf("") }

    var apiKey by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
    var creator by remember { mutableStateOf(prefs.getString("creator_id", "") ?: "") }
    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("Uploaded via Rexyy Uploader") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var operation by remember { mutableStateOf("") }
    var assetId by remember { mutableStateOf("") }
    var history by remember { mutableStateOf(loadHistory(prefs.getString("history", "[]") ?: "[]")) }

    // Speed playback state
    var selectedSpeed by remember { mutableStateOf(1.0f) }
    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    var isPlaying by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { picked ->
        if (picked != null) {
            uri = picked
            fileName = getFileNameFromUri(context, picked)
            // Otomatis isi nama asset dari nama file (tanpa ekstensi)
            val nameWithoutExt = fileName.substringBeforeLast('.').ifBlank { fileName }
            name = nameWithoutExt
            try {
                context.contentResolver.takePersistableUriPermission(
                    picked, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            // Reset media player saat file baru dipilih
            mediaPlayer?.release()
            mediaPlayer = null
            isPlaying = false
        }
    }

    // Cleanup media player saat composable di-dispose
    DisposableEffect(Unit) {
        onDispose {
            mediaPlayer?.release()
            mediaPlayer = null
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Bg, surface = Panel)) {
        Scaffold(
            containerColor = Bg,
            snackbarHost = { SnackbarHost(snackbar) },
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF11131A)) {
                    Page.values().forEach { p ->
                        NavigationBarItem(
                            selected = page == p,
                            onClick = { page = p },
                            icon = {
                                Icon(
                                    when (p) {
                                        Page.Upload -> Icons.Default.CloudUpload
                                        Page.History -> Icons.Default.History
                                        Page.Account -> Icons.Default.Person
                                        Page.Help -> Icons.Default.Help
                                    }, null
                                )
                            },
                            label = { Text(p.label, fontSize = 10.sp) }
                        )
                    }
                }
            }
        ) { pad ->
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(pad)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("REXYY", fontSize = 23.sp, fontWeight = FontWeight.Black, color = Color.White, letterSpacing = 2.sp)
                        Text("ROBLOX ASSET UPLOADER", fontSize = 10.sp, color = Muted)
                    }
                    Text(
                        if (apiKey.isBlank()) "BELUM TERHUBUNG" else "API KEY TERSIMPAN",
                        color = if (apiKey.isBlank()) Color(0xFFFFC56A) else Color(0xFF68DDA0),
                        fontSize = 10.sp, fontWeight = FontWeight.Bold
                    )
                }

                Spacer(Modifier.height(20.dp))

                when (page) {
                    Page.Account -> {
                        Title("Akun Roblox", "API Key disimpan lokal di perangkat.")
                        CardBox {
                            OutlinedTextField(apiKey, { apiKey = it }, Modifier.fillMaxWidth(), label = { Text("Roblox Open Cloud API Key") }, singleLine = true)
                            Spacer(Modifier.height(10.dp))
                            OutlinedTextField(creator, { creator = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(), label = { Text("Creator User ID") }, singleLine = true)
                            Spacer(Modifier.height(12.dp))
                            Button(onClick = {
                                prefs.edit().putString("api_key", apiKey.trim()).putString("creator_id", creator.trim()).apply()
                                scope.launch { snackbar.showSnackbar("Pengaturan akun disimpan di perangkat") }
                            }, Modifier.fillMaxWidth()) { Text("SIMPAN AKUN") }
                            Text("Buat API Key di Creator Dashboard dengan izin asset:write. Jangan bagikan API Key kepada siapa pun.", color = Muted, fontSize = 11.sp)
                        }
                    }

                    Page.Upload -> {
                        Title("Upload asset Roblox", "Kirim Audio atau Decal ke akun/creator yang kamu atur.")
                        CardBox {
                            // Toggle Audio/Decal
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("Audio", "Decal").forEach { t ->
                                    FilterButton(t, type == t, Modifier.weight(1f)) {
                                        type = t
                                        uri = null
                                        fileName = ""
                                        name = ""
                                        mediaPlayer?.release()
                                        mediaPlayer = null
                                        isPlaying = false
                                    }
                                }
                            }

                            Spacer(Modifier.height(12.dp))

                            // Pilih File
                            Text("FILE ${type.uppercase()}", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, Purple, RoundedCornerShape(16.dp))
                                    .clickable { picker.launch(if (type == "Audio") arrayOf("audio/*") else arrayOf("image/*")) }
                                    .padding(22.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        if (type == "Audio") Icons.Default.MusicNote else Icons.Default.Image,
                                        null, tint = Purple, modifier = Modifier.size(32.dp)
                                    )
                                    Text(
                                        if (fileName.isBlank()) "Pilih file dari HP" else fileName,
                                        color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        if (type == "Audio") "Pilih audio yang didukung Roblox" else "Pilih gambar PNG/JPG",
                                        color = Muted, fontSize = 11.sp
                                    )
                                }
                            }

                            // === SPEED PLAYBACK (hanya muncul kalau Audio dan file sudah dipilih) ===
                            if (type == "Audio" && uri != null) {
                                Spacer(Modifier.height(14.dp))
                                Divider(color = Color(0xFF393D4A))
                                Spacer(Modifier.height(12.dp))

                                Row(
                                    Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Speed, null, tint = Muted, modifier = Modifier.size(14.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("SPEED PLAYBACK", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Text("${selectedSpeed}x", color = Purple, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }

                                Spacer(Modifier.height(8.dp))

                                // Tombol speed seperti di foto
                                val speeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f)
                                Row(
                                    Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    speeds.forEach { spd ->
                                        val isSelected = selectedSpeed == spd
                                        Box(
                                            Modifier
                                                .weight(1f)
                                                .background(
                                                    if (isSelected) Color.White else Color(0xFF252936),
                                                    RoundedCornerShape(8.dp)
                                                )
                                                .border(
                                                    1.dp,
                                                    if (isSelected) Color.White else Color(0xFF393D4A),
                                                    RoundedCornerShape(8.dp)
                                                )
                                                .clickable {
                                                    selectedSpeed = spd
                                                    // Terapkan speed ke MediaPlayer kalau sedang main
                                                    mediaPlayer?.playbackParams = mediaPlayer?.playbackParams?.setSpeed(spd) ?: return@clickable
                                                }
                                                .padding(vertical = 6.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                if (spd == 1.0f) "1.0x" else "${spd}x",
                                                color = if (isSelected) Color.Black else Color.White,
                                                fontSize = 10.sp,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                            )
                                        }
                                    }
                                }

                                Spacer(Modifier.height(10.dp))

                                // Tombol Play Preview
                                OutlinedButton(
                                    onClick = {
                                        if (isPlaying) {
                                            mediaPlayer?.pause()
                                            isPlaying = false
                                        } else {
                                            try {
                                                if (mediaPlayer == null) {
                                                    mediaPlayer = MediaPlayer().apply {
                                                        setDataSource(context, uri!!)
                                                        prepare()
                                                        playbackParams = playbackParams.setSpeed(selectedSpeed)
                                                        setOnCompletionListener { isPlaying = false }
                                                    }
                                                } else {
                                                    mediaPlayer?.playbackParams = mediaPlayer!!.playbackParams.setSpeed(selectedSpeed)
                                                }
                                                mediaPlayer?.start()
                                                isPlaying = true
                                            } catch (e: Exception) {
                                                status = "Gagal preview: ${e.message}"
                                            }
                                        }
                                    },
                                    Modifier.fillMaxWidth(),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Purple)
                                ) {
                                    Icon(
                                        if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        null, tint = Purple
                                    )
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        if (isPlaying) "PAUSE PREVIEW" else "PREVIEW AUDIO (${selectedSpeed}x)",
                                        color = Purple, fontSize = 12.sp
                                    )
                                }

                                Spacer(Modifier.height(4.dp))
                                Divider(color = Color(0xFF393D4A))
                            }

                            Spacer(Modifier.height(12.dp))

                            OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("Display Name") }, singleLine = true)
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(desc, { desc = it }, Modifier.fillMaxWidth(), label = { Text("Deskripsi") }, minLines = 2)
                            Spacer(Modifier.height(12.dp))

                            // Tombol Upload
                            Button(
                                onClick = {
                                    if (apiKey.isBlank() || creator.toLongOrNull() == null || uri == null || name.isBlank()) {
                                        status = "Lengkapi API Key, Creator ID, file, dan nama asset."
                                        return@Button
                                    }
                                    busy = true; status = "Mengirim file ke Roblox…"; assetId = ""; operation = ""
                                    scope.launch {
                                        try {
                                            val result = withContext(Dispatchers.IO) {
                                                RobloxAssetUploader(context).upload(apiKey.trim(), uri!!, type, name.trim(), desc.trim(), creator.toLong())
                                            }
                                            operation = result.operationId.orEmpty()
                                            assetId = result.assetId.orEmpty()
                                            status = if (assetId.isNotBlank()) "Upload berhasil. Asset ID: $assetId" else "Upload diterima. Memeriksa status…"
                                            if (operation.isNotBlank()) {
                                                var finalJson = ""
                                                repeat(12) {
                                                    if (finalJson.isBlank()) {
                                                        kotlinx.coroutines.delay(2500)
                                                        finalJson = withContext(Dispatchers.IO) {
                                                            RobloxAssetUploader(context).checkOperation(apiKey.trim(), operation)
                                                        }
                                                        val j = JSONObject(finalJson)
                                                        val state = j.optString("done")
                                                        val response = j.optJSONObject("response")
                                                        val found = response?.optString("assetId").orEmpty()
                                                        if (found.isNotBlank()) assetId = found
                                                        status = when {
                                                            found.isNotBlank() -> "Selesai • Asset ID: $found"
                                                            state == "true" -> "Operasi selesai. Respons: $finalJson"
                                                            else -> "Memproses upload…"
                                                        }
                                                    }
                                                }
                                                if (assetId.isNotBlank() || finalJson.isNotBlank()) {
                                                    val item = HistoryItem(type, name, assetId.ifBlank { operation }, status, System.currentTimeMillis().toString())
                                                    history = listOf(item) + history
                                                    prefs.edit().putString("history", saveHistory(history)).apply()
                                                }
                                            }
                                        } catch (e: Exception) {
                                            status = "Gagal: ${e.message ?: "Kesalahan tidak diketahui"}"
                                        } finally {
                                            busy = false
                                        }
                                    }
                                },
                                Modifier.fillMaxWidth().height(52.dp),
                                enabled = !busy
                            ) {
                                if (busy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                                else Icon(Icons.Default.CloudUpload, null)
                                Spacer(Modifier.width(8.dp))
                                Text(if (busy) "SEDANG UPLOAD…" else "UPLOAD ASSET")
                            }

                            if (status.isNotBlank()) {
                                Spacer(Modifier.height(10.dp))
                                Text(
                                    status,
                                    color = if (status.startsWith("Gagal")) Color(0xFFFF8B8B) else Color(0xFFBBA3FF),
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }

                    Page.History -> {
                        Title("Riwayat Upload", "Riwayat tersimpan lokal di perangkat ini.")
                        if (history.isEmpty()) CardBox { Text("Belum ada riwayat upload.", color = Muted) }
                        else history.forEach { h ->
                            CardBox {
                                Text("${h.type.uppercase()} • ${h.name}", color = Color.White, fontWeight = FontWeight.Bold)
                                Text("ID: ${h.id}", color = Purple, fontSize = 12.sp)
                                Text(h.status, color = Muted, fontSize = 11.sp)
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                        OutlinedButton(
                            onClick = { history = emptyList(); prefs.edit().putString("history", "[]").apply() },
                            Modifier.fillMaxWidth()
                        ) { Text("HAPUS RIWAYAT") }
                    }

                    Page.Help -> {
                        Title("Bantuan", "Panduan penggunaan")
                        CardBox {
                            Text(
                                "1. Tambahkan API Key dan Creator User ID di menu Akun.\n" +
                                "2. Pilih Audio atau Decal.\n" +
                                "3. Pilih file, isi nama dan deskripsi.\n" +
                                "4. Atur speed playback sesuai kebutuhan (opsional).\n" +
                                "5. Tekan Upload Asset dan tunggu hasilnya.\n\n" +
                                "Limit/kuota tidak ditampilkan sebagai angka palsu. Status upload berasal dari respons Roblox. Jika gagal, cek izin API Key, Creator ID, tipe file, dan ketentuan Roblox.",
                                color = Color.White, lineHeight = 21.sp
                            )
                        }
                    }
                }

                Spacer(Modifier.height(20.dp))
            }
        }
    }
}

@Composable
private fun Title(t: String, s: String) {
    Text(t, color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
    Text(s, color = Muted, fontSize = 12.sp)
    Spacer(Modifier.height(14.dp))
}

@Composable
private fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(Brush.linearGradient(listOf(Color(0xFF242631), Panel)), RoundedCornerShape(20.dp))
            .border(1.dp, Color(0xFF393D4A), RoundedCornerShape(20.dp))
            .padding(15.dp),
        content = content
    )
    Spacer(Modifier.height(10.dp))
}

@Composable
private fun FilterButton(t: String, selected: Boolean, m: Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick, modifier = m,
        colors = ButtonDefaults.buttonColors(containerColor = if (selected) Color(0xFF443264) else Color(0xFF252936))
    ) { Text(t) }
}

private fun saveHistory(items: List<HistoryItem>) = org.json.JSONArray().apply {
    items.take(100).forEach {
        put(JSONObject().put("type", it.type).put("name", it.name).put("id", it.id).put("status", it.status).put("date", it.date))
    }
}.toString()

private fun loadHistory(raw: String): List<HistoryItem> {
    return try {
        val a = org.json.JSONArray(raw)
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            HistoryItem(o.optString("type"), o.optString("name"), o.optString("id"), o.optString("status"), o.optString("date"))
        }
    } catch (_: Exception) { emptyList() }
}
